# Implementation and verification

All eleven implementation areas have working code or build tooling. Acceptance remains incomplete where the required evidence is missing or a measured target is unmet.

| Slice | Implementation | Verification |
| --- | --- | --- |
| 1 Store and fixture | Complete data model, compact records, indexes and deterministic generator | Golden fixtures at four sizes, counts, adjacency and query regressions |
| 2 Shell and tokens | Native four-surface shell, pane resizing, themes, tokens and status | Native launch, theme screenshots and contrast tests; complete state audit pending |
| 3 Tree and inspector | Hierarchy, filtering, rename, create, delete, undo and linked axiom sections | Mutation regressions, native creation/focus/Undo journeys; exhaustive inspector audit pending |
| 4 Viewport and force | Hard Budget, eviction, expansion, pins, focus, Barnes-Hut simulation | 10,000-operation fuzz test, protected nodes, determinism and separation |
| 5 Other layouts | Hierarchy, radial, grouped grid and automatic selection | Thirty-two scale and geometry combinations |
| 6 Rendering | Win2D scene, shared shapes, label placement, spatial hit index, minimap and legend | Native swap-chain screenshots, badge geometry, 600-frame traces and external presentation evidence |
| 7 Individuals table | Virtual row window, filtering, sorting, editing, validation and undo | 100,000-row native virtualization, Grid/Table/Value automation, creation dialogs and retained filters |
| 8 SPARQL | Parser, evaluator, syntax editor, seven examples, cancellation and results grid | Example results, parser errors, cap regressions and native query journey |
| 9 Export | PNG at 2x and 3x, SVG and clipboard, shared renderer and metadata | SVG parsing, dimension and caption tests; third-party paste/open checks pending |
| 10 Hardening | Error boundary, accessibility peers, contrast, CI and timing harnesses | 150 domain tests and 15 native journeys pass; full accessibility and performance matrices remain open |
| 11 Packaging | Self-contained x64 and ARM64 payloads, validated unsigned MSIX and architecture bundle, optional signing | Local builds; trusted signing and clean Windows 11 installation pending |

See verification.md for evidence and limitations, decisions.md for specification conflicts, and traceability.csv for the complete numbered requirement map.
