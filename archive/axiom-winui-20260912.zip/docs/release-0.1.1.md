# Axiom 0.1.1 preview

This preview includes a self-contained Windows x64 executable, an ARM64 payload, unsigned MSIX packages and a bundle containing both architectures. The published x64 application has passed the native checks on Windows 10 build 19045. ARM64 has been cross-compiled and packaged.

The graph now presents through a Win2D composition swap chain. Cached text and badge pills reduce repeated drawing work. Selection and pin changes preserve computed layouts, and the force layout reuses its working storage. The frame harness records 600 actual draws per run, with CPU work separated from presentation evidence.

The table exposes native row and cell peers, column roles, sort state, per-cell header associations and accessible validation errors. Narrow windows wrap controls and restore the inspector when widened. Row and graph text metrics respond to Windows text scaling.

The create-class dialog validates its required name, expands the parent, reveals the new class and restores focus. Creation writes one subclass triple. The create-individual dialog supports a chosen rating and customer, uses the specified defaults, validates price and preserves active table filters. Both operations support Undo.

The packaged frame harness completed all 18 measured runs, each with 600 actual graph draws. The median per-run p95 CPU work at 3,000 force nodes was 16.59 ms in light theme and 16.54 ms in dark theme on this host; presentation acceptance remains open.

All 150 domain and geometry tests pass. The published x64 payload passes 15 native automation journeys, native PNG/SVG rendering in both themes, and virtualization checks at 100,000 records.

Full specification acceptance remains open. The verification record includes the measured presentation limits, the WinUI table-wide header limitation, the remaining accessibility matrix and the Windows 11 installation and signing requirements. These artifacts are development previews.

See [verification](verification.md) for commands and evidence, and [implementation decisions](decisions.md) for specification resolutions.
