# Implementation decisions

The normative suite describes the product. This document records resolutions where its requirements conflict.

1. WinUI 3 with Win2D implements the native Windows application, following the recommendation in the product overview. Core and fixture projects have no UI references. The development executable is unpackaged and bundles the Windows App SDK runtime. Release packaging is a separate operation.
2. STORE-62 and DEF-14 take precedence over the reference counter and the old FIX-92, FIX V48 to V51 and AC-S28 expectations. The queryable count includes 140 flattened restriction triples: 7,629 / 87,379 / 362,879 / 725,379. Tests distinguish the 239 authored TBox triples from the 140 derived triples.
3. VP-1, VP-54 and VP-55 jointly require that the Budget never be exceeded and protected nodes never be evicted. A reduction below the protected node count is rejected, with the required minimum reported. This supersedes the contradictory VP-122 and AC-V11 overage behaviour.
4. DS-60/61, REN-285 and AC-D12/AC-A10 govern reduced motion. Compute the settled layout before presenting it and suppress decorative animation. This supersedes ARCH-116's instruction to retain continuous motion.
5. The supplied fixture is transcribed from the specification tables. The external HTML prototype remains read-only and is never executed or included in the build.
6. The provisional minimum target is Windows 11 x64, four CPU cores, 16 GB RAM, a Direct3D 11 graphics device and a 1920 by 1080 display. Performance results must identify the actual machine. This workspace currently runs Windows 10 on an AMD Threadripper 3960X with 128 GB RAM; measurements here do not certify the minimum target.
7. Requirements marked as absent from the prototype are implementation work. Prototype defects do not define successful product behaviour.
8. Source code and build scripts can prepare release packages. A trusted release signing identity and clean Windows 11 installation validation are external release prerequisites; development artifacts must not be represented as signed releases.

9. SPQ-87 uses the documented refinement: unbound FILTER operands do not pass. SPQ example defect D7 corrects the first example to use rdfs:subClassOf for NamedPizza. Fractional LIMIT values truncate toward zero; negative values are rejected.
10. The acceptance requirement that radial nodes do not overlap supersedes the multi-root origin collapse implied by LAY-180. Multiple roots receive a populated inner ring with the same 52-unit arc allowance; a single root remains at the origin. The standard three collision passes remain in place. The sixteen scale tests exposed this specification conflict.

11. Parallel edge fan offsets use the unordered pair orientation. This corrects the REN-85 formula when two edges point in opposite directions: without the orientation sign their control points coincide, violating AC-R12. A fixture-based SVG regression checks three distinct controls.
12. Export dimensions include enough width for the full caption. Raster scale is capped directly by both 9,000-pixel limits, including scenes too large for the reference minimum scale. Complete-scene export takes precedence over a minimum scale that would exceed the guard.

13. The graph uses a Win2D composition swap chain, with drawing, input and Store access on the UI thread. Its diagnostic harness counts actual graph draws and separates CPU work, draw intervals and external presentation evidence. Composition callbacks without a draw are not valid frame samples.
14. WinUI 1.8 currently loses the table-wide header array in its native UI Automation wrapper. Axiom exposes a Header row, eight HeaderItem peers, per-cell TableItem associations and LabeledBy. The native report records the remaining platform limitation explicitly; it is not a conformance pass.
15. TBL-152 governs new-individual price validation: creation and in-cell editing share the same routine, including rejection of empty values and rounding to two decimal places. Customer and rating are explicit choices, and successful creation preserves active filters.
