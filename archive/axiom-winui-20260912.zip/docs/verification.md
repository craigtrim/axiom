# Verification record

This is a working native implementation. Full specification conformance has not been established. The requirement map records implementation locations and relevant checks; its rows are not assertions that every requirement passes.

## Reproduce the checks

Run these commands from the repository root:

    dotnet test tests/Axiom.Tests -c Release --logger trx
    powershell -File scripts/verify.ps1 -Native
    powershell -File scripts/measure-frames.ps1
    dotnet run --project tools/Axiom.Benchmarks -c Release
    node scripts/traceability.mjs --check

Native checks need an interactive Windows desktop. Pass -Executable to measure-frames.ps1 to measure a published payload. The script records the executable hash and machine details with its frame report. The quick --verify mode checks rendering, export and virtualization; its off-screen samples are separate from the 600-frame harness.

Publishing explicitly copies App.xbf and Axiom.App.pri; a package can pass MSIX validation yet fail to launch if those compiled WinUI resources are omitted. Core tests also run on Linux. CI builds unsigned packages for x64 and ARM64; the separate desktop workflow requires a runner labelled axiom-desktop. These workflows have been authored locally and have not been executed by GitHub in this session.

## Evidence collected

Measurements were collected on 11 and 12 September 2026. The machine runs Windows 10 build 19045 with an AMD Threadripper 3960X, 128 GB RAM, and an NVIDIA RTX 4090 using driver 32.0.16.1088. The native windows were measured at 150 per cent display scaling. Builds use .NET 8, WinUI 3 and Win2D. This machine does not certify the provisional Windows 11 minimum in decisions.md.

| Check | Result and evidence |
| --- | --- |
| Domain suite | 150 tests pass, including fixture, query, viewport, mutations, layout, label and badge geometry, export and contrast checks. |
| Fixture | All four generated sizes match the golden data. There are 114 authored entities, 239 TBox triples and 140 flattened restriction triples. |
| Query engine | Seven worked examples, explicit parser errors, repeated variables, DISTINCT, cancellation, stable snapshots and the 200,000-solution cap have regression coverage. |
| Viewport | A deterministic 10,000-operation fuzz test verifies the hard Budget, protected nodes, edge endpoints and maintained degrees. |
| Layout and labels | Thirty-two combinations cover four layouts at 100, 500, 1,000 and 3,000 nodes, using mixed seeds and high-degree class expansions. Additional checks cover scaled labels, allocation reuse, unchanged-layout stability, and same-count viewport replacement. |
| Mutations | Creation adds the specified subclass triple without rebuilding flattened restrictions. Individual creation projects the chosen customer and rating. Invalid choices leave the Store unchanged; Undo restores counts and indexes. |
| Native automation | Fifteen journeys pass. They cover startup graph peers, table rows and header associations, sort state, editable names, invalid values, empty-state recovery, editing and Undo, distant rows, inspector links, narrow-window controls, themes, queries, creation dialogs, focus restoration and retained filters. |
| Native virtualization | The realized row window stays constant when the dataset changes from 12,000 to 100,000 records. Native Grid reports the full dataset count. |
| Native rendering | Both themes produce a 1,000-node PNG scene and full SVG export. Window screenshots use PrintWindow so they include the graph swap chain. |
| Frame harness | Three repetitions of 600 consecutive actual graph draws per scenario and theme, after 30 warmup frames. CPU work and draw intervals are reported separately. No per-method profiling occurs in timed frames. |
| Packages | Self-contained x64 and ARM64 payloads, unsigned MSIX packages and a bundle containing both architectures are built with the Windows SDK packaging validator. Version 0.1.1.0 passed 15 native journeys and native rendering/export checks from its published x64 payload. ARM64 is cross-compiled; it has not been run on ARM64 hardware. |

Detailed reports are under artifacts, with domain results in tests/Axiom.Tests/TestResults. Screenshots establish that a surface rendered; geometry assertions check placement independently.

## Native accessibility limits

WinUI 1.8 exposes an empty table-wide ColumnHeaders array in this environment even when the application provider returns all eight headers. Both the managed UI Automation client and a native COM client reproduce it. The [WinUI wrapper implementation](https://github.com/microsoft/microsoft-ui-xaml/blob/ba3b6cd989b4bac7c82791ad76a28d837bbf903b/src/dxaml/xcp/win/shared/UIAPatternProviderWrapper.cpp) releases its SAFEARRAY before filling it in CUIATableProviderWrapper::GetColumnHeaders. Per-cell TableItem header associations, LabeledBy, the Header row and all eight HeaderItem peers are verified. The native test report records the table-wide failure as a platform limitation.

Dialog validation is associated with its field and also exposed through HelpText and invalid status. Required-name errors survive WinUI's delayed focus events after a failed submission. Native journeys verify the invalid-field focus and restoration of the invoking control after a successful class creation.

Row heights and graph text metrics respond to Windows text scaling. Geometry tests exercise 100, 125, 150 and 200 per cent scale factors; the complete native operating-system matrix and Narrator review remain pending. No system text-scale preference was changed during these checks.

## Performance evidence

The computation harness uses a warmup and at least five measured repetitions. Initial medians on this machine include 1,302 ms for a fully settled 3,000-node force layout, 36 ms for hierarchy, 8 ms for radial, 3.4 ms for grid, and 145 ms for generating and indexing 100,000 orders. At 100,000 records, the Shoreditch query median was 96 ms and the customer join median was 162 ms. These are computation measurements on this host.

The untraced native frame baseline from the published 0.1.1.0 x64 payload is artifacts/frames-20260912-172336. The report includes the executable and application assembly hashes and the machine details. Each cell below is the median of three per-run p95 values, in milliseconds. The viewport was approximately 797 by 445 DIPs at 150 per cent display scaling.

| Scenario | Light CPU work | Dark CPU work | Light draw interval | Dark draw interval |
| --- | ---: | ---: | ---: | ---: |
| PB-01, force, 3,000 nodes | 16.59 | 16.54 | 20.48 | 20.37 |
| PB-02, grid, 3,000 nodes | 9.69 | 9.81 | 20.39 | 20.72 |
| PB-03, force, 1,000 nodes | 5.71 | 5.67 | 19.18 | 19.24 |

All runs contain 600 actual graph draws. The force simulation remains active, and the camera pans throughout each measurement. CPU work includes simulation, graph command submission and minimap work. The measured CPU budgets are met on this host; these values alone do not establish display completion or minimum-machine acceptance.

The former CanvasControl path had draw intervals around 64 ms at p95. Direct swap-chain presentation reduced that to roughly 19 to 21 ms in this baseline. The renderer caches glyphs and badge pills in bounded atlases; SVG and export text retain their vector paths. Earlier callback-based results in artifacts/frames-20260912-160457 counted callbacks without matching draws and are superseded. Earlier off-screen numbers also included profiling overhead; the profiler now runs in a separate untimed pass.

An independent PresentMon 2.5.1 trace targeted only the owned test process, with input tracking disabled. The downloaded binary's SHA256 was checked against the official release: 9BEC3083069F58F911E6A512F4806DB51A27BD096103087BC1D05EF54C80A191. Raw data and analysis are in artifacts/presentmon-20260912-115650, matched against artifacts/frames-20260912-165651. Reproduce the analysis with:

    node scripts/analyze-presentmon.mjs artifacts/presentmon-20260912-115650/presentmon.csv artifacts/frames-20260912-165651 47576

The analyzer matches QPC timestamps to each measured run, excludes startup and warmup, and reports each swap chain separately. PresentMon defines MsBetweenPresents as the interval between Present calls and MsBetweenDisplayChange as the previous frame's display duration. Missing values remain missing. See the [official console documentation](https://github.com/GameTechDev/PresentMon/blob/main/README-ConsoleApplication.md).

On the most active chain, the median per-run p95 Present interval was 28.13 ms for force at 3,000 nodes, 20.80 ms for grid at 3,000 nodes and 19.35 ms for force at 1,000 nodes. The corresponding display-interval values were 17.28, 16.73 and 16.73 ms. Force had p99 display intervals near 33.35 ms. The trace matched 560 to 599 presentation events per 600-draw window, so it does not establish a one-to-one presentation for every measured draw. The graph chain is inferred by event frequency; its native address is not instrumented in the application. Traced and untraced runs remain separate because ETW collection can affect timings. Presentation acceptance remains open.

The synthetic label microbenchmark cannot certify native text measurement. Cold start, first drawable force frame, table fling, export encoding at both scales, theme latency and the one-hour memory soak still need the complete specified measurements.

## Outstanding acceptance work

1. A requirement-by-requirement conformance audit, including exact UI copy, every component state, token usage and the complete acceptance tables. The generated map provides locations for that audit.
2. The full accessibility matrix: all keyboard journeys and dialogs, focus indicators, both themes, high contrast, reduced motion, Narrator and native Windows text scaling.
3. Performance budgets on the agreed minimum machine, including presentation cadence and the remaining timing and memory measurements. No target has been relaxed.
4. Trusted release signing and clean, offline Windows 11 installation and launch. No certificate has been created or installed. Current packages are unsigned development artifacts.
5. Independent opening of PNG and SVG exports and clipboard paste in the required third-party applications.

OWL import, OWL serialization, reasoning, workspace persistence and networking are outside the v1 specification. Save and inferred-axiom controls state those boundaries in the product.

## Requirement map

Run node scripts/traceability.mjs to regenerate docs/traceability.csv. The generator extracts all 2,377 numbered declarations from the normative Markdown documents, rejects duplicate IDs, checks mapped files and records each statement with its source line. The visual reference declares no numbered VIS requirements.

Every row starts as mapped with individual conformance audit pending. Mapping does not satisfy IMP-29 or ACC-10 by itself. Specification conflicts are recorded in decisions.md.
