using System.Runtime.InteropServices;
namespace Axiom.UiTests;

// The COM client reads pattern methods directly. The older managed UIA client
// reads Table header properties instead; keep the two paths distinguishable.
internal static class NativeTableProbe
{
    public static int HeaderCount(nint window)
    {
        var client = (Client)Activator.CreateInstance(Type.GetTypeFromCLSID(new("ff48dba4-60ef-4201-aa87-54103eef594e"))!)!;
        var root = client.ElementFromHandle(window);
        var condition = client.CreatePropertyCondition(30012, "AxiomVirtualGrid");
        var grid = root.FindFirst(4, condition);
        var table = (Table)grid.GetCurrentPattern(10012);
        var headers = table.GetCurrentColumnHeaders();
        return headers?.Length ?? 0;
    }
    [ComImport, Guid("30cbe57d-d9d0-452a-ab13-7ac5ac4825ee"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface Client
    {
        void CompareElements(); void CompareRuntimeIds(); void GetRootElement();
        Element ElementFromHandle(nint hwnd);
        void ElementFromPoint(); void GetFocusedElement(); void GetRootElementBuildCache();
        void ElementFromHandleBuildCache(); void ElementFromPointBuildCache(); void GetFocusedElementBuildCache();
        void CreateTreeWalker(); void ControlViewWalker(); void ContentViewWalker(); void RawViewWalker();
        void RawViewCondition(); void ControlViewCondition(); void ContentViewCondition(); void CreateCacheRequest();
        void CreateTrueCondition(); void CreateFalseCondition();
        [return: MarshalAs(UnmanagedType.Interface)]
        object CreatePropertyCondition(int property, [MarshalAs(UnmanagedType.Struct)] object value);
    }
    [ComImport, Guid("d22108aa-8ac5-49a5-837b-37bbb3d7591e"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface Element
    {
        void SetFocus(); void GetRuntimeId();
        Element FindFirst(int scope, [MarshalAs(UnmanagedType.Interface)] object condition);
        void FindAll(); void FindFirstBuildCache(); void FindAllBuildCache(); void BuildUpdatedCache();
        void GetCurrentPropertyValue(); void GetCurrentPropertyValueEx(); void GetCachedPropertyValue(); void GetCachedPropertyValueEx();
        void GetCurrentPatternAs(); void GetCachedPatternAs();
        [return: MarshalAs(UnmanagedType.IUnknown)] object GetCurrentPattern(int pattern);
    }
    [ComImport, Guid("620e691c-ea96-4710-a850-754b24ce2417"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface Table
    {
        ElementArray GetCurrentRowHeaders();
        ElementArray GetCurrentColumnHeaders();
    }
    [ComImport, Guid("14314595-b4bc-4055-95f2-58f2e42c9855"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface ElementArray
    {
        int Length
        {
            get;
        }
        Element GetElement(int index);
    }
}
