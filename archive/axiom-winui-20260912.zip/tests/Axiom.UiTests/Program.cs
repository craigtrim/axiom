using System.IO;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows.Automation;
namespace Axiom.UiTests;
public static class Program
{
    [DllImport("user32.dll")] private static extern uint GetDpiForWindow(nint window);
    [DllImport("user32.dll")] private static extern bool PrintWindow(nint window, nint dc, uint flags);
    [DllImport("user32.dll")] private static extern bool GetWindowRect(nint window, out RECT rect);
    [StructLayout(LayoutKind.Sequential)]
    private struct RECT
    {
        public int Left, Top, Right, Bottom;
    }
    [STAThread]
    public static int Main(string[] args)
    {
        if (args.Length == 0)
        {
            Console.Error.WriteLine("Pass the full path to Axiom.App.exe.");
            return 2;
        }
        Directory.CreateDirectory("artifacts");
        var checks = new List<string>();
        var limitations = new List<string>();
        Process? process = null;
        try
        {
            process = Process.Start(new ProcessStartInfo(args[0]) { UseShellExecute = true, WindowStyle = ProcessWindowStyle.Hidden, Arguments = "--ui-test" })!;
            var watch = Stopwatch.StartNew();
            while (process.MainWindowHandle == 0 && watch.ElapsedMilliseconds < 15000)
            {
                Thread.Sleep(100);
                process.Refresh();
                if (process.HasExited)
                    throw new Exception("Application exited before creating a window.");
            }
            if (process.MainWindowHandle == 0)
                throw new Exception("No application window appeared.");
            var window = AutomationElement.FromHandle(process.MainWindowHandle);
            Thread.Sleep(1500);
            AutomationElement Find(string name, ControlType? type = null)
            {
                var condition = type == null ? (Condition)new PropertyCondition(AutomationElement.NameProperty, name) : new AndCondition(new PropertyCondition(AutomationElement.NameProperty, name), new PropertyCondition(AutomationElement.ControlTypeProperty, type));
                if (name == "Graph viewport")
                    condition = new PropertyCondition(AutomationElement.ClassNameProperty, "AxiomGraph");
                return window.FindFirst(TreeScope.Descendants, condition) ?? throw new Exception("Missing UIA element: " + name);
            }
            void Click(string name)
            {
                var control = Find(name);
                ((InvokePattern)control.GetCurrentPattern(InvokePattern.Pattern)).Invoke();
                Thread.Sleep(300);
            }
            _ = Find("Ontology hierarchy");
            _ = Find("Graph viewport");
            _ = Find("Filter individuals");
            _ = Find("Fit graph (F)");
            _ = Find("Viewport budget");
            checks.Add("All primary surfaces expose native automation elements.");
            var graph = Find("Graph viewport");
            var nodes = graph.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ClassNameProperty, "AxiomGraphNode"));
            if (nodes.Count != 17)
                throw new Exception("Expected the default 17-node Pizza neighbourhood; got " + nodes.Count + ". Visible text: " + string.Join(" | ", window.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Text)).Cast<AutomationElement>().Select(e => e.Current.Name)));
            checks.Add($"Graph exposes {nodes.Count} navigable node peers.");
            var node = nodes[0];
            ((SelectionItemPattern)node.GetCurrentPattern(SelectionItemPattern.Pattern)).Select();
            checks.Add("Graph node selection is available through UI Automation.");
            var table = window.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.ClassNameProperty, "AxiomVirtualGrid")) ?? throw new Exception("Missing grid peer.");
            var cells = table.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ClassNameProperty, "AxiomGridCell"));
            if (cells.Count < 8 || cells.Count % 8 != 0)
                throw new Exception("Virtual grid sibling enumeration is incomplete: " + cells.Count);
            var grid = (GridPattern)table.GetCurrentPattern(GridPattern.Pattern);
            if (grid.Current.RowCount != 12000 || grid.Current.ColumnCount != 8)
                throw new Exception("Wrong native table shape.");
            if (table.Current.Name != "Individuals")
                throw new Exception("The individuals grid has the wrong accessible name.");
            var nativeRows = table.FindAll(TreeScope.Children, new PropertyCondition(AutomationElement.ClassNameProperty, "AxiomGridRow"));
            if (nativeRows.Count == 0 || nativeRows.Count * 8 != cells.Count)
                throw new Exception("Cells are not grouped into the realized native rows.");
            var tableHeaderCount = NativeTableProbe.HeaderCount(process.MainWindowHandle);
            if (tableHeaderCount == 0)
                limitations.Add("WinUI 1.8 returns an empty table-wide ColumnHeaders array. Header rows, per-cell TableItem associations and LabeledBy remain available.");
            else if (tableHeaderCount != 8)
                throw new Exception("The native table-wide header count is incorrect: " + tableHeaderCount);
            var headers = table.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ClassNameProperty, "AxiomColumnHeader")).Cast<AutomationElement>().ToArray();
            if (headers.Length != 8 || headers.Any(h => h.Current.ControlType != ControlType.HeaderItem))
                throw new Exception("The table does not expose eight column headers: " + headers.Length + "; COM=" + NativeTableProbe.HeaderCount(process.MainWindowHandle) + "; native=" + table.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ClassNameProperty, "AxiomColumnHeader")).Count + "; " + string.Join(" | ", headers.Select(h => h.Current.Name + ":" + h.Current.ControlType.ProgrammaticName + ":" + h.Current.ClassName)));
            var priceHeader = headers.Single(h => h.Current.Name == "Price");
            ((InvokePattern)priceHeader.GetCurrentPattern(InvokePattern.Pattern)).Invoke();
            Thread.Sleep(150);
            headers = table.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ClassNameProperty, "AxiomColumnHeader")).Cast<AutomationElement>().ToArray();
            if (headers.Single(h => h.Current.Name == "Price").Current.ItemStatus != "ascending" || headers.Count(h => h.Current.ItemStatus != "none") != 1)
                throw new Exception("Column sort state is not exposed correctly.");
            var associated = ((TableItemPattern)grid.GetItem(0, 4).GetCurrentPattern(TableItemPattern.Pattern)).Current.GetColumnHeaderItems();
            if (associated.Length != 1 || associated[0].Current.Name != "Price")
                throw new Exception("A cell cannot resolve its column header.");
            ((InvokePattern)headers.Single(h => h.Current.Name == "Individual").GetCurrentPattern(InvokePattern.Pattern)).Invoke();
            Thread.Sleep(150);
            if (!grid.GetItem(0, 4).Current.Name.EndsWith(", editable") || grid.GetItem(0, 0).Current.IsKeyboardFocusable)
                throw new Exception("Cell names or keyboard focusability violate the table contract.");
            checks.Add("Native rows, Table and TableItem patterns, column-header roles and sort state are exposed.");

            ((ValuePattern)Find("Filter individuals").GetCurrentPattern(ValuePattern.Pattern)).SetValue("no_such_individual_7593");
            Thread.Sleep(400);
            if (grid.Current.RowCount != 0)
                throw new Exception("The empty filter result still reports rows.");
            Click("Reset filters");
            if (grid.Current.RowCount != 12000)
                throw new Exception("Empty-state recovery did not restore all rows.");
            checks.Add("The empty state offers Reset filters and restores the full dataset.");

            try
            {
                ((ValuePattern)grid.GetItem(0, 4).GetCurrentPattern(ValuePattern.Pattern)).SetValue("700");
            }
            catch (Exception) { /* Invalid input is rejected by the provider. */ }
            if (!grid.GetItem(0, 4).Current.ItemStatus.StartsWith("Invalid: "))
                throw new Exception("The rejected price does not expose an invalid accessible state.");
            checks.Add("Invalid cell values expose their error to assistive technology.");
            var price = grid.GetItem(0, 4);
            var value = (ValuePattern)price.GetCurrentPattern(ValuePattern.Pattern);
            var original = value.Current.Value;
            value.SetValue("12.34");
            Thread.Sleep(150);
            if (((ValuePattern)grid.GetItem(0, 4).GetCurrentPattern(ValuePattern.Pattern)).Current.Value != "£12.34")
                throw new Exception("Cell edit did not update the Store.");
            Click("Undo (Ctrl+Z)");
            if (((ValuePattern)grid.GetItem(0, 4).GetCurrentPattern(ValuePattern.Pattern)).Current.Value != original)
                throw new Exception("Undo did not restore the cell.");
            var distant = grid.GetItem(11999, 0);
            ((VirtualizedItemPattern)distant.GetCurrentPattern(VirtualizedItemPattern.Pattern)).Realize();
            checks.Add("Native Grid and Value patterns edit, undo and realize a distant virtual row.");
            ((InvokePattern)grid.GetItem(0, 0).GetCurrentPattern(InvokePattern.Pattern)).Invoke();
            Thread.Sleep(300);
            ((InvokePattern)Find("pizza:Rosa", ControlType.Hyperlink).GetCurrentPattern(InvokePattern.Pattern)).Invoke();
            Thread.Sleep(300);
            Click("Page instances into the graph");
            checks.Add("Table reveal, inspector axiom navigation, and additive instance paging work through native automation.");
            var bounds = window.Current.BoundingRectangle;
            var scale = GetDpiForWindow(process.MainWindowHandle) / 96d;
            var transform = (TransformPattern)window.GetCurrentPattern(TransformPattern.Pattern);
            transform.Resize(1000 * scale, bounds.Height);
            Thread.Sleep(450);
            var collapsedInspector = window.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, "Entity inspector"));
            if (collapsedInspector != null && !collapsedInspector.Current.IsOffscreen)
                throw new Exception("The inspector did not collapse at the narrow breakpoint.");
            var narrowBounds = window.Current.BoundingRectangle;
            foreach (var name in new[] { "New individual", "Fit graph (F)", "Viewport budget", "Send page to graph", "Filter individuals" })
            {
                var controlBounds = Find(name).Current.BoundingRectangle;
                if (controlBounds.Width <= 0 || controlBounds.Right > narrowBounds.Right + 1 || controlBounds.Left < narrowBounds.Left - 1)
                    throw new Exception("A control is clipped in the narrow layout: " + name);
            }
            Screenshot(process.MainWindowHandle, "artifacts/native-narrow.png");
            transform.Resize(bounds.Width, bounds.Height);
            Thread.Sleep(450);
            if (Find("Entity inspector").Current.IsOffscreen)
                throw new Exception("The inspector did not return when the window widened.");
            checks.Add("Narrow windows wrap controls and restore the inspector when widened.");
            var theme = window.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button)).Cast<AutomationElement>().Single(e => e.Current.Name.StartsWith("Switch to "));
            var themeName = theme.Current.Name;
            Click(themeName);
            Click(themeName == "Switch to light theme" ? "Switch to dark theme" : "Switch to light theme");
            checks.Add("Both themes switch without an application error.");
            Click("SPARQL");
            _ = Find("SPARQL query editor");
            Click("Run query (Ctrl+Enter)");
            Thread.Sleep(600);
            var text = window.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Text)).Cast<AutomationElement>().Select(e => e.Current.Name).ToArray();
            if (!text.Any(t => t.Contains("103 rows")))
                throw new Exception("Default query did not expose its expected 103-row result.");
            checks.Add("Corrected NamedPizza example returns 103 rows in the native console.");
            Click("Individuals");
            checks.AddRange(DialogJourneys.Run(window));
            Click("Save");
            checks.Add("Save explicitly presents the unimplemented OWL serialization boundary.");
            Screenshot(process.MainWindowHandle, "artifacts/native-window.png");
            File.WriteAllText("artifacts/ui-automation.json", JsonSerializer.Serialize(new
            {
                Passed = true,
                Checks = checks,
                PlatformLimitations = limitations,
                OS = Environment.OSVersion.ToString(),
                Date = DateTimeOffset.UtcNow
            }, new JsonSerializerOptions { WriteIndented = true }));
            Console.WriteLine($"Passed {checks.Count} native automation checks.");
            return 0;
        }
        catch (Exception ex) { if (process != null && process.MainWindowHandle != 0) Screenshot(process.MainWindowHandle, "artifacts/native-window.png"); File.WriteAllText("artifacts/ui-automation.json", JsonSerializer.Serialize(new { Passed = false, Checks = checks, Error = ex.ToString() }, new JsonSerializerOptions { WriteIndented = true })); Console.Error.WriteLine(ex); return 1; }
        finally { if (process != null && !process.HasExited) { process.CloseMainWindow(); if (!process.WaitForExit(5000)) process.Kill(); } process?.Dispose(); }
    }
    private static void Screenshot(nint window, string path)
    {
        if (!GetWindowRect(window, out var r))
            return;
        using var bitmap = new Bitmap(r.Right - r.Left, r.Bottom - r.Top);
        using (var graphics = Graphics.FromImage(bitmap))
        {
            var dc = graphics.GetHdc();
            try
            {
                PrintWindow(window, dc, 2);
            }
            finally { graphics.ReleaseHdc(dc); }
        }
        bitmap.Save(path, System.Drawing.Imaging.ImageFormat.Png);
    }
}
