using System.Diagnostics;
using System.Windows.Automation;

namespace Axiom.UiTests;

internal static class DialogJourneys
{
    internal static IEnumerable<string> Run(AutomationElement window)
    {
        AutomationElement Find(string name, ControlType? type = null) =>
            window.FindFirst(TreeScope.Descendants, type == null
                ? new PropertyCondition(AutomationElement.NameProperty, name)
                : new AndCondition(new PropertyCondition(AutomationElement.NameProperty, name), new PropertyCondition(AutomationElement.ControlTypeProperty, type)))
            ?? throw new Exception("Missing dialog element: " + name);
        AutomationElement Field(string label) => window.FindFirst(TreeScope.Descendants,
            new PropertyCondition(AutomationElement.AutomationIdProperty, "DialogField:" + label))
            ?? throw new Exception("Missing dialog field: " + label);
        void Click(string name)
        {
            ((InvokePattern)Find(name, ControlType.Button).GetCurrentPattern(InvokePattern.Pattern)).Invoke();
            Thread.Sleep(250);
        }
        static string Value(AutomationElement e) => ((ValuePattern)e.GetCurrentPattern(ValuePattern.Pattern)).Current.Value;
        static void Set(AutomationElement e, string value) => ((ValuePattern)e.GetCurrentPattern(ValuePattern.Pattern)).SetValue(value);
        static string Choice(AutomationElement e) => ((SelectionPattern)e.GetCurrentPattern(SelectionPattern.Pattern)).Current.GetSelection().Single().Current.Name;
        void Choose(AutomationElement e, string? name = null)
        {
            ((ExpandCollapsePattern)e.GetCurrentPattern(ExpandCollapsePattern.Pattern)).Expand();
            Thread.Sleep(200);
            var options = e.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.ListItem)).Cast<AutomationElement>().ToArray();
            if (options.Length == 0)
                options = window.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.ListItem)).Cast<AutomationElement>().ToArray();
            var option = name == null ? options.Skip(1).First() : options.Single(o => o.Current.Name == name);
            ((SelectionItemPattern)option.GetCurrentPattern(SelectionItemPattern.Pattern)).Select();
            ((ExpandCollapsePattern)e.GetCurrentPattern(ExpandCollapsePattern.Pattern)).Collapse();
            Thread.Sleep(150);
        }
        static void Wait(Func<bool> ready, string message)
        {
            var timer = Stopwatch.StartNew();
            while (timer.ElapsedMilliseconds < 5000)
            {
                if (ready())
                    return;
                Thread.Sleep(100);
            }
            throw new Exception(message);
        }

        var createClass = Find("New class", ControlType.Button);
        createClass.SetFocus();
        Click("New class");
        var name = Field("Class name");
        if (!name.Current.IsRequiredForForm || !name.Current.HasKeyboardFocus)
            throw new Exception("New class must focus and identify its required name field.");
        Click("Create class");
        if (name.Current.HelpText != "A name is required.")
            throw new Exception("Name validation was not exposed: " + name.Current.HelpText);
        if (!name.Current.HasKeyboardFocus)
            throw new Exception("Invalid class name did not retain keyboard focus.");
        Set(name, "UiPreviewClass");
        Click("Create class");
        Wait(() => window.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.AutomationIdProperty, "DialogField:Class name")) == null, "The class dialog did not close.");
        if (!createClass.Current.HasKeyboardFocus)
            throw new Exception("Closing the class dialog did not restore its invoking control.");
        Wait(() => window.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ClassNameProperty, "AxiomGraphNode")).Cast<AutomationElement>().Any(n => n.Current.AutomationId.EndsWith("#UiPreviewClass")), "New class was not revealed in the graph.");
        Click("Undo (Ctrl+Z)");
        yield return "Class creation validates its name, reveals the class, restores focus, and supports Undo.";

        var table = window.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.ClassNameProperty, "AxiomVirtualGrid"))!;
        var grid = (GridPattern)table.GetCurrentPattern(GridPattern.Pattern);
        Click("New individual");
        var price = Field("Price, GBP");
        if (Value(price) != "11.50" || Choice(Field("Branch")) != "Soho" || Choice(Field("Rating")) != "5")
            throw new Exception("New individual defaults differ from the specification.");
        Set(price, "-1");
        Click("Create individual");
        if (price.Current.HelpText != "Price cannot be negative.")
            throw new Exception("Price validation was not exposed: " + price.Current.HelpText);
        if (!price.Current.HasKeyboardFocus || grid.Current.RowCount != 12000)
            throw new Exception("Invalid price changed the table or failed to focus the field.");
        Set(price, "12.34");
        Choose(Field("Rating"), "4");
        var customer = Field("Customer");
        var originalCustomer = Choice(customer);
        Choose(customer);
        var chosenCustomer = Choice(customer);
        if (chosenCustomer == originalCustomer)
            throw new Exception("The customer choice did not change.");
        Click("Create individual");
        Wait(() => grid.Current.RowCount == 12001, "Created individual did not appear in the table.");
        if (Value(grid.GetItem(12000, 4)) != "£12.34" || Value(grid.GetItem(12000, 5)) != "4 / 5" || Value(grid.GetItem(12000, 7)) != chosenCustomer)
            throw new Exception("The table did not receive the chosen price, rating and customer.");
        Click("Undo (Ctrl+Z)");
        Wait(() => grid.Current.RowCount == 12000, "Undo did not remove the created individual.");
        yield return "Individual creation validates price and preserves the selected rating and customer through the Store and table.";

        var branch = Find("Filter by branch", ControlType.ComboBox);
        Choose(branch, "Camden");
        var filteredCount = grid.Current.RowCount;
        Click("New individual");
        Click("Create individual");
        if (Choice(branch) != "Camden" || grid.Current.RowCount != filteredCount)
            throw new Exception("Creation reset the existing branch filter.");
        Click("Undo (Ctrl+Z)");
        if (Choice(branch) != "Camden" || grid.Current.RowCount != filteredCount)
            throw new Exception("Creation Undo reset the existing branch filter.");
        Click("Reset");
        yield return "Creation and Undo preserve active table filters.";
    }
}
