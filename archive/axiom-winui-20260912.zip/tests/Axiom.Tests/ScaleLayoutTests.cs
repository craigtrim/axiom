using Axiom.Core;
using Axiom.Fixture;
using Xunit;
namespace Axiom.Tests;
public class ScaleLayoutTests
{
    public static IEnumerable<object[]> Cases() => new[] { "force", "hierarchy", "radial", "grid" }.SelectMany(mode => new[] { 100, 500, 1000, 3000 }.Select(n => new object[] { mode, n }));
    [Theory]
    [MemberData(nameof(Cases))]
    public void Expanded_class_neighbourhoods_have_no_node_overlap(string mode, int count)
    {
        var store = PizzaFixture.Build(100000);
        var view = new Viewport(store);
        view.SetBudget(count);
        view.Seed([Ns.Pizza + "Margherita"], expand: false);
        view.Expand(Ns.Pizza + "Margherita", count - 1);
        Assert.Equal(count, view.Nodes.Count);
        var layout = new Layouts(view, store) { Choice = mode };
        layout.Run(true, true);
        var nodes = view.OrderedNodes.ToArray();
        for (var i = 0; i < nodes.Length; i++)
            for (var j = i + 1; j < nodes.Length; j++)
            {
                var a = nodes[i];
                var b = nodes[j];
                var dx = a.X - b.X;
                var dy = a.Y - b.Y;
                var radius = a.Radius + b.Radius;
                Assert.True(dx * dx + dy * dy >= radius * radius - .01, $"{mode}/{count}: {Ns.Local(a.Iri)} overlaps {Ns.Local(b.Iri)}.");
            }
    }
    [Theory]
    [MemberData(nameof(Cases))]
    public void RG01_RG02_NoNodeOrLabelOverlapAtSupportedScales(string mode, int count)
    {
        var s = PizzaFixture.Build(12000);
        var v = new Viewport(s);
        v.SetBudget(3000);
        var iris = s.Entities.Keys.Concat(s.Individuals.Select(i => i.Iri)).Take(count).ToArray();
        v.Seed(iris, expand: false);
        var layout = new Layouts(v, s) { Choice = mode };
        layout.Run(true, true);
        var nodes = v.OrderedNodes.ToArray();
        for (var i = 0; i < nodes.Length; i++)
            for (var j = i + 1; j < nodes.Length; j++)
            {
                var a = nodes[i];
                var b = nodes[j];
                var dx = a.X - b.X;
                var dy = a.Y - b.Y;
                var radius = a.Radius + b.Radius;
                Assert.True(dx * dx + dy * dy >= radius * radius - .01, $"{mode}/{count}: {Ns.Local(a.Iri)} overlaps {Ns.Local(b.Iri)} by {radius - Math.Sqrt(dx * dx + dy * dy):F2}.");
            }
        using var d = new SvgDraw(1600, 1000, (t, size, _, _) => t.Length * size * .55);
        var labels = SceneRenderer.Labels(d, v, Camera.Fit(v, 1600, 1000), 1600, 1000, null);
        Assert.InRange(labels.Count, 0, 900);
        for (var i = 0; i < labels.Count; i++)
            for (var j = i + 1; j < labels.Count; j++)
                Assert.False(labels[i].Bounds.Intersects(labels[j].Bounds));
    }
}
