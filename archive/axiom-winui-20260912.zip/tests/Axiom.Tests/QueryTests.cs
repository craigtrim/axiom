using Axiom.Core;
using Axiom.Fixture;
using Xunit;
namespace Axiom.Tests;
public class QueryTests
{
    [Theory]
    [InlineData(0, 103, 103)]
    [InlineData(1, 5, 5)]
    [InlineData(2, 21, 21)]
    [InlineData(3, 100, 626)]
    [InlineData(4, 150, 3455)]
    [InlineData(5, 5, 5)]
    [InlineData(6, 500, 1940)]
    public void SevenExamplesReturnSpecifiedAnswers(int index, int rows, int total)
    {
        var s = PizzaFixture.Build();
        var result = new QueryEngine(s).Execute(QueryExamples.All[index].Text);
        Assert.Equal(rows, result.Rows.Count);
        Assert.Equal(total, result.Total);
        Assert.False(result.Capped);
        Assert.Equal(s.Version, result.StoreVersion);
    }
    [Fact]
    public void DEF_PrefixOverrideAndLessThanDoNotConsumeLaterTerms()
    {
        var s = PizzaFixture.Build(1000);
        var engine = new QueryEngine(s);
        var result = engine.Execute("PREFIX p: <http://example.org/pizzeria#> SELECT ?s ?v WHERE { ?s p:rating ?v FILTER (?v < 3) FILTER (?v > 1) }");
        Assert.All(result.Rows, r => Assert.Equal("2", r[1].Value));
        Assert.NotEmpty(result.Rows);
        Assert.NotEmpty(engine.Execute("PREFIX pizza: <http://example.org/pizzeria#> SELECT ?s WHERE { ?s pizza:rating 5 }").Rows);
    }
    [Fact]
    public void DEF_RepeatedVariablesUnifyWithinPattern()
    {
        var s = PizzaFixture.Build(1000);
        var result = new QueryEngine(s).Execute("SELECT ?x WHERE { ?x ?p ?x }");
        Assert.Empty(result.Rows);
        var all = new QueryEngine(s).Execute("SELECT ?x WHERE { ?x ?x ?x }");
        Assert.Empty(all.Rows);
    }
    [Fact]
    public void DEF_CapDoesNotDiscardOtherSolutionsInLaterPatterns()
    {
        var s = PizzaFixture.Build(1000);
        var result = new QueryEngine(s).Execute("SELECT ?s ?r WHERE { ?s ?p ?o . ?s demo:rating ?r }", solutionCap: 1500);
        Assert.True(result.Capped);
        Assert.True(result.Rows.Count > 100);
        Assert.All(result.Rows, r => Assert.True(s.IndividualIndex.ContainsKey(r[0].Value)));
    }
    [Fact]
    public void DEF_CapRegressionAt100000Records()
    {
        var result = new QueryEngine(PizzaFixture.Build(100000)).Execute("SELECT ?s ?o ?r WHERE { ?s ?p ?o . ?s demo:rating ?r }");
        Assert.True(result.Capped);
        Assert.Equal(187121, result.Rows.Count);
    }
    [Fact]
    public void DEF_LimitZeroNegativeAndFractional()
    {
        var e = new QueryEngine(PizzaFixture.Build(1000));
        const string q = "SELECT ?s WHERE { ?s demo:rating 5 }";
        var zero = e.Execute(q + " LIMIT 0");
        Assert.Empty(zero.Rows);
        Assert.Equal(313, zero.Total);
        Assert.Equal(3, e.Execute(q + " LIMIT 3.7").Rows.Count);
        var error = Assert.Throws<QueryException>(() => e.Execute(q + " LIMIT -5"));
        Assert.Contains("LIMIT", error.Hint);
    }
    [Theory]
    [InlineData("ASK { ?s ?p ?o }")]
    [InlineData("SELECT ?s { ?s ?p ?o }")]
    [InlineData("SELECT ?s WHERE { ?s demo:rating 5; demo:branch ?b }")]
    [InlineData("SELECT ?s WHERE { ?s A pizza:Pizza }")]
    [InlineData("SELECT ?missing WHERE { ?s ?p ?o }")]
    [InlineData("SELECT ?s WHERE { OPTIONAL { ?s ?p ?o } }")]
    [InlineData("SELECT ?s WHERE { ?s ?p ?o } OFFSET 3")]
    public void UnsupportedGrammarHasCauseAndRemedy(string text)
    {
        var error = Assert.Throws<QueryException>(() => QueryParser.Parse(text));
        Assert.NotEmpty(error.Message);
        Assert.NotEmpty(error.Hint);
    }
    [Fact]
    public void DistinctAndLiteralEqualityRespectTermKind()
    {
        var s = PizzaFixture.Build(1000);
        var e = new QueryEngine(s);
        Assert.Equal(e.Execute("SELECT ?s WHERE { ?s demo:rating 5 }").Rows.Count, e.Execute("SELECT ?s WHERE { ?s demo:rating \"5\" }").Rows.Count);
        Assert.False(new Term("5").Equivalent(Term.Literal("5")));
        Assert.Equal(6, e.Execute("SELECT DISTINCT ?branch WHERE { ?s demo:branch ?branch }").Rows.Count);
        Assert.Empty(e.Execute("SELECT ?s WHERE { ?s demo:rating 5 FILTER (?missing != 1) }").Rows);
    }
    [Fact]
    public void SnapshotRetainsVersionAndValuesAcrossEditsAndRegeneration()
    {
        var s = PizzaFixture.Build(1000);
        var old = s.Individuals[0].Price;
        var snapshot = s.QuerySnapshot();
        var version = snapshot.Version;
        Assert.Null(s.EditCell(s.Individuals[0].Iri, "price", "400"));
        var generated = PizzaFixture.Generate(12000);
        s.LoadGenerated(generated.Individuals, generated.Customers);
        Assert.Equal(1000, snapshot.Individuals.Count);
        Assert.Equal(old, snapshot.Individuals[0].Price);
        Assert.Equal(version, snapshot.Version);
        Assert.Equal(snapshot.TripleCount, snapshot.Scan().LongCount());
    }
    [Fact]
    public void CancellationStopsLargeJoins()
    {
        using var c = new CancellationTokenSource();
        c.Cancel();
        Assert.Throws<OperationCanceledException>(() => new QueryEngine(PizzaFixture.Build(1000)).Execute("SELECT * WHERE { ?s ?p ?o }", c.Token));
    }
}
