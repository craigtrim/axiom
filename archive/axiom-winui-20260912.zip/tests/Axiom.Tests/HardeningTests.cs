using Axiom.Core;
using Axiom.Fixture;
using Xunit;
namespace Axiom.Tests;
public class HardeningTests
{
    [Fact]
    public void DEF10_FrameFailureIsObservableAndNextFrameStillRuns()
    {
        var guard = new FrameGuard();
        var failures = 0;
        guard.Failed += _ => failures++;
        Assert.False(guard.Run(() => throw new InvalidOperationException("Device unavailable.")));
        var completed = false;
        Assert.True(guard.Run(() => completed = true));
        Assert.True(completed);
        Assert.Equal(1, failures);
        Assert.Null(guard.LastError);
    }
    [Fact]
    public void ThemeKeysAreIdenticalAndEssentialGraphicsPassContrast()
    {
        Assert.Equal(DesignTokens.Values("light").Keys.Order(), DesignTokens.Values("dark").Keys.Order());
        foreach (var dark in new[] { false, true })
            foreach (var key in new[] { "e-class", "e-defined", "e-individual", "e-objprop", "e-dataprop", "stroke-strong" })
                Assert.True(DesignTokens.Contrast(DesignTokens.Colour(key, dark), DesignTokens.Colour("canvas", dark)) >= 3, key);
    }
    [Fact]
    public void DEF15_16_CappedExpansionRemainsIncompleteAndAdmissionDeduplicates()
    {
        var store = PizzaFixture.Build(100000);
        var view = new Viewport(store);
        view.SetBudget(100);
        view.Seed([Ns.Demo + "Order"], expand: false);
        view.Expand(Ns.Demo + "Order");
        Assert.False(view.Nodes[Ns.Demo + "Order"].Expanded);
        Assert.True(view.Nodes[Ns.Demo + "Order"].Hidden > 90000);
        view.Clear();
        var iri = store.Individuals[0].Iri;
        var added = view.Admit([iri, iri, iri]);
        Assert.Equal(1, added.Added);
        Assert.Single(view.Nodes);
    }
    [Fact]
    public void DEF17_LinkingBeyondTheNeighbourCapWorksAcrossBatches()
    {
        var store = PizzaFixture.Build(100000);
        var view = new Viewport(store);
        var iri = store.Individuals[99999].Iri;
        view.Admit([Ns.Demo + "Order"]);
        view.Admit([iri]);
        Assert.Contains(new EdgeKey(iri, Ns.Type, Ns.Demo + "Order"), view.Edges.Keys);
    }
    [Fact]
    public void DEF22_DistinctKeysDoNotConcatenateAmbiguously()
    {
        var store = new Store();
        var subject = Ns.Demo + "s";
        store.TBox.AddRange([new(subject, Ns.Demo + "a", Term.Literal("ab")), new(subject, Ns.Demo + "a", Term.Literal("a")), new(subject, Ns.Demo + "b", Term.Literal("c")), new(subject, Ns.Demo + "b", Term.Literal("bc"))]);
        store.RebuildSchemaIndexes();
        Assert.Equal(4, new QueryEngine(store).Execute("SELECT DISTINCT ?a ?b WHERE { demo:s demo:a ?a . demo:s demo:b ?b }").Rows.Count);
    }
}
