using Axiom.Core;
using Xunit;
namespace Axiom.Tests;
public class QueryErrorTests
{
    [Theory]
    [InlineData("ASK", "Only SELECT queries are supported.", "Start the query with SELECT, or pick an example from the right.")]
    [InlineData("SELECT WHERE", "SELECT needs at least one variable.", "For example: SELECT ?pizza ?topping")]
    [InlineData("SELECT ?s {", "Expected WHERE after the projection.", "The shape is: SELECT ?x WHERE { ... }")]
    [InlineData("SELECT ?s WHERE", "Expected “{” but found the end of the query.", "Check the braces and the dot at the end of each triple pattern.")]
    [InlineData("SELECT ?s WHERE x", "Expected “{” but found “x”.", "Check the braces and the dot at the end of each triple pattern.")]
    [InlineData("PREFIX x:", "Malformed PREFIX declaration.", "Write it as: PREFIX pizza: <http://www.co-ode.org/ontologies/pizza/pizza.owl#>")]
    [InlineData("SELECT ?s WHERE { ?s xx:p ?o }", "Unknown prefix “xx:”.", "Declare it with PREFIX, or use one of: pizza: demo: rdf: rdfs: owl: xsd:")]
    [InlineData("SELECT ?s WHERE { ?s ?p", "The pattern ends too early.", "Every triple pattern needs a subject, a predicate and an object.")]
    [InlineData("SELECT ?s WHERE { ?s ?p ?o FILTER (?o ! 5) }", "FILTER needs a comparison operator.", "Supported: = != < <= > >=")]
    [InlineData("SELECT ?s WHERE { ?s ?p ?o } ORDER BY", "ORDER BY needs a variable.", "For example: ORDER BY DESC(?price)")]
    [InlineData("SELECT ?s WHERE { ?s ?p ?o } LIMIT", "LIMIT needs a number.", "For example: LIMIT 100")]
    [InlineData("SELECT ?s WHERE {}", "The WHERE block has no triple patterns.", "Add at least one, for example: ?pizza a pizza:NamedPizza .")]
    [InlineData("SELECT ?missing WHERE { ?s ?p ?o }", "Variable ?missing is selected but never bound in the WHERE block.", "Either bind it in a pattern, or remove it from SELECT.")]
    public void RequiredCauseAndRemedyAreVerbatim(string query, string message, string hint)
    {
        var error = Assert.Throws<QueryException>(() => QueryParser.Parse(query));
        Assert.Equal(message, error.Message);
        Assert.Equal(hint, error.Hint);
    }
}
