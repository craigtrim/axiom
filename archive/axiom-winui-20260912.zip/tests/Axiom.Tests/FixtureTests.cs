using Axiom.Core;
using Axiom.Fixture;
using Xunit;
namespace Axiom.Tests;
public class FixtureTests
{
    [Fact]
    public void FIX_StructuralAndAxiomCounts()
    {
        var s = PizzaFixture.Build();
        var es = s.Entities.Values.ToArray();
        Assert.Equal(114, es.Length);
        Assert.Equal(95, s.ClassCount);
        Assert.Equal(14, s.PropertyCount);
        Assert.Equal(11, es.Count(e => e.Kind == EntityKind.Defined));
        Assert.Equal(5, es.Count(e => e.Kind == EntityKind.Individual));
        Assert.Equal(239, s.TBox.Count);
        Assert.Equal(140, s.RBox.Count);
        Assert.Equal(157, es.Sum(e => e.Restrictions.Count));
        Assert.Equal(24, es.Sum(e => e.Equivalents.Count));
        Assert.Equal(8, es.Sum(e => e.DisjointWith.Count));
        Assert.Equal(22, es.Count(e => e.Parents.Contains(Ns.Pizza + "NamedPizza")));
        var named = es.Where(e => e.Parents.Contains(Ns.Pizza + "NamedPizza")).ToArray();
        Assert.Equal(103, named.Sum(e => e.Restrictions.Count(r => r.Quantifier == "some")));
        Assert.Equal(33, named.SelectMany(e => e.Restrictions.Where(r => r.Quantifier == "some").SelectMany(r => r.Fillers)).Distinct().Count());
        Assert.All(named, e => { Assert.Single(e.Restrictions, r => r.Quantifier == "only"); Assert.Equal(Ns.Pizza + "Italy", e.Restrictions[^1].Fillers[0]); });
        Assert.Equal(4, s.Entities[Ns.Pizza + "Margherita"].Restrictions.Count);
        Assert.Equal(9, s.Entities[Ns.Pizza + "Cajun"].Restrictions.Count);
        Assert.Equal(7, s.TBox.Count(t => t.Predicate == Ns.Rdfs + "comment"));
        Assert.Equal(6, es.Count(e => e.Restrictions.Any(r => r.Property == Ns.Pizza + "hasSpiciness")));
        Assert.Equal(6, es.Count(e => e.Inverse != null));
        Assert.Equal(7, es.Count(e => e.Iri.StartsWith(Ns.Pizza) && e.Domain != null));
        Assert.Equal(8, es.Count(e => e.Iri.StartsWith(Ns.Pizza) && e.Range != null));
        Assert.Equal(4, s.TBox.Count(t => t.Predicate == Ns.SubProperty));
        Assert.Equal(2, s.Entities[Ns.Pizza + "CheeseyVegetableTopping"].Equivalents.Count);
        Assert.DoesNotContain(s.TBox, t => t.Predicate == Ns.Owl + "oneOf");
        Assert.Equal(111, s.TBox.Count(t => t.Predicate == Ns.Type));
        Assert.Equal(94, s.TBox.Count(t => t.Predicate == Ns.SubClass));
        Assert.Equal(13_505, s.IndividualCount);
        Assert.Equal(87_379, s.TripleCount);
    }
    [Theory]
    [InlineData(1000, 7629, 12206.53, 3830, "FruttiDiMare", 14.71, "Siciliana", 13.18, "Quinn Esposito")]
    [InlineData(12000, 87379, 146475.15, 45015, "Rosa", 10.86, "Margherita", 8.14, "Jonna Ueda")]
    [InlineData(50000, 362879, 609160.42, 188150, "Caprina", 11.41, "QuattroFormaggi", 12.71, "Elif Ionescu")]
    [InlineData(100000, 725379, 1217990.26, 375866, "Veneziana", 11.67, "American", 9.65, "Sami Lombardi")]
    public void FIX_GoldenDatasets(int n, long triples, decimal prices, int ratings, string first, double firstPrice, string last, double lastPrice, string lastCustomer)
    {
        var s = PizzaFixture.Build(n);
        Assert.Equal(triples, s.TripleCount);
        Assert.Equal(n + n / 8 + 5, s.IndividualCount);
        Assert.Equal(prices, s.Individuals.Sum(i => (decimal)i.Price));
        Assert.Equal(ratings, s.Individuals.Sum(i => i.Rating));
        Assert.Equal(first, s.Individuals[0].TypeName);
        Assert.Equal(firstPrice, s.Individuals[0].Price);
        Assert.Equal(last, s.Individuals[^1].TypeName);
        Assert.Equal(lastPrice, s.Individuals[^1].Price);
        Assert.Equal(lastCustomer, s.Customers[^1].Name);
        Assert.Equal(new[] { "Nadia Duarte", "Chidi Tremblay", "Greta Varga", "Xiulan Sato", "Kofi Weber" }, s.Customers.Take(5).Select(c => c.Name));
        Assert.Equal(n, s.IndividualIndex.Count);
        Assert.Equal(n, s.ByType.Values.Sum(b => b.Count));
        Assert.Equal(n, s.Individuals.Select(i => i.Reference).Distinct().Count());
        Assert.All(s.Individuals, i =>
        {
            Assert.Same(i, s.IndividualIndex[i.Iri]);
            Assert.False(s.Entities.ContainsKey(i.Iri));
            Assert.StartsWith(Ns.Demo, i.Iri);
            Assert.StartsWith(Ns.Pizza, i.Type);
            Assert.InRange(i.Price, 7.5, 16);
            Assert.InRange(i.Rating, 1, 5);
            Assert.InRange(i.CustomerIndex, 0, s.Customers.Count - 1);
            Assert.Equal(0, i.Timestamp % 1000);
            Assert.InRange(i.Timestamp, 1785542400000L, 1788134399000L);
        });
        var again = PizzaFixture.Generate(n);
        Assert.Equal(s.Individuals.Select(Serialise), again.Individuals.Select(Serialise));
        Assert.Equal(s.Customers, again.Customers);
    }
    static string Serialise(Individual i) => string.Join("|", i.Index, i.Iri, i.Type, i.Reference, i.Branch, i.Price.ToString("R", System.Globalization.CultureInfo.InvariantCulture), i.Timestamp, i.Rating, i.CustomerIndex);
    [Fact]
    public void STORE_QueryCountMatchesActualLazySource()
    {
        var s = PizzaFixture.Build(1000);
        Assert.Equal(s.TripleCount, s.Scan().LongCount());
        Assert.Equal(140, s.RBox.Count);
        Assert.Equal(313, s.Scan(predicate: Ns.Demo + "rating", obj: Term.Literal(5)).Count());
        Assert.Equal(114, s.Entities.Count);
    }
    [Fact]
    public void STORE_AdjacencyCapsWithoutLyingOrDuplicating()
    {
        var s = PizzaFixture.Build(100000);
        var all = s.Neighbours(Ns.Demo + "Order");
        Assert.Equal(4000, all.List.Count);
        Assert.Equal(100007, all.Total);
        var pizza = s.Neighbours(Ns.Pizza + "Margherita");
        Assert.Equal(pizza.List.Distinct().Count(), pizza.List.Count);
        var n = s.ByType[Ns.Pizza + "Margherita"].Count;
        Assert.Equal(n + 4, pizza.Total);
        Assert.All(s.Individuals.Take(30), i => Assert.Equal(2, s.Neighbours(i.Iri).Total));
        Assert.All(s.Entities.Values, e => Assert.All(e.Parents, p => Assert.Contains(e.Iri, s.Entities[p].Children)));
    }
    [Fact]
    public void STORE_ReverseRestrictionUsesSamePredicate()
    {
        var s = PizzaFixture.Build();
        var target = Ns.Pizza + "CheeseTopping";
        var from = Ns.Pizza + "CheeseyVegetableTopping";
        Assert.Contains(new Neighbour(target, Ns.Owl + "equivalentClass", true), s.Neighbours(from).List);
        Assert.Contains(new Neighbour(from, Ns.Owl + "equivalentClass", false), s.Neighbours(target).List);
    }
    [Fact]
    public void FIX_ExactNamespaces()
    {
        Assert.Equal("http://example.org/pizzeria#Pizza_000001", Ns.Expand("demo:Pizza_000001"));
        Assert.Equal("<https://unknown.test/x>", Ns.Shorten("https://unknown.test/x"));
        var s = PizzaFixture.Build();
        Assert.All(s.Entities.Values.SelectMany(e => e.Restrictions.Concat(e.Equivalents)).SelectMany(r => r.Fillers), f => Assert.False(f.StartsWith(Ns.Demo)));
    }
}
