using Axiom.Core;
using Axiom.Fixture;
using System.Xml.Linq;
using Xunit;
namespace Axiom.Tests;
public class ParallelRouteTests
{
    [Fact]
    public void Opposite_directions_use_distinct_parallel_curve_controls()
    {
        // The real fixture contains reciprocal object properties. Isolate that pair
        // and add a second assertion to test three routes, including opposite directions.
        var store = PizzaFixture.Build(1000);
        var view = new Viewport(store);
        var a = Ns.Pizza + "hasTopping";
        var b = Ns.Pizza + "isToppingOf";
        view.Seed([a, b], expand: false);
        view.Edges.Clear();
        foreach (var key in new[] { new EdgeKey(a, Ns.Owl + "inverseOf", b), new EdgeKey(b, Ns.Owl + "inverseOf", a), new EdgeKey(a, Ns.Rdfs + "seeAlso", b) })
            view.Edges.Add(key, new(key));
        var layout = new Layouts(view, store) { Choice = "grid" };
        layout.Run();
        view.Nodes[a].X = 0;
        view.Nodes[a].Y = 0;
        view.Nodes[b].X = 100;
        view.Nodes[b].Y = 0;
        using var svg = new SvgDraw(600, 400, (s, size, _, _) => s.Length * size * .55);
        SceneRenderer.Render(svg, view, layout, new(100, 100, 1), 600, 400, false);
        var controls = XDocument.Parse(svg.Finish()).Descendants().Where(e => e.Name.LocalName == "path").Select(e => (string?)e.Attribute("d")).Where(d => d?.Contains(" Q") == true).Select(d => d!.Split(" Q")[1].Split(' ')[0]).ToArray();
        Assert.Equal(3, controls.Length);
        Assert.Equal(3, controls.Distinct().Count());
    }
}
