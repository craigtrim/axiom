using Axiom.Core;
using Axiom.Fixture;
using System.Globalization;
using System.Xml.Linq;
using Xunit;

namespace Axiom.Tests;

public class BadgeContractTests
{
    [Theory]
    [InlineData(37, "+37")]
    [InlineData(999, "+999")]
    [InlineData(1000, "+1.0k")]
    [InlineData(9999, "+10.0k")]
    [InlineData(10000, "+10k")]
    [InlineData(12500, "+13k")]
    public void Badge_counts_match_the_specification_rounding(int count, string expected) => Assert.Equal(expected, SceneRenderer.BadgeText(count));

    [Fact]
    public void Svg_badges_use_the_specified_anchor_and_stadium_geometry()
    {
        var store = PizzaFixture.Build(1000);
        var view = new Viewport(store);
        view.Seed([Ns.Pizza + "Pizza"], expand: false);
        var node = view.OrderedNodes.Single();
        node.X = node.Y = 0;
        node.Radius = 10;
        node.Degree = 37;
        var layout = new Layouts(view, store);
        using var draw = new SvgDraw(800, 600, (text, size, _, _) => text.Length * 5);
        SceneRenderer.Render(draw, view, layout, new(400, 300, 1), 800, 600, false);
        var doc = XDocument.Parse(draw.Finish());
        var text = doc.Descendants().Single(e => e.Name.LocalName == "text" && e.Value == "+37");
        Assert.Equal("412.2", (string?)text.Attribute("x"));
        Assert.Equal("288.3", (string?)text.Attribute("y"));
        Assert.Equal("central", (string?)text.Attribute("dominant-baseline"));
        var pills = doc.Descendants().Where(e => e.Name.LocalName == "rect" && (double?)e.Attribute("height") == 14).ToArray();
        Assert.Equal(2, pills.Length);
        Assert.All(pills, pill =>
        {
            Assert.Equal(24, (double)pill.Attribute("width")!);
            Assert.Equal(7, (double)pill.Attribute("rx")!);
            Assert.Equal("400.2", (string?)pill.Attribute("x"));
            Assert.Equal("280.8", (string?)pill.Attribute("y"));
        });
    }

    [Theory]
    [InlineData(.3, 400)]
    [InlineData(1, -100)]
    [InlineData(1, 900)]
    public void Badge_pass_culls_zoomed_out_and_offscreen_nodes(double zoom, double cameraX)
    {
        var store = PizzaFixture.Build(1000);
        var view = new Viewport(store);
        view.Seed([Ns.Pizza + "Pizza"], expand: false);
        view.OrderedNodes.Single().X = 0;
        view.OrderedNodes.Single().Y = 0;
        using var draw = new SvgDraw(800, 600, (text, size, _, _) => text.Length * 5);
        SceneRenderer.Render(draw, view, new Layouts(view, store), new(cameraX, 300, zoom), 800, 600, false);
        Assert.DoesNotContain(XDocument.Parse(draw.Finish()).Descendants(), e => e.Name.LocalName == "text" && e.Value.StartsWith("+"));
    }
}
