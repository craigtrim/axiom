using Xunit;
using Axiom.Core;
using Axiom.Fixture;
namespace Axiom.Tests;
public class HitIndexTests
{
    [Fact]
    public void Fixture_buckets_match_topmost_brute_force_across_camera_scales()
    {
        var store = PizzaFixture.Build(1000);
        var view = new Viewport(store);
        view.Seed(store.Individuals.Take(500).Select(n => n.Iri), true, false);
        var layout = new Layouts(view, store) { Choice = "grid" };
        layout.Run(true, true);
        var nodes = view.OrderedNodes.ToArray();
        var index = new HitIndex();
        index.Rebuild(nodes);
        foreach (var zoom in new[] { .05, .2, 1d, 4 })
            foreach (var n in nodes.Where((_, i) => i % 7 == 0))
                foreach (var offset in new[] { -30d, 0, 25 })
                {
                    var p = new PointD(n.X + offset, n.Y - offset / 2);
                    var padding = 6 / zoom;
                    var expected = nodes.Reverse().FirstOrDefault(a => Math.Pow(a.X - p.X, 2) + Math.Pow(a.Y - p.Y, 2) <= Math.Pow(a.Radius + padding, 2));
                    Assert.Same(expected, index.Hit(p, padding));
                }
    }
}
