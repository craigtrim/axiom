using Axiom.Core;
using Axiom.Fixture;
using Xunit;

namespace Axiom.Tests;

public class ForceReuseTests
{
    [Fact]
    public void Reused_spatial_storage_produces_the_same_layout_after_shrink_and_growth()
    {
        var store = PizzaFixture.Build(12000);
        var view = new Viewport(store);
        view.SetBudget(1000);
        var layout = new Layouts(view, store) { Choice = "force" };
        var iris = store.Entities.Keys.Concat(store.Individuals.Take(886).Select(i => i.Iri)).ToArray();
        view.Seed(iris, expand: false);
        layout.Run(true, true);
        var expected = view.OrderedNodes.Select(n => (n.Iri, n.X, n.Y)).ToArray();

        view.Clear();
        view.Seed([Ns.Pizza + "Pizza"], expand: false);
        layout.Run(true, true);
        view.Clear();
        view.Seed(iris, expand: false);
        layout.Run(true, true);

        Assert.Equal(expected, view.OrderedNodes.Select(n => (n.Iri, n.X, n.Y)).ToArray());
        Assert.All(view.OrderedNodes, n => Assert.True(double.IsFinite(n.X) && double.IsFinite(n.Y)));
    }

    [Fact]
    public void Warm_force_frames_reuse_spatial_buckets_instead_of_allocating_per_node()
    {
        var store = PizzaFixture.Build(12000);
        var view = new Viewport(store);
        view.SetBudget(3000);
        view.Seed(store.Individuals.Take(3000).Select(i => i.Iri), expand: false);
        var layout = new Layouts(view, store) { Choice = "force" };
        layout.Run(true, true);
        for (var i = 0; i < 30; i++)
        {
            view.Alpha = .05;
            layout.Force.Step();
        }
        var before = GC.GetAllocatedBytesForCurrentThread();
        for (var i = 0; i < 60; i++)
        {
            view.Alpha = .05;
            layout.Force.Step();
        }
        var allocated = GC.GetAllocatedBytesForCurrentThread() - before;
        Assert.True(allocated < 1_000_000, $"Sixty warmed frames allocated {allocated:N0} bytes.");
    }
}
