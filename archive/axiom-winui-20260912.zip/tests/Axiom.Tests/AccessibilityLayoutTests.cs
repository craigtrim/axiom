using Axiom.Core;
using Axiom.Fixture;
using Xunit;

namespace Axiom.Tests;

public class AccessibilityLayoutTests
{
    [Theory]
    [InlineData(1)]
    [InlineData(1.25)]
    [InlineData(1.5)]
    [InlineData(2)]
    public void Scaled_rows_keep_absolute_scroll_indices_and_constant_virtualization(double scale)
    {
        var rowHeight = TableModel.RowHeight * scale;
        var small = TableModel.Window(120 * rowHeight, 10 * rowHeight, 1000, rowHeight);
        var large = TableModel.Window(120 * rowHeight, 10 * rowHeight, 100000, rowHeight);
        Assert.Equal(114, large.First);
        Assert.Equal(22, large.Count);
        Assert.Equal(small.Count, large.Count);
        Assert.Equal(100000 * rowHeight, large.Height);
        var end = TableModel.Window(100000 * rowHeight, 10 * rowHeight, 100000, rowHeight);
        Assert.InRange(end.First + end.Count, 0, 100000);
    }

    [Theory]
    [InlineData(1.25)]
    [InlineData(1.5)]
    [InlineData(2)]
    public void Enlarged_graph_labels_reserve_their_full_text_height(double scale)
    {
        var store = PizzaFixture.Build(1000);
        var view = new Viewport(store);
        view.Seed(store.Entities.Keys.Concat(store.Individuals.Take(386).Select(i => i.Iri)), expand: false);
        var layout = new Layouts(view, store) { Choice = "grid" };
        layout.Run();
        using var metrics = new SvgDraw(1600, 1000, (text, size, _, _) => text.Length * size * .55);
        var labels = SceneRenderer.Labels(metrics, view, Camera.Fit(view, 1600, 1000), 1600, 1000, null, textScale: scale);
        Assert.NotEmpty(labels);
        Assert.All(labels, label => Assert.Equal(16 * scale, label.Bounds.Height));
        for (var i = 0; i < labels.Count; i++)
            for (var j = i + 1; j < labels.Count; j++)
                Assert.False(labels[i].Bounds.Intersects(labels[j].Bounds));
    }

    [Fact]
    public void Selection_pins_and_camera_independent_positions_do_not_relayout()
    {
        var store = PizzaFixture.Build(1000);
        var view = new Viewport(store);
        view.Seed([Ns.Pizza + "Pizza"]);
        var layout = new Layouts(view, store) { Choice = "grid" };
        layout.Run();
        var node = view.OrderedNodes.First();
        node.X = 1234;
        node.Pinned = true;
        view.Selected = node.Iri;
        view.Hovered = node.Iri;
        view.Alpha = .12;
        Assert.False(layout.NeedsLayout);
        layout.EnsureCurrent();
        Assert.Equal(1234, node.X);
        Assert.Equal(.12, view.Alpha);
    }

    [Fact]
    public void Same_size_structural_replacement_still_relayouts()
    {
        var store = PizzaFixture.Build(1000);
        var view = new Viewport(store);
        view.Seed(store.Individuals.Take(20).Select(i => i.Iri), expand: false);
        var layout = new Layouts(view, store) { Choice = "grid" };
        layout.Run();
        view.Remove(store.Individuals[0].Iri);
        view.Admit([store.Individuals[30].Iri]);
        Assert.Equal(20, view.Nodes.Count);
        Assert.True(layout.NeedsLayout);
        layout.EnsureCurrent();
        Assert.False(layout.NeedsLayout);
        view.Clear();
        layout.EnsureCurrent();
        Assert.Empty(layout.Groups);
        Assert.Empty(layout.Rings);
        Assert.Equal(0, view.Alpha);
    }
}
