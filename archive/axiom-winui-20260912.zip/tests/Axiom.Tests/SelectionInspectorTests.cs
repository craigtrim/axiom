using Axiom.Core;
using Axiom.Fixture;
using Xunit;
namespace Axiom.Tests;
public class SelectionInspectorTests
{
    [Fact]
    public void Generated_labels_and_special_instance_counts_match_the_fixture()
    {
        var store = PizzaFixture.Build(12000);
        Assert.Equal("AX-100000", store.Label(store.Individuals[0].Iri));
        Assert.Equal("Nadia Duarte", store.Label(store.Customers[0].Iri));
        Assert.Equal(12000, store.InstanceCount(Ns.Demo + "Order"));
        Assert.Equal(1500, store.InstanceCount(Ns.Demo + "Customer"));
        Assert.Equal(543, store.InstanceCount(Ns.Pizza + "Margherita"));
        Assert.Equal(0, store.InstanceCount(Ns.Pizza + "Country"));
        Assert.Equal(94, store.DescendantCount(Ns.Thing));
        Assert.Equal(store.Individuals.Select(i => i.Iri), store.InstanceIris(Ns.Demo + "Order"));
    }
    [Fact]
    public void Unresolved_query_IRIs_retain_identity_and_explicit_reveal()
    {
        var store = PizzaFixture.Build(1000);
        var selection = new Selection(store);
        var events = new List<string>();
        selection.Changed += iri => events.Add("selected " + iri);
        selection.RevealRequested += iri => events.Add("reveal " + iri);
        selection.Select(Ns.SubClass, true);
        Assert.Equal(Ns.SubClass, selection.Iri);
        Assert.False(selection.IsResolved);
        Assert.Equal(new[] { "selected " + Ns.SubClass, "reveal " + Ns.SubClass }, events);
        selection.Select(null);
        Assert.Null(selection.Iri);
    }
    [Fact]
    public void Instance_paging_retains_existing_focus_and_obeys_budget()
    {
        var store = PizzaFixture.Build(12000);
        var view = new Viewport(store);
        view.SetBudget(100);
        view.Seed([Ns.Pizza + "Pizza"], expand: false);
        var before = view.Focus.Single();
        var iri = Ns.Pizza + "Margherita";
        view.Seed([iri], false, false);
        var result = view.Admit(store.InstanceIris(iri), 1, view.Nodes[iri]);
        Assert.Equal(98, result.Added);
        Assert.Equal(445, result.Refused);
        Assert.Equal(100, view.Nodes.Count);
        Assert.Contains(before, view.Nodes.Keys);
        Assert.Contains(iri, view.Nodes.Keys);
    }
}
