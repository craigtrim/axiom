using Axiom.Core;
using Axiom.Fixture;
using Xunit;

namespace Axiom.Tests;

public class CreationContractTests
{
    [Fact]
    public void CreatingClassAddsOnlyItsSubclassTripleAndUndoRestoresTheSchema()
    {
        var store = PizzaFixture.Build(1000);
        var triples = store.TBox.ToArray();
        var restrictions = store.RBox.ToArray();
        var count = store.Entities.Count;
        var parent = Ns.Pizza + "PizzaTopping";
        var result = store.CreateClass("TruffleTopping", parent);
        Assert.Null(result.Error);
        var entity = Assert.IsType<Entity>(result.Entity);
        Assert.Equal("Added in this session.", entity.Comment);
        Assert.Equal(new[] { parent }, entity.Parents);
        Assert.Equal(count + 1, store.Entities.Count);
        Assert.Equal(triples.Length + 1, store.TBox.Count);
        Assert.Equal(new Triple(entity.Iri, Ns.SubClass, new(parent)), Assert.Single(store.Scan(entity.Iri)));
        Assert.Equal(restrictions, store.RBox);
        Assert.Contains(entity.Iri, store.Entities[parent].Children);
        Assert.Contains(store.Scan(predicate: Ns.SubClass), t => t.Subject == entity.Iri);
        Assert.True(store.Undo());
        Assert.Equal(count, store.Entities.Count);
        Assert.Equal(triples, store.TBox);
        Assert.Equal(restrictions, store.RBox);
        Assert.Empty(store.Scan(entity.Iri));
        Assert.DoesNotContain(entity.Iri, store.Entities[parent].Children);
    }

    [Fact]
    public void IndividualCreationProjectsChosenValuesAndUndoRemovesEveryIndexEntry()
    {
        var store = PizzaFixture.Build(1000);
        var type = store.Individuals[0].Type;
        var count = store.Individuals.Count;
        var typeCount = store.ByType[type].Count;
        var triples = store.TripleCount;
        const long timestamp = 1700000000000;
        var result = store.CreateIndividual(type, "Camden", "£12.345", timestamp, 4, 7);
        Assert.Null(result.Error);
        var item = Assert.IsType<Individual>(result.Individual);
        Assert.Equal(Ns.Demo + "Pizza_001001", item.Iri);
        Assert.Equal(count, item.Index);
        Assert.Equal(12.35, item.Price);
        Assert.Equal(4, item.Rating);
        Assert.Equal(7, item.CustomerIndex);
        Assert.Equal(timestamp, item.Timestamp);
        Assert.Same(item, store.IndividualIndex[item.Iri]);
        Assert.Equal(typeCount + 1, store.ByType[type].Count);
        Assert.Equal(triples + 7, store.TripleCount);
        var projected = store.Scan(item.Iri).ToArray();
        Assert.Equal(7, projected.Length);
        Assert.Contains(projected, t => t.Predicate == Ns.Demo + "orderedBy" && t.Object.Value == store.Customers[7].Iri);
        Assert.Contains(projected, t => t.Predicate == Ns.Demo + "rating" && t.Object.Value == "4");
        Assert.True(store.Undo());
        Assert.Equal(count, store.Individuals.Count);
        Assert.Equal(typeCount, store.ByType[type].Count);
        Assert.Equal(triples, store.TripleCount);
        Assert.False(store.IndividualIndex.ContainsKey(item.Iri));
        Assert.Empty(store.Scan(item.Iri));
    }

    [Fact]
    public void NewIndividualDefaultsToFiveStarsAndTheFirstCustomer()
    {
        var store = PizzaFixture.Build(1000);
        var result = store.CreateIndividual(store.Individuals[0].Type, "Soho", "11.50");
        Assert.Null(result.Error);
        Assert.Equal(5, result.Individual!.Rating);
        Assert.Equal(0, result.Individual.CustomerIndex);
    }

    [Theory]
    [InlineData(0, 0)]
    [InlineData(6, 0)]
    [InlineData(5, -1)]
    [InlineData(5, 100000)]
    public void InvalidCreationChoicesDoNotMutateTheStore(int rating, int customer)
    {
        var store = PizzaFixture.Build(1000);
        var version = store.Version;
        var triples = store.TripleCount;
        var result = store.CreateIndividual(store.Individuals[0].Type, "Soho", "11.50", rating: rating, customerIndex: customer);
        Assert.Null(result.Individual);
        Assert.NotNull(result.Error);
        Assert.Equal(version, store.Version);
        Assert.Equal(triples, store.TripleCount);
        Assert.False(store.CanUndo);
    }
}
