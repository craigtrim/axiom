using Axiom.Core;
using Axiom.Fixture;
using Xunit;
namespace Axiom.Tests;
public class MutationTableTests
{
    [Fact]
    public void RenameUndoWorksAfterAnInterveningSchemaSnapshotUndo()
    {
        var s = PizzaFixture.Build(1000);
        var iri = Ns.Pizza + "Margherita";
        var old = s.Entities[iri].Name;
        Assert.Null(s.Rename(iri, "TestPizza"));
        var created = s.CreateClass("MyPizza", iri);
        Assert.Null(created.Error);
        Assert.True(s.Undo());
        Assert.True(s.Undo());
        Assert.Equal(old, s.Entities[iri].Name);
    }
    [Fact]
    public void DeletingClassReparentsChildrenCleansAxiomsKeepsOrdersAndIsUndoable()
    {
        var s = PizzaFixture.Build(1000);
        var iri = Ns.Pizza + "Margherita";
        var count = s.ByType[iri].Count;
        var triples = s.TripleCount;
        Assert.Null(s.DeleteClass(iri));
        Assert.False(s.Entities.ContainsKey(iri));
        Assert.Equal(count, s.ByType[iri].Count);
        Assert.DoesNotContain(s.TBox, t => t.Subject == iri || t.Object.Value == iri);
        Assert.DoesNotContain(s.Entities.Values.SelectMany(e => e.Restrictions).SelectMany(r => r.Fillers), f => f == iri);
        Assert.True(s.Undo());
        Assert.True(s.Entities.ContainsKey(iri));
        Assert.Equal(triples, s.TripleCount);
        Assert.NotNull(s.DeleteClass(Ns.Thing));
    }
    [Theory]
    [InlineData("", "Price is required.")]
    [InlineData("NaN", "not a number")]
    [InlineData("££12", "not a number")]
    [InlineData("-1", "cannot be negative")]
    [InlineData("501", "£500")]
    public void InvalidPriceNeverMutatesOrPushesUndo(string input, string message)
    {
        var s = PizzaFixture.Build(1000);
        var i = s.Individuals[0];
        var value = i.Price;
        var version = s.Version;
        Assert.Contains(message, s.EditCell(i.Iri, "price", input));
        Assert.Equal(value, i.Price);
        Assert.Equal(version, s.Version);
        Assert.False(s.CanUndo);
    }
    [Theory]
    [InlineData("0")]
    [InlineData("6")]
    [InlineData("4.5")]
    [InlineData("")]
    [InlineData("Infinity")]
    public void InvalidRatingIsRejected(string input) => Assert.NotNull(Store.ValidateRating(input, out _));
    [Fact]
    public void EditInvalidatesFilterAndUndoRestoresSameRecord()
    {
        var s = PizzaFixture.Build(1000);
        var table = new TableModel(s) { Branch = "Soho" };
        table.Apply();
        var i = table.Rows[0];
        var count = table.Rows.Count;
        Assert.Null(s.EditCell(i.Iri, "branch", "Camden"));
        table.Apply();
        Assert.Equal(count - 1, table.Rows.Count);
        Assert.True(s.Undo());
        table.Apply();
        Assert.Equal(count, table.Rows.Count);
        Assert.Contains(i, table.Rows);
    }
    [Fact]
    public void FilteringUsesAllFacetsAndFieldBoundariesButNotPrices()
    {
        var s = PizzaFixture.Build(1000);
        var i = s.Individuals[0];
        var table = new TableModel(s) { Type = i.Type, Branch = i.Branch, Query = i.TypeName + " " + i.Branch };
        table.Apply();
        Assert.NotEmpty(table.Rows);
        Assert.All(table.Rows, r => { Assert.Equal(i.Type, r.Type); Assert.Equal(i.Branch, r.Branch); });
        table.Query = "£";
        table.Apply();
        Assert.Empty(table.Rows);
        table.Reset();
        Assert.Same(s.Individuals[0], table.Rows[0]);
    }
    [Fact]
    public void NumericSortIsStableAndColumnWidthsDoNotDrift()
    {
        var s = PizzaFixture.Build(1000);
        var table = new TableModel(s);
        table.ToggleSort("rating");
        table.Apply();
        Assert.Equal(table.Rows.OrderBy(i => i.Rating).Select(i => i.Index), table.Rows.Select(i => i.Index));
        foreach (var g in table.Rows.GroupBy(i => i.Rating))
            Assert.Equal(g.OrderBy(i => i.Index), g);
        var widths = TableModel.Widths(1500);
        Assert.Equal(1500, widths.Sum(), 6);
        Assert.Equal(108, widths[2]);
        Assert.Equal(124, widths[3]);
    }
    [Theory]
    [InlineData(0, 400, 100000, 0, 25)]
    [InlineData(32000, 400, 100000, 994, 25)]
    [InlineData(3199968, 400, 100000, 99993, 7)]
    public void VirtualWindowHasConstantBoundAndCorrectAbsoluteOffset(double scroll, double height, int total, int first, int count)
    {
        var window = TableModel.Window(scroll, height, total);
        Assert.Equal(first, window.First);
        Assert.Equal(count, window.Count);
        Assert.Equal(total * 32d, window.Height);
    }
}
