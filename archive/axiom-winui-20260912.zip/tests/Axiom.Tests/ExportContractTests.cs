using Axiom.Core;
using Axiom.Fixture;
using System.Xml.Linq;
using Xunit;
namespace Axiom.Tests;
public class ExportContractTests
{
    [Theory]
    [InlineData(100, 200, 3)]
    [InlineData(50000, 80000, 3)]
    [InlineData(9001, 100, 2)]
    public void Raster_dimensions_never_exceed_the_guard(double width, double height, double requested)
    {
        var scale = SceneRenderer.RasterScale(width, height, requested);
        Assert.InRange(width * scale, 0, 9000);
        Assert.InRange(height * scale, 0, 9000);
        Assert.InRange(scale, 0, requested);
    }
    [Fact]
    public void Export_caption_has_six_exact_fields_and_chrome_is_vector_text()
    {
        var store = PizzaFixture.Build(1000);
        var view = new Viewport(store);
        view.Seed([Ns.Pizza + "Pizza"]);
        var layout = new Layouts(view, store) { Choice = "grid" };
        layout.Run();
        var date = new DateTimeOffset(2026, 9, 11, 14, 32, 0, TimeSpan.Zero);
        Assert.Equal(new[] { "Cluster grid layout", $"{Ns.Count(view.Nodes.Count)} nodes", $"{Ns.Count(view.Edges.Count)} relationships", "viewport budget 1,000", $"{Ns.Count(view.Hidden)} neighbours held back", "11 Sep 2026, 14:32" }, SceneRenderer.Caption(view, layout, date).Split(" · "));
        using var svg = new SvgDraw(2200, 1000, (s, size, _, _) => s.Length * size * .55);
        SceneRenderer.ExportChrome(svg, view, layout, 2200, 1000, false, date);
        var texts = XDocument.Parse(svg.Finish()).Descendants().Where(e => e.Name.LocalName == "text").Select(e => e.Value).ToArray();
        Assert.Contains("pizza.owl — graph view", texts);
        Assert.Contains("Axiom Ontology Workbench", texts);
        foreach (var kind in Enum.GetValues<EntityKind>())
            Assert.Contains(Kinds.Label(kind), texts);
        Assert.Contains("Dashed = rdf:type · solid = subClassOf and object properties · +n = neighbours outside the budget", texts);
    }
    [Fact]
    public void Reserved_group_titles_do_not_intersect_node_labels()
    {
        var store = PizzaFixture.Build(1000);
        var view = new Viewport(store);
        view.Seed([Ns.Pizza + "Margherita"]);
        var layout = new Layouts(view, store) { Choice = "grid" };
        layout.Run();
        using var svg = new SvgDraw(1600, 1000, (s, size, _, _) => s.Length * size * .55);
        var camera = Camera.Fit(view, 1600, 1000);
        var reserved = new[] { new RectD(0, 0, 1600, 500) };
        var labels = SceneRenderer.Labels(svg, view, camera, 1600, 1000, null, 900, reserved);
        Assert.All(labels, l => Assert.False(l.Bounds.Intersects(reserved[0])));
    }
}
