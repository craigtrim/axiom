using Axiom.Core;
using Axiom.Fixture;
using Xunit;
namespace Axiom.Tests;
public class ViewportTests
{
    [Fact]
    public void BudgetAndEdgeInvariantsSurviveMixedOperations()
    {
        var s = PizzaFixture.Build(1000);
        var v = new Viewport(s);
        var random = new Random(41);
        var iris = s.Entities.Keys.Concat(s.Individuals.Take(300).Select(i => i.Iri)).ToArray();
        v.SetBudget(100);
        for (var step = 0; step < 10000; step++)
        {
            var iri = iris[random.Next(iris.Length)];
            switch (step % 7)
            {
                case 0:
                    v.Admit(Enumerable.Range(0, 30).Select(_ => iris[random.Next(iris.Length)]), random.Next(4));
                    break;
                case 1:
                    if (v.Nodes.Count > 0)
                        v.Expand(v.Nodes.Keys.First(), 20);
                    break;
                case 2:
                    v.Remove(iri);
                    break;
                case 3:
                    if (v.Nodes.TryGetValue(iri, out var node))
                        node.Pinned = !node.Pinned;
                    break;
                case 4:
                    v.SetBudget(random.Next(1, 4) * 100);
                    break;
                case 5:
                    if (v.Nodes.Count > 0)
                        v.Collapse(v.Nodes.Keys.Last());
                    break;
                case 6:
                    v.EvictionMode = new[] { "lru", "degree", "refuse" }[random.Next(3)];
                    break;
            }
            Assert.InRange(v.Nodes.Count, 0, v.Budget);
            Assert.Equal(v.Nodes.Count, v.OrderedNodes.Count());
            Assert.All(v.Edges.Keys, e => { Assert.True(v.Nodes.ContainsKey(e.Source)); Assert.True(v.Nodes.ContainsKey(e.Target)); });
            var degrees = v.Nodes.Keys.ToDictionary(k => k, _ => 0);
            foreach (var edge in v.Edges.Keys)
            {
                degrees[edge.Source]++;
                degrees[edge.Target]++;
            }
            Assert.All(v.OrderedNodes, n => { Assert.True(n.Hidden >= 0); Assert.Equal(degrees[n.Iri], n.ShownDegree); });
        }
    }
    [Fact]
    public void ProtectedFocusAndPinsSurviveAdmissionAndBudgetCannotUnderflowThem()
    {
        var s = PizzaFixture.Build(1000);
        var v = new Viewport(s);
        v.Seed(s.Individuals.Take(200).Select(i => i.Iri), expand: false);
        Assert.False(v.SetBudget(100).Accepted);
        Assert.Equal(1000, v.Budget);
        v.Admit(s.Individuals.Skip(200).Select(i => i.Iri));
        Assert.All(s.Individuals.Take(200), i => Assert.True(v.Nodes.ContainsKey(i.Iri)));
        var pin = s.Individuals[999].Iri;
        v.Nodes[pin].Pinned = true;
        v.SetBudget(300);
        Assert.True(v.Nodes.ContainsKey(pin));
        Assert.Equal(300, v.Nodes.Count);
    }
    [Fact]
    public void REFUSELeavesExistingNodesUntouched()
    {
        var s = PizzaFixture.Build(1000);
        var v = new Viewport(s);
        v.SetBudget(100);
        v.EvictionMode = "refuse";
        v.Admit(s.Individuals.Take(100).Select(i => i.Iri));
        var before = v.Nodes.Keys.ToArray();
        var r = v.Admit(s.Individuals.Skip(100).Take(20).Select(i => i.Iri));
        Assert.Equal(20, r.Refused);
        Assert.Equal(0, r.Evicted);
        Assert.Equal(before, v.Nodes.Keys);
    }
    [Fact]
    public void IncrementalLinksIncludeExistingSchemaHubsAndUseDistinctPredicates()
    {
        var s = PizzaFixture.Build(1000);
        var v = new Viewport(s);
        v.Admit([Ns.Pizza + "Margherita"]);
        var order = s.ByType[Ns.Pizza + "Margherita"][0];
        v.Admit([order.Iri]);
        Assert.Contains(new EdgeKey(order.Iri, Ns.Type, order.Type), v.Edges.Keys);
        v.Admit([Ns.Pizza + "CheeseyVegetableTopping", Ns.Pizza + "CheeseTopping"]);
        Assert.Contains(new EdgeKey(Ns.Pizza + "CheeseyVegetableTopping", Ns.Owl + "equivalentClass", Ns.Pizza + "CheeseTopping"), v.Edges.Keys);
        var count = v.Edges.Count;
        v.Refresh();
        Assert.Equal(count, v.Edges.Count);
    }
    [Theory]
    [InlineData("force")]
    [InlineData("hierarchy")]
    [InlineData("radial")]
    [InlineData("grid")]
    public void LayoutsAreDeterministicFiniteAndPreservePins(string mode)
    {
        var s = PizzaFixture.Build(1000);
        Viewport Make()
        {
            var v = new Viewport(s);
            v.Seed([Ns.Pizza + "Pizza"], expand: true);
            return v;
        }
        var a = Make();
        var b = Make();
        var la = new Layouts(a, s) { Choice = mode };
        var lb = new Layouts(b, s) { Choice = mode };
        la.Run(true, true);
        lb.Run(true, true);
        Assert.Equal(a.OrderedNodes.Select(n => (n.Iri, n.X, n.Y)), b.OrderedNodes.Select(n => (n.Iri, n.X, n.Y)));
        Assert.All(a.OrderedNodes, n => { Assert.True(double.IsFinite(n.X)); Assert.True(double.IsFinite(n.Y)); });
        var pin = a.OrderedNodes.First();
        pin.Pinned = true;
        var location = (pin.X, pin.Y);
        la.Run(true, true);
        Assert.Equal(location, (pin.X, pin.Y));
    }
    [Fact]
    public void AutomaticLayoutUsesActualDensityAndTopology()
    {
        var s = PizzaFixture.Build(1000);
        var v = new Viewport(s);
        v.Seed(s.Individuals.Take(501).Select(i => i.Iri), expand: false);
        Assert.Equal("grid", new Layouts(v, s).Choose());
        v.Clear();
        Assert.Equal("force", new Layouts(v, s).Choose());
    }
}
