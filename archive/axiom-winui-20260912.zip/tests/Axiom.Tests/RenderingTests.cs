using Axiom.Core;
using Axiom.Fixture;
using System.Xml.Linq;
using Xunit;
namespace Axiom.Tests;
public class RenderingTests
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void PaletteHasReadableTextAndControls(bool dark)
    {
        foreach (var fg in new[] { "text", "text-secondary", "syntax-keyword", "syntax-variable", "syntax-iri", "syntax-string", "syntax-number", "syntax-comment" })
            Assert.True(DesignTokens.Contrast(DesignTokens.Colour(fg, dark), DesignTokens.Colour("surface", dark)) >= 4.5, fg);
        Assert.True(DesignTokens.Contrast(DesignTokens.Colour("stroke-strong", dark), DesignTokens.Colour("surface", dark)) >= 3);
    }
    [Fact]
    public void LabelsDoNotOverlapAndSvgEscapesContent()
    {
        var s = PizzaFixture.Build(1000);
        var v = new Viewport(s);
        v.Seed([Ns.Pizza + "Pizza"]);
        var layout = new Layouts(v, s) { Choice = "grid" };
        layout.Run();
        v.OrderedNodes.First().Label = "A < B & \"quoted\"";
        using var svg = new SvgDraw(1600, 1000, (t, size, _, _) => t.Length * size * .55);
        var camera = Camera.Fit(v, 1600, 1000);
        var labels = SceneRenderer.Labels(svg, v, camera, 1600, 1000, null);
        for (var i = 0; i < labels.Count; i++)
            for (var j = i + 1; j < labels.Count; j++)
                Assert.False(labels[i].Bounds.Intersects(labels[j].Bounds));
        SceneRenderer.Render(svg, v, layout, camera, 1600, 1000, false);
        var content = svg.Finish();
        var xml = XDocument.Parse(content);
        Assert.Equal("svg", xml.Root!.Name.LocalName);
        Assert.Contains("&amp;", content);
        Assert.Contains("&lt;", content);
    }
    [Fact]
    public void CameraRoundTripsAndFitsNodeGeometry()
    {
        var c = new Camera(120, -40, .75);
        var screen = c.Screen(90, 27);
        var world = c.World(screen.X, screen.Y);
        Assert.Equal(90, world.X, 8);
        Assert.Equal(27, world.Y, 8);
        var s = PizzaFixture.Build(1000);
        var v = new Viewport(s);
        v.Seed([Ns.Pizza + "Pizza"]);
        var layout = new Layouts(v, s) { Choice = "radial" };
        layout.Run();
        var fit = Camera.Fit(v, 1200, 700);
        Assert.All(v.OrderedNodes, n => { var p = fit.Screen(n.X, n.Y); Assert.InRange(p.X, 0, 1200); Assert.InRange(p.Y, 0, 700); });
    }
}
