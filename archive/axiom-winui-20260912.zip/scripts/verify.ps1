param([switch]$Native)
$ErrorActionPreference = 'Stop'
Push-Location (Join-Path $PSScriptRoot '..')
try {
    node scripts/traceability.mjs --check
    if ($LASTEXITCODE -ne 0) { throw 'Requirement map validation failed.' }
    dotnet test tests/Axiom.Tests -c Release --nologo --logger trx
    if ($LASTEXITCODE -ne 0) { throw 'Core regression tests failed.' }
    dotnet build src/Axiom.App -c Release -p:Platform=x64 --nologo
    if ($LASTEXITCODE -ne 0) { throw 'Native build failed.' }
    if ($Native) {
        $exe = Join-Path (Get-Location) 'src\Axiom.App\bin\x64\Release\net8.0-windows10.0.19041.0\win-x64\Axiom.App.exe'
        dotnet run --project tests/Axiom.UiTests -c Release -- $exe
        if ($LASTEXITCODE -ne 0) { throw 'Native UI Automation checks failed.' }
        $app = Start-Process -FilePath $exe -ArgumentList '--verify' -WindowStyle Hidden -PassThru
        if (-not $app.WaitForExit(60000)) { Stop-Process -Id $app.Id; throw 'Native verification timed out.' }
        if ($app.ExitCode -ne 0) { throw 'Native rendering verification failed.' }
    }
} finally { Pop-Location }
