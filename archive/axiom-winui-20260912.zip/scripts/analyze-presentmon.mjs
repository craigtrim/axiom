import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const [csvPath, framesDirectory, expectedPid] = process.argv.slice(2);
if (!csvPath || !framesDirectory || !/^\d+$/.test(expectedPid ?? ''))
  throw new Error('Usage: node scripts/analyze-presentmon.mjs <presentmon.csv> <frames-directory> <process-id>');

// PresentMon emits a conventional CSV. Quoted fields and escaped quotes are supported.
function parseCsv(source) {
  const rows = []; let row = [], field = '', quoted = false;
  for (let i = 0; i < source.length; i++) {
    const c = source[i];
    if (c === '"') {
      if (quoted && source[i + 1] === '"') { field += '"'; i++; }
      else quoted = !quoted;
    } else if (c === ',' && !quoted) { row.push(field); field = ''; }
    else if (c === '\n' && !quoted) { row.push(field.replace(/\r$/, '')); rows.push(row); row = []; field = ''; }
    else field += c;
  }
  if (quoted) throw new Error('Unclosed CSV field.');
  if (field || row.length) { row.push(field.replace(/\r$/, '')); rows.push(row); }
  return rows;
}
const csv = fs.readFileSync(csvPath, 'utf8').replace(/^\uFEFF/, '');
const [headers, ...values] = parseCsv(csv);
for (const name of ['ProcessID', 'TimeInQPC', 'SwapChainAddress', 'MsBetweenPresents', 'MsBetweenDisplayChange'])
  if (!headers.includes(name)) throw new Error('Missing required PresentMon column: ' + name);
const rows = values.filter(r => r.length > 1).map(r => {
  if (r.length !== headers.length) throw new Error('CSV column count differs from header.');
  return Object.fromEntries(headers.map((h, i) => [h, r[i]]));
});
if (!rows.length || rows.some(r => r.ProcessID !== expectedPid)) throw new Error('The CSV must contain only the requested application process.');
const summary = JSON.parse(fs.readFileSync(path.join(framesDirectory, 'summary.json'), 'utf8'));
if (!summary.HarnessSucceeded) throw new Error('The native frame harness did not complete.');
function statistics(items) {
  const sorted = items.filter(v => v !== '' && v !== 'NA').map(Number).filter(Number.isFinite).sort((a,b) => a-b);
  const percentile = p => sorted.length ? sorted[Math.max(0, Math.ceil(sorted.length * p) - 1)] : null;
  return { Samples: sorted.length, Missing: items.length - sorted.length, MedianMs: percentile(.5), P95Ms: percentile(.95), P99Ms: percentile(.99) };
}
const runs = [];
for (const file of fs.readdirSync(framesDirectory).filter(n => /^PB-\d+-.*-\d+\.json$/.test(n)).sort()) {
  const run = JSON.parse(fs.readFileSync(path.join(framesDirectory, file), 'utf8'));
  if (run.Frames.length < 600 || run.Frames.some(f => f.CanvasDraws !== 1)) throw new Error('Incomplete measured run: ' + file);
  const first = run.Frames[0], last = run.Frames.at(-1);
  const start = first.Timestamp, end = last.Timestamp + last.IntervalMs * summary.StopwatchFrequency / 1000;
  const measured = rows.filter(r => Number(r.TimeInQPC) >= start && Number(r.TimeInQPC) < end);
  const groups = Map.groupBy(measured, r => r.SwapChainAddress);
  const chains = [...groups].sort((a,b) => b[1].length - a[1].length).map(([address, presents]) => ({
    Address: address, Presents: presents.length, Modes: [...new Set(presents.map(r => r.PresentMode))],
    PresentInterval: statistics(presents.map(r => r.MsBetweenPresents)),
    DisplayInterval: statistics(presents.map(r => r.MsBetweenDisplayChange)),
    GpuBusy: statistics(presents.map(r => r.MsGPUBusy)),
    UntilDisplayed: statistics(presents.map(r => r.MsUntilDisplayed))
  }));
  if (!chains.length) throw new Error('No presentation events matched ' + file);
  runs.push({ File: file, Frames: run.Frames.length, StartQPC: start, EndQPC: end, DurationMs: (end-start)*1000/summary.StopwatchFrequency,
    MostActiveChain: chains[0].Address, Chains: chains });
}
const expectedRuns = summary.Results.reduce((sum,r) => sum+r.Repetitions, 0);
if (runs.length !== expectedRuns) throw new Error('Not all expected runs were found.');
const result = {
  ProcessID: Number(expectedPid), Csv: path.resolve(csvPath), CsvSHA256: crypto.createHash('sha256').update(fs.readFileSync(csvPath)).digest('hex'),
  FrameDirectory: path.resolve(framesDirectory), AnalysisDate: new Date().toISOString(),
  Matching: 'TimeInQPC within each measured draw window, after 30 warmup frames. Each swap chain is reported separately. MostActiveChain is inferred by event count; its native address is not instrumented in the app.',
  Interpretation: 'An external ETW observation of the targeted process. NA display samples remain missing, never zero. This trace does not certify the minimum machine, and traced runs are separate from the untraced baseline.',
  Runs: runs
};
const destination = path.join(path.dirname(path.resolve(csvPath)), 'analysis.json');
fs.writeFileSync(destination, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ Analysis: destination, Runs: runs.map(r => ({ File:r.File, Chains:r.Chains.length, ...r.Chains[0] })) }, null, 2));
