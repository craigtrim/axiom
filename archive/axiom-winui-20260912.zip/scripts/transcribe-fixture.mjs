// Transcribe FIX data only. Never execute the prototype.
import fs from 'node:fs';
import assert from 'node:assert/strict';
const source=fs.readFileSync('specs/62-pizza-ontology-fixture.md','utf8');
function table(marker) {
 const lines=source.slice(source.indexOf(marker)).split(/\r?\n/);
 const start=lines.findIndex(l=>l.startsWith('| # |'));assert(start>=0,marker);
 const rows=[];for(const line of lines.slice(start+2)){if(!line.startsWith('|'))break;rows.push(line.split('|').slice(1,-1).map(s=>s.trim().replaceAll(String.fromCharCode(96),'')));}
 return rows;
}
const empty=s=>s.startsWith('—')?'':s;
const iri=s=>(s.match(/(?:pizza|demo|owl|xsd):[A-Za-z]+/)??[''])[0];
const classes=table('**FIX-24**').map(r=>({iri:r[1],parents:[r[2]],kind:r[3]==='Defined'?'Defined':'Class',axioms:empty(r[4]),disjoint:empty(r[5]).split(', ').filter(Boolean),spiciness:empty(r[6]),comment:empty(r[7])}));
const pizzas=table('**FIX-27**').map(r=>({iri:r[1],toppings:r[3].split(', ').map(t=>'pizza:'+t)}));
const properties=table('**FIX-33**').map(r=>({iri:r[1],parent:iri(r[2]),domain:iri(r[3]),range:iri(r[4]),characteristics:empty(r[5]).split(', ').filter(Boolean),inverse:iri(r[6])}));
const demoClasses=table('**FIX-46**').map(r=>({iri:r[1],comment:r[4]}));
const dataProperties=table('**FIX-48**').map(r=>({iri:r[1],range:r[2],domain:r[3],comment:r[4]}));
const branches=table('**FIX-64**').map(r=>r[1]);
function names(marker){return table(marker).flatMap(r=>[[r[0],r[1]],[r[2],r[3]]]).filter(r=>r[0]).sort((a,b)=>+a[0]-b[0]).map(r=>r[1]);}
const firstNames=names('**FIX-65**'),lastNames=names('**FIX-66**');
const prices=Object.fromEntries(table('**FIX-68**').map(r=>[r[1],+r[2]]));
assert.equal(classes.length,70);assert.equal(pizzas.length,22);assert.equal(properties.length,8);assert.equal(firstNames.length,26);assert.equal(lastNames.length,25);
const fixture={classes,pizzas,properties,demoClasses,dataProperties,branches,firstNames,lastNames,prices};
fs.mkdirSync('src/Axiom.Fixture/Data',{recursive:true});
fs.writeFileSync('src/Axiom.Fixture/Data/pizza.json',JSON.stringify(fixture,null,2)+'\n');
console.log('Transcribed 70 classes, 22 pizzas, 8 properties and exact generator lists.');
