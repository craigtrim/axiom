param([switch]$Build)
$ErrorActionPreference = 'Stop'
$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$exe = Join-Path $repo 'src\Axiom.App\bin\x64\Release\net8.0-windows10.0.19041.0\win-x64\Axiom.App.exe'
if ($Build -or -not (Test-Path -LiteralPath $exe)) {
    dotnet build (Join-Path $repo 'src\Axiom.App') -c Release -p:Platform=x64 --nologo
    if ($LASTEXITCODE -ne 0) { throw 'Application build failed.' }
}
& $exe
