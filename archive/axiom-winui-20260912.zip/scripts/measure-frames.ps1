param(
    [string]$Executable,
    [ValidateSet('both','light','dark')][string]$Theme = 'both'
)
$ErrorActionPreference = 'Stop'
$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if (-not $Executable) {
    $Executable = Join-Path $repo 'src\Axiom.App\bin\x64\Release\net8.0-windows10.0.19041.0\win-x64\Axiom.App.exe'
}
$Executable = (Resolve-Path -LiteralPath $Executable).Path
Push-Location $repo
try {
    $frameArguments = @('--performance')
    if ($Theme -ne 'both') { $frameArguments += "--performance-theme=$Theme" }
    $started = [DateTimeOffset]::UtcNow
    $process = Start-Process -FilePath $Executable -ArgumentList $frameArguments -WindowStyle Hidden -PassThru
    $deadline = $started.AddMinutes(20)
    while (-not $process.WaitForExit(1000)) {
        if ([DateTimeOffset]::UtcNow -gt $deadline) {
            Stop-Process -Id $process.Id
            throw 'Frame measurement timed out.'
        }
    }
    if ($process.ExitCode -ne 0) { throw 'The native frame harness failed.' }
    $directory = (Get-Content -LiteralPath 'artifacts/latest-frames.txt' -Raw).Trim()
    $resultPath = Join-Path $directory 'summary.json'
    if ((Get-Item -LiteralPath $resultPath).LastWriteTimeUtc -lt $started.UtcDateTime) { throw 'The frame report is stale.' }
    $result = Get-Content -LiteralPath $resultPath -Raw | ConvertFrom-Json
    if (-not $result.HarnessSucceeded) { throw ('Frame measurement failed: ' + $result.Error) }
    [ordered]@{
        OS = (Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber)
        CPU = (Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors)
        Display = (Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,CurrentHorizontalResolution,CurrentVerticalResolution,CurrentRefreshRate)
        PhysicalMemoryBytes = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory
        ExecutableSHA256 = (Get-FileHash -LiteralPath $Executable -Algorithm SHA256).Hash
        AppAssemblySHA256 = (Get-FileHash -LiteralPath ([IO.Path]::ChangeExtension($Executable, ".dll")) -Algorithm SHA256).Hash
    } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $directory 'machine.json') -Encoding utf8
    $result.Results | Format-Table Requirement,Theme,MedianP95WorkMs,MedianP99WorkMs,MedianP95DrawIntervalMs,CpuWorkBudgetMet
    Write-Output "Raw frames and summary: $directory"
} finally { Pop-Location }
