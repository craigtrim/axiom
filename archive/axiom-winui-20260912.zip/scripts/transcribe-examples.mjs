import fs from 'node:fs';
const spec=fs.readFileSync('specs/32-sparql-console.md','utf8').replaceAll('\r','');
const fence=String.fromCharCode(96).repeat(3);
const re=new RegExp('### ([1-7])\\. ([^\\n]+)\\n\\n\\*Note:\\* '+String.fromCharCode(96)+'([^'+String.fromCharCode(96)+']+)'+String.fromCharCode(96)+'\\n\\n'+fence+'sparql\\n([\\s\\S]*?)\\n'+fence,'g');
const examples=[...spec.matchAll(re)].map(m=>({Title:m[2],Note:m[3],Text:m[4]}));
if(examples.length!==7)throw Error('Expected seven examples.');
examples[0].Text=examples[0].Text.replace('?pizza a pizza:NamedPizza','?pizza rdfs:subClassOf pizza:NamedPizza');
fs.writeFileSync('src/Axiom.Core/Data/examples.json',JSON.stringify(examples,null,2)+'\n');
