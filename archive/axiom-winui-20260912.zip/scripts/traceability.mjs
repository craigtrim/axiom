import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const core='src/Axiom.Core/',app='src/Axiom.App/',test='tests/Axiom.Tests/';
const routes={
 OVR:['README.md;docs/decisions.md',test+'HardeningTests.cs;docs/verification.md'],
 ARCH:[core+'Store.cs;'+core+'Selection.cs;'+app+'MainWindow.cs;'+app+'MainWindow.Surfaces.cs',test+'MutationTableTests.cs;'+test+'SelectionInspectorTests.cs;tests/Axiom.UiTests/Program.cs'],
 STORE:[core+'Domain.cs;'+core+'Store.cs;'+core+'TripleSource.cs;'+core+'Mutations.cs',test+'FixtureTests.cs;'+test+'MutationTableTests.cs;'+test+'HardeningTests.cs'],
 VP:[core+'Viewport.cs;'+app+'GraphView.cs;'+app+'GraphPeer.cs',test+'ViewportTests.cs;'+test+'HardeningTests.cs;'+test+'HitIndexTests.cs;'+test+'SelectionInspectorTests.cs;tests/Axiom.UiTests/Program.cs'],
 LAY:[core+'Layouts.cs;'+core+'ForceLayout.cs;'+core+'ComputedLayouts.cs',test+'ViewportTests.cs;'+test+'ScaleLayoutTests.cs;'+test+'ForceReuseTests.cs;'+test+'AccessibilityLayoutTests.cs;tools/Axiom.Benchmarks/Program.cs'],
 REN:[core+'Rendering.cs;'+core+'SvgDraw.cs;'+app+'Win2DDraw.cs;'+app+'GraphExport.cs;'+app+'GraphView.cs;'+app+'GraphCanvas.cs;'+app+'GraphPerformance.cs',test+'BadgeContractTests.cs;'+test+'RenderingTests.cs;'+test+'ExportContractTests.cs;'+test+'ParallelRouteTests.cs;'+test+'ScaleLayoutTests.cs;'+app+'GraphDiagnostics.cs'],
 TREE:[app+'HierarchyView.cs;'+app+'HierarchyEditing.cs;'+app+'InspectorView.cs;'+app+'MainWindow.Dialogs.cs;'+core+'Mutations.cs',test+'MutationTableTests.cs;tests/Axiom.UiTests/Program.cs'],
 TBL:[core+'TableModel.cs;'+core+'Mutations.cs;'+app+'IndividualsView.cs;'+app+'VirtualGrid.cs;'+app+'GridPeer.cs;'+app+'GridHeader.cs;'+app+'MainWindow.Dialogs.cs',test+'CreationContractTests.cs;'+test+'MutationTableTests.cs;tests/Axiom.UiTests/DialogJourneys.cs;tests/Axiom.UiTests/Program.cs;'+app+'MainWindow.Diagnostics.cs'],
 SPQ:[core+'Query.cs;'+core+'QueryExamples.cs;'+app+'QueryView.cs;'+app+'VirtualGrid.cs',test+'QueryTests.cs;'+test+'QueryErrorTests.cs;tests/Axiom.UiTests/Program.cs'],
 DS:[core+'DesignTokens.cs;'+core+'Data/tokens.json;'+app+'Theme.cs;'+app+'Ui.cs;'+app+'WrapRow.cs;'+app+'MainWindow.Responsive.cs',test+'AccessibilityLayoutTests.cs;'+test+'RenderingTests.cs;'+test+'HardeningTests.cs;docs/verification.md'],
 CMP:[app+'Theme.cs;'+app+'Ui.cs;'+app+'TabStrip.cs;'+app+'MainWindow.cs;'+app+'VirtualGrid.cs',test+'MutationTableTests.cs;tests/Axiom.UiTests/Program.cs;docs/verification.md'],
 IMP:['docs/progress.md;docs/decisions.md;scripts/verify.ps1;scripts/build-package.ps1;scripts/build-bundle.ps1','docs/verification.md;docs/traceability.csv'],
 ACC:['scripts/verify.ps1;'+app+'MainWindow.Diagnostics.cs;'+app+'MainWindow.Performance.cs;scripts/measure-frames.ps1;scripts/analyze-presentmon.mjs;tools/Axiom.Benchmarks/Program.cs','docs/verification.md;docs/traceability.csv'],
 FIX:['src/Axiom.Fixture/PizzaFixture.cs;src/Axiom.Fixture/Data/pizza.json;scripts/transcribe-fixture.mjs',test+'FixtureTests.cs;'+test+'QueryTests.cs'],
 DEF:['docs/decisions.md;'+core+'Query.cs;'+core+'Store.cs;'+app+'MainWindow.cs',test+'HardeningTests.cs;'+test+'QueryTests.cs;'+test+'QueryErrorTests.cs']
};
const decisions={
 'STORE-62':'Decision 2: include the flattened restriction index.',
 'FIX-92':'Decision 2 supersedes the old 239-only triple count.',
 'VP-122':'Decision 3: reject reductions below the protected population.',
 'LAY-180':'Decision 10: multiple roots occupy an inner ring.',
 'ARCH-116':'Decision 4: reduced motion settles before paint.',
 'SPQ-87':'Decision 9: unbound FILTER operands evaluate false.',
 'DEF-14':'Decision 2: truthful counts include 140 derived triples.',
 'REN-85':'Decision 11: fan reciprocal edges using the unordered pair orientation.'
};
const rows=[],seen=new Set();
for(const name of fs.readdirSync(path.join(root,'specs')).filter(n=>n.endsWith('.md')).sort()){
 const lines=fs.readFileSync(path.join(root,'specs',name),'utf8').split(/\r?\n/);let section='';
 for(let i=0;i<lines.length;i++){
  if(/^#{1,4} /.test(lines[i]))section=lines[i].replace(/^#+ /,'');
  const match=lines[i].match(/^\*\*([A-Z]+-\d+)\b[^*]*\*\*/)??lines[i].match(/^### (DEF-\d+)\b/);
  if(!match)continue;
  const id=match[1],prefix=id.split('-')[0];if(prefix==='TC')continue;if(!routes[prefix])throw new Error('Unmapped prefix '+prefix);
  if(seen.has(id))throw new Error('Duplicate requirement '+id);seen.add(id);
  const [implementation,verification]=routes[prefix];
  let statement=lines[i];for(let j=i+1;j<lines.length&&lines[j].trim()&&!/^#|^\*\*[A-Z]+-\d+/.test(lines[j]);j++)statement+=' '+lines[j];
  rows.push([id,'specs/'+name,i+1,section,statement,implementation,verification,'Mapped; individual conformance audit pending',decisions[id]??'Mapping identifies the implementation and relevant evidence. It is not a per-requirement pass assertion.']);
 }
}
if(rows.length<2000)throw new Error('Unexpectedly incomplete requirement extraction: '+rows.length);
for(const row of rows)for(const file of (row[5]+';'+row[6]).split(';'))if(!file.endsWith('traceability.csv')&&!fs.existsSync(path.join(root,file)))throw new Error('Missing mapped file '+file);
const quote=value=>'"'+String(value).replaceAll('"','""')+'"';
const output=[['Requirement','Specification','Line','Section','Statement','Implementation','Verification','Status','Notes'],...rows].map(r=>r.map(quote).join(',')).join('\n')+'\n';
const destination=path.join(root,'docs/traceability.csv');
if(process.argv.includes('--check')){
 if(!fs.existsSync(destination)||fs.readFileSync(destination,'utf8')!==output)throw new Error('Requirement map is stale. Run node scripts/traceability.mjs.');
}else fs.writeFileSync(destination,output);
const counts={};for(const row of rows){const p=row[0].split('-')[0];counts[p]=(counts[p]??0)+1;}
console.log(JSON.stringify({requirements:rows.length,byPrefix:counts,mode:process.argv.includes('--check')?'checked':'generated'}));
