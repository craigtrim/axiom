param(
    [string]$X64Package,
    [string]$Arm64Package,
    [string]$Version = '0.1.1.0',
    [string]$CertificateThumbprint
)
$ErrorActionPreference = 'Stop'
$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if (-not $X64Package -or -not $Arm64Package) {
    $records = @('x64', 'arm64') | ForEach-Object {
        Get-Content -LiteralPath (Join-Path $repo ('artifacts/latest-' + $_ + '.json')) -Raw | ConvertFrom-Json
    }
    if ($records[0].Version -ne $Version -or $records[1].Version -ne $Version) {
        throw 'Build both architectures with the requested bundle version first.'
    }
    if (-not $X64Package) { $X64Package = $records[0].Package }
    if (-not $Arm64Package) { $Arm64Package = $records[1].Package }
}
$inputs = @((Resolve-Path -LiteralPath $X64Package).Path, (Resolve-Path -LiteralPath $Arm64Package).Path)
$build = Join-Path $repo ('artifacts/bundle-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$stage = Join-Path $build 'packages'
New-Item -ItemType Directory -Path $stage -Force | Out-Null
foreach ($package in $inputs) { Copy-Item -LiteralPath $package -Destination $stage }
$kits = Join-Path ([Environment]::GetEnvironmentVariable('ProgramFiles(x86)')) 'Windows Kits/10/bin'
$makeappx = Get-ChildItem -LiteralPath $kits -Filter makeappx.exe -Recurse |
    Where-Object { $_.Directory.Name -eq 'x64' } |
    Sort-Object FullName -Descending |
    Select-Object -First 1
if (-not $makeappx) { throw 'Install the Windows SDK packaging tools to build the bundle.' }
$bundle = Join-Path $build ("Axiom-" + $Version + ".msixbundle")
& $makeappx.FullName bundle /d $stage /p $bundle /bv $Version /o
if ($LASTEXITCODE -ne 0) { throw 'Bundle validation failed.' }
if ($CertificateThumbprint) {
    $signtool = Join-Path $makeappx.Directory.FullName 'signtool.exe'
    & $signtool sign /fd SHA256 /sha1 $CertificateThumbprint $bundle
    if ($LASTEXITCODE -ne 0) { throw 'Bundle signing failed.' }
    & $signtool verify /pa $bundle
    if ($LASTEXITCODE -ne 0) { throw 'Bundle signature verification failed.' }
}
$record = [ordered]@{
    Version = $Version
    Bundle = $bundle
    Architectures = @('x64', 'arm64')
    Packages = $inputs
    SHA256 = (Get-FileHash -LiteralPath $bundle -Algorithm SHA256).Hash
    Signed = [bool]$CertificateThumbprint
    BuiltUtc = [DateTimeOffset]::UtcNow.ToString('o')
}
$record | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $build 'release.json') -Encoding utf8
$record | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $repo 'artifacts/latest-bundle.json') -Encoding utf8
Write-Output ("Bundle: " + $bundle)
if (-not $CertificateThumbprint) { Write-Output 'This development bundle is unsigned.' }
