param(
    [ValidateSet('x64','arm64')][string]$Architecture = 'x64',
    [string]$Publisher = 'CN=Axiom Development',
    [string]$CertificateThumbprint,
    [string]$Version = '0.1.1.0'
)
$ErrorActionPreference = 'Stop'
$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$build = Join-Path $repo ('artifacts\release-' + $Architecture + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$stage = Join-Path $build 'payload'
if (-not [IO.Path]::GetFullPath($stage).StartsWith($repo + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Package staging must remain within this repository.' }
New-Item -ItemType Directory -Path $stage -Force | Out-Null
$platform = if ($Architecture -eq 'arm64') { 'ARM64' } else { 'x64' }
dotnet publish (Join-Path $repo 'src\Axiom.App') -c Release -p:Platform=$platform -r "win-$Architecture" "-p:Version=$Version" --self-contained true -o $stage --nologo
if ($LASTEXITCODE -ne 0) { throw 'Publish failed.' }
foreach ($resource in @('App.xbf','Axiom.App.pri','coreclr.dll','Microsoft.UI.Xaml.dll','Microsoft.Graphics.Canvas.dll')) {
    if (-not (Test-Path -LiteralPath (Join-Path $stage $resource))) { throw ('Published payload is missing ' + $resource) }
}
& (Join-Path $PSScriptRoot 'build-assets.ps1') -OutputDirectory (Join-Path $stage 'Assets')
[xml]$manifest = Get-Content -LiteralPath (Join-Path $repo 'packaging\AppxManifest.xml')
$manifest.Package.Identity.ProcessorArchitecture = $Architecture
$manifest.Package.Identity.Publisher = $Publisher
$manifest.Package.Identity.Version = $Version
$manifest.Save((Join-Path $stage 'AppxManifest.xml'))
$kits = Join-Path ([Environment]::GetEnvironmentVariable('ProgramFiles(x86)')) 'Windows Kits\10\bin'
$makeappx = Get-ChildItem -LiteralPath $kits -Filter makeappx.exe -Recurse | Where-Object { $_.Directory.Name -eq 'x64' } | Sort-Object FullName -Descending | Select-Object -First 1
if (-not $makeappx) { throw 'Install the Windows SDK packaging tools to build MSIX.' }
$package = Join-Path $build "Axiom-$Version-$Architecture.msix"
& $makeappx.FullName pack /d $stage /p $package /o
if ($LASTEXITCODE -ne 0) { throw 'MSIX validation or packaging failed.' }
if ($CertificateThumbprint) {
    $signtool = Join-Path $makeappx.Directory.FullName 'signtool.exe'
    & $signtool sign /fd SHA256 /sha1 $CertificateThumbprint $package
    if ($LASTEXITCODE -ne 0) { throw 'Package signing failed. Check the certificate identity and manifest publisher.' }
    & $signtool verify /pa $package
    if ($LASTEXITCODE -ne 0) { throw 'Package signature verification failed.' }
} else { Write-Output 'Development package is unsigned. A trusted release certificate is required before distribution.' }
$checksum = Get-FileHash -LiteralPath $package -Algorithm SHA256
$record = [ordered]@{ Architecture=$Architecture; Version=$Version; Package=$package; Executable=(Join-Path $stage 'Axiom.App.exe'); SHA256=$checksum.Hash; Signed=[bool]$CertificateThumbprint; BuiltUtc=[DateTimeOffset]::UtcNow.ToString('o') }
$record | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $build 'release.json') -Encoding utf8
$record | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $repo ('artifacts\latest-' + $Architecture + '.json')) -Encoding utf8
$checksum | Format-List
Write-Output "Package: $package"
Write-Output "Portable executable: $(Join-Path $stage 'Axiom.App.exe')"
