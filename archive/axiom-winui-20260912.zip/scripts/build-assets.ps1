param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
foreach ($entry in @(@('StoreLogo.png',50),@('Square44x44Logo.png',44),@('Square150x150Logo.png',150))) {
    $size = [int]$entry[1]
    $bitmap = [Drawing.Bitmap]::new($size,$size)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    try {
        $graphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $graphics.Clear([Drawing.Color]::Transparent)
        $pen = [Drawing.Pen]::new([Drawing.ColorTranslator]::FromHtml('#0F6CBD'),[single]($size * 0.055))
        $brush = [Drawing.SolidBrush]::new([Drawing.ColorTranslator]::FromHtml('#0F6CBD'))
        try {
            [Drawing.PointF[]]$points = @([Drawing.PointF]::new($size*.5,$size*.2),[Drawing.PointF]::new($size*.2,$size*.78),[Drawing.PointF]::new($size*.8,$size*.78))
            $graphics.DrawPolygon($pen,$points)
            foreach ($point in $points) { $graphics.FillRectangle($brush,$point.X-$size*.09,$point.Y-$size*.09,$size*.18,$size*.18) }
            $bitmap.Save((Join-Path $OutputDirectory $entry[0]),[Drawing.Imaging.ImageFormat]::Png)
        } finally { $pen.Dispose(); $brush.Dispose() }
    } finally { $graphics.Dispose(); $bitmap.Dispose() }
}
