using System.Diagnostics;
using System.Text.Json;
using Axiom.Core;
using Axiom.Fixture;
var samples = new List<object>();
void Measure(string name, int size, Action action, int repeats = 9)
{
    action();
    var values = new double[repeats];
    for (var i = 0; i < repeats; i++)
    {
        var sw = Stopwatch.StartNew();
        action();
        values[i] = sw.Elapsed.TotalMilliseconds;
    }
    Array.Sort(values);
    samples.Add(new
    {
        Name = name,
        Size = size,
        MedianMs = values[repeats / 2],
        P95Ms = values[(int)Math.Ceiling(repeats * .95) - 1],
        Samples = values
    });
}
foreach (var size in PizzaFixture.Sizes)
{
    var store = PizzaFixture.Build(size);
    var engine = new QueryEngine(store);
    Measure("PB-14 named pizzas", size, () => engine.Execute(QueryExamples.All[0].Text));
    Measure("PB-15 Shoreditch orders", size, () => engine.Execute(QueryExamples.All[3].Text));
    Measure("PB-16 customer join", size, () => engine.Execute(QueryExamples.All[4].Text));
}
var large = PizzaFixture.Build(100000);
Measure("PB-09 class adjacency", 100000, () => large.Neighbours(Ns.Pizza + "Margherita"));
Measure("PB-09 customer adjacency", 100000, () => large.Neighbours(Ns.Demo + "Customer"));
Measure("PB-23 generation and indexes", 100000, () => { var data = PizzaFixture.Generate(100000); var store = new Store(); store.LoadGenerated(data.Individuals, data.Customers); });
var table = new TableModel(large) { Query = "margherita soho" };
Measure("PB-10 table filter", 100000, table.Apply);
table.Reset();
table.ToggleSort("price");
Measure("PB-11 table sort", 100000, table.Apply);
var view = new Viewport(large);
view.SetBudget(3000);
view.Seed(large.Entities.Keys.Concat(large.Individuals.Select(i => i.Iri)).Take(3000), expand: false);
foreach (var mode in new[] { "force", "hierarchy", "radial", "grid" }) { var layouts = new Layouts(view, large) { Choice = mode }; Measure(mode == "force" ? "PB-04 force settled" : "layout " + mode, 3000, () => layouts.Run(true, true), 5); }
var l = new Layouts(view, large) { Choice = "grid" };
l.Run();
using (var measurement = new SvgDraw(1600, 1000, (text, size, _, _) => text.Length * size * .55)) Measure("PB-08 placement (synthetic cached metrics)", 3000, () => SceneRenderer.Labels(measurement, view, Camera.Fit(view, 1600, 1000), 1600, 1000, null));
var result = new { Date = DateTimeOffset.UtcNow, OS = Environment.OSVersion.ToString(), Runtime = Environment.Version.ToString(), ProcessorCount = Environment.ProcessorCount, Machine = Environment.MachineName, MinimumTargetCertification = false, Measurements = samples };
Directory.CreateDirectory("artifacts");
File.WriteAllText("artifacts/performance.json", JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine(JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
