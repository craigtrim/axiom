# Axiom

Axiom is a native Windows ontology workbench built with WinUI 3 and Win2D. It includes the specified Pizza ontology fixture and a deterministic generated dataset of up to 100,000 pizza orders.

The application has a class and property hierarchy, an inspector, a bounded graph with four layouts, a virtualized editable individuals table, and a SELECT query console. PNG, SVG and clipboard exports use the graph renderer.

## Build and run

Install .NET 8 SDK and the Windows SDK on Windows. Restore requires NuGet access; the application runs offline.

    dotnet build src/Axiom.App -c Release -p:Platform=x64

Launch from PowerShell:

    ./scripts/run.ps1

Or run the executable directly:

    src\Axiom.App\bin\x64\Release\net8.0-windows10.0.19041.0\win-x64\Axiom.App.exe

Run the domain regression suite on Windows, Linux or macOS:

    dotnet test tests/Axiom.Tests -c Release

On an interactive Windows desktop, run native UI and rendering verification:

    powershell -File scripts/verify.ps1 -Native

For 600 consecutive drawn frames per run, with three repeats of each scenario in both themes:

    powershell -File scripts/measure-frames.ps1

The verification mode writes screenshots and measurement reports under artifacts. Ordinary application use writes no files except requested exports.

## Using the workbench

Select an entity in any surface to update the shared selection and inspector. Double-click or choose Show in graph to reveal it. Single selection leaves the viewport membership unchanged.

The graph admits at most its Budget. Focus and pinned nodes survive eviction. A budget reduction below the protected population is rejected with the required minimum. Choose a layout, expand neighbours, inspect the held-back counts, and export the entire viewport independently of pan and zoom.

The individuals table supports type, branch and text filters. Click Branch, Price or Rating to edit; validation and Undo apply to the underlying Store. Send page to graph takes the first Budget rows in the current filtered and sorted result.

The query console supports flat SELECT patterns, binary FILTER comparisons, DISTINCT, ORDER BY and LIMIT. It is not SPARQL 1.1. Comparisons with an unbound variable do not pass FILTER. The seven built-in examples run against the same Store data, using a consistent snapshot when the user edits or regenerates during execution.

| Context | Keyboard shortcuts |
| --- | --- |
| Application | Ctrl+F search, Ctrl+Z undo, Ctrl+S save-status message |
| Hierarchy | Arrows navigate, Enter reveal, F2 rename, Delete class |
| Graph | Arrows select, Enter expand, F fit, L relayout, P pin, Space freeze, Delete remove from viewport |
| Table | Arrows navigate, Home/End within a row, Ctrl+Home/End across rows, Page Up/Down, Enter or F2 edit, Enter on read-only cells reveals |
| Cell editor | Enter commit, Escape cancel |
| Query editor | Ctrl+Enter run, Tab insert two spaces, Ctrl+Tab or Escape leave editor |

Save explicitly reports that OWL serialization is not implemented. Real file import, reasoning, persistence and networking are outside the v1 specification.

## Packages and verification

    powershell -File scripts/build-package.ps1 -Architecture x64 -Version 0.1.1.0
    powershell -File scripts/build-package.ps1 -Architecture arm64 -Version 0.1.1.0
    powershell -File scripts/build-bundle.ps1 -Version 0.1.1.0

These commands produce self-contained payloads, MSIX packages and a bundle containing both architectures under artifacts. The latest build paths and SHA256 hashes are recorded in artifacts/latest-x64.json, artifacts/latest-arm64.json and artifacts/latest-bundle.json. Without a signing certificate they are development artifacts. Pass Publisher and CertificateThumbprint for a configured release identity. No certificate is created or installed by the scripts.

The current build passes 150 domain and geometry tests and 15 native automation journeys. The graph uses a Win2D composition swap chain. Creation dialogs support customer and rating choices, accessible validation, focus restoration and Undo. Narrow windows wrap their controls and restore the inspector when widened.

Full specification acceptance remains open, including presentation performance, the complete accessibility matrix and release installation. See the verification record for measured results and platform limitations.

The package targets Windows 11. The current workspace runs Windows 10, so clean Windows 11 installation, trusted release signing, Narrator review and the minimum-machine performance audit remain release gates. See [implementation decisions](docs/decisions.md), [verification](docs/verification.md) and the [requirement map](docs/traceability.csv).

| Project | Responsibility |
| --- | --- |
| Axiom.Core | Store, indexes, mutations, graph, layouts, query engine and shared scene renderer |
| Axiom.Fixture | Specification-transcribed ontology and deterministic generated records |
| Axiom.App | Native controls, accessibility peers, Win2D rendering and export |
| Axiom.Tests | Domain, fixture, regression, geometry, virtualization and contrast tests |
| Axiom.UiTests | Native UI Automation journeys |
| Axiom.Benchmarks | Repeatable computation timing distributions |
