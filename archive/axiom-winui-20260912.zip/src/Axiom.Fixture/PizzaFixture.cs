using System.Text.Json;
using Axiom.Core;
namespace Axiom.Fixture;

public static class PizzaFixture
{
    public const int DefaultSize = 12000;
    public static readonly int[] Sizes = [1000, 12000, 50000, 100000];
    private static readonly JsonElement Data = Load();
    private static JsonElement Load()
    {
        using var stream = typeof(PizzaFixture).Assembly.GetManifestResourceStream("Axiom.Fixture.Data.pizza.json")!;
        using var doc = JsonDocument.Parse(stream);
        return doc.RootElement.Clone();
    }
    private static string S(JsonElement e, string name) => e.GetProperty(name).GetString()!;
    private static IEnumerable<string> Strings(JsonElement e) => e.EnumerateArray().Select(v => v.GetString()!);
    public static readonly string[] Branches = Strings(Data.GetProperty("branches")).ToArray();
    public static readonly string[] PizzaNames = Data.GetProperty("pizzas").EnumerateArray().Select(p => Ns.Local(Ns.Expand(S(p, "iri")))).ToArray();
    public static Store Build(int n = DefaultSize)
    {
        var store = new Store();
        BuildTBox(store);
        var data = Generate(n);
        store.LoadGenerated(data.Individuals, data.Customers);
        return store;
    }
    public static void BuildTBox(Store store)
    {
        if (store.Entities.Count != 0)
            throw new InvalidOperationException("The TBox has already been built.");
        void T(string s, string p, string o) => store.TBox.Add(new(s, p, new(o)));
        store.AddEntity(Ns.Thing, EntityKind.Class).Comment = "The universal class. Everything is a Thing.";
        foreach (var row in Data.GetProperty("classes").EnumerateArray())
        {
            var iri = Ns.Expand(S(row, "iri"));
            var e = store.AddEntity(iri, Enum.Parse<EntityKind>(S(row, "kind")));
            e.Parents = Strings(row.GetProperty("parents")).Select(Ns.Expand).ToList();
            e.Comment = S(row, "comment");
            e.DisjointWith = Strings(row.GetProperty("disjoint")).Select(Ns.Expand).ToList();
            foreach (var p in e.Parents)
                T(iri, Ns.SubClass, p);
            T(iri, Ns.Type, Ns.Owl + "Class");
            if (e.Comment != "")
                store.TBox.Add(new(iri, Ns.Rdfs + "comment", Term.Literal(e.Comment)));
            foreach (var d in e.DisjointWith)
                T(iri, Ns.Owl + "disjointWith", d);
            var ax = S(row, "axioms");
            if (ax.StartsWith("EquivalentTo: "))
                e.Equivalents = ax[14..].Split(" and ").Select(Restriction.Parse).ToList();
            else if (ax != "")
                e.Restrictions = ax.Split("<br>").Select(s => Restriction.Parse(s.Replace("SubClassOf: ", ""))).ToList();
            var spice = S(row, "spiciness");
            if (spice != "")
                e.Restrictions.Add(Restriction.Parse(spice.Replace("SubClassOf: ", "")));
        }
        foreach (var row in Data.GetProperty("pizzas").EnumerateArray())
        {
            var iri = Ns.Expand(S(row, "iri"));
            var e = store.AddEntity(iri, EntityKind.Class);
            e.Parents = [Ns.Pizza + "NamedPizza"];
            e.Comment = "A named pizza from the menu.";
            var toppings = Strings(row.GetProperty("toppings")).Select(Ns.Expand).ToArray();
            foreach (var topping in toppings)
                e.Restrictions.Add(new("restriction", Ns.Pizza + "hasTopping", "some", [topping]));
            e.Restrictions.Add(new("restriction", Ns.Pizza + "hasTopping", "only", toppings));
            e.Restrictions.Add(new("restriction", Ns.Pizza + "hasCountryOfOrigin", "value", [Ns.Pizza + "Italy"]));
            T(iri, Ns.SubClass, Ns.Pizza + "NamedPizza");
            T(iri, Ns.Type, Ns.Owl + "Class");
        }
        foreach (var row in Data.GetProperty("properties").EnumerateArray())
        {
            var iri = Ns.Expand(S(row, "iri"));
            var e = store.AddEntity(iri, EntityKind.ObjectProperty);
            string? Get(string key) => S(row, key) is var s && s != "" ? Ns.Expand(s) : null;
            if (Get("parent") is { } parent)
            {
                e.Parents = [parent];
                T(iri, Ns.SubProperty, parent);
            }
            e.Domain = Get("domain");
            e.Range = Get("range");
            e.Inverse = Get("inverse");
            e.Characteristics = Strings(row.GetProperty("characteristics")).ToList();
            T(iri, Ns.Type, Ns.Owl + "ObjectProperty");
            if (e.Domain is not null)
                T(iri, Ns.Rdfs + "domain", e.Domain);
            if (e.Range is not null)
                T(iri, Ns.Rdfs + "range", e.Range);
        }
        foreach (var country in new[] { "America", "England", "France", "Germany", "Italy" })
        {
            var e = store.AddEntity(Ns.Pizza + country, EntityKind.Individual);
            e.Types = [Ns.Pizza + "Country"];
            e.Comment = "Named individual of pizza:Country.";
            T(e.Iri, Ns.Type, e.Types[0]);
        }
        foreach (var name in new[] { "Hot", "Medium", "Mild" })
            store.Entities[Ns.Pizza + name].IsValuePartition = true;
        foreach (var row in Data.GetProperty("demoClasses").EnumerateArray())
        {
            var e = store.AddEntity(Ns.Expand(S(row, "iri")), EntityKind.Class);
            e.Parents = [Ns.Thing];
            e.Comment = S(row, "comment");
            T(e.Iri, Ns.SubClass, Ns.Thing);
        }
        foreach (var row in Data.GetProperty("dataProperties").EnumerateArray())
        {
            var e = store.AddEntity(Ns.Expand(S(row, "iri")), EntityKind.DataProperty);
            e.Domain = Ns.Expand(S(row, "domain"));
            e.Range = Ns.Expand(S(row, "range"));
            e.Comment = S(row, "comment");
            T(e.Iri, Ns.Type, Ns.Owl + "DatatypeProperty");
        }
        var orderedBy = store.AddEntity(Ns.Demo + "orderedBy", EntityKind.ObjectProperty);
        orderedBy.Domain = Ns.Demo + "Order";
        orderedBy.Range = Ns.Demo + "Customer";
        orderedBy.Comment = "Generated demo data. Links a produced pizza to its customer.";
        T(orderedBy.Iri, Ns.Type, Ns.Owl + "ObjectProperty");
        store.RebuildSchemaIndexes();
    }
    // FIX-61/70/73: unsigned wraparound and exact draw order.
    public static (List<Individual> Individuals, List<Customer> Customers) Generate(int n)
    {
        if (n < 0 || n > 1_000_000)
            throw new ArgumentOutOfRangeException(nameof(n));
        var rng = new FixtureRandom();
        var first = Strings(Data.GetProperty("firstNames")).ToArray();
        var last = Strings(Data.GetProperty("lastNames")).ToArray();
        var customers = new List<Customer>(Math.Max(24, (int)Math.Floor(n / 8d + 0.5)));
        T Pick<T>(IReadOnlyList<T> a) => a[(int)(rng.Next() * a.Count)];
        for (var c = 0; c < customers.Capacity; c++)
            customers.Add(new(Ns.Demo + "Customer_" + (c + 1).ToString("D6"), Pick(first) + " " + Pick(last)));
        var orders = new List<Individual>(n);
        var pad = Math.Max(6, n.ToString().Length);
        for (var i = 0; i < n; i++)
        {
            var type = Pick(PizzaNames);
            var branch = Pick(Branches);
            var price = Data.GetProperty("prices").TryGetProperty(type, out var p) ? p.GetDouble() : 11;
            orders.Add(new()
            {
                Index = i,
                Iri = Ns.Demo + "Pizza_" + (i + 1).ToString("D" + pad),
                Type = Ns.Pizza + type,
                Reference = "AX-" + ((100000 + i) % 1000000).ToString("D6"),
                Branch = branch,
                Price = Math.Floor((price + (rng.Next() * 3 - 1)) * 100 + 0.5) / 100,
                Timestamp = (1785542400L + (long)Math.Floor(rng.Next() * 2592000)) * 1000,
                Rating = Math.Clamp(3 + (int)Math.Floor(rng.Next() * 3) - (rng.Next() < 0.12 ? 2 : 0), 1, 5),
                CustomerIndex = (int)(rng.Next() * customers.Count)
            });
        }
        return (orders, customers);
    }
}
public sealed class FixtureRandom
{
    private uint state = 20250911;
    public double Next()
    {
        unchecked
        {
            state = state * 1664525u + 1013904223u;
        }
        return state / 4294967296d;
    }
}
