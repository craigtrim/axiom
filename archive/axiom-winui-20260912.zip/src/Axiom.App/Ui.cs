using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Media;
namespace Axiom.App;
public static class Ui
{
    public static PathIcon VectorIcon(string data) => (PathIcon)Microsoft.UI.Xaml.Markup.XamlReader.Load("<PathIcon xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" Width=\"16\" Height=\"16\" Data=\"" + data + "\" />");
    public static T Named<T>(T element, string name) where T : DependencyObject
    {
        AutomationProperties.SetName(element, name);
        return element;
    }
    public static TextBlock Text(string text, double size = double.NaN, string colour = "text") => new() { Text = text, FontSize = double.IsNaN(size) ? Theme.Body : size, FontFamily = new FontFamily(Theme.UiFont), Foreground = Theme.Brush(colour), VerticalAlignment = VerticalAlignment.Center };
    public static Button Button(string label, Action action, string? hint = null)
    {
        var b = Named(new Button { Content = label }, hint ?? label);
        b.Click += (_, _) => action();
        ToolTipService.SetToolTip(b, hint ?? label);
        return b;
    }
    public static TabButton Tab(string label, Action action)
    {
        var tab = Named(new TabButton { Content = label, Activate = action }, label);
        tab.Click += (_, _) => tab.Select();
        return tab;
    }
    public static TextBox Field(string name, string placeholder = "") => Named(new TextBox { PlaceholderText = placeholder, Background = Theme.Brush("surface"), Foreground = Theme.Brush("text"), BorderBrush = Theme.Brush("stroke-strong") }, name);
    public static WrapRow Wrap(params UIElement[] controls)
    {
        var row = new WrapRow();
        foreach (var control in controls)
            row.Children.Add(control);
        return row;
    }
    public static StackPanel Row(params UIElement[] controls)
    {
        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = Theme.S2 };
        foreach (var c in controls)
            row.Children.Add(c);
        return row;
    }
    public static Border Panel(UIElement content) => new() { Background = Theme.Brush("surface"), Child = content };
    public static Grid Grid(string rows, string columns)
    {
        var g = new Grid();
        foreach (var part in rows.Split(','))
            g.RowDefinitions.Add(new()
            {
                Height = Length(part)
            });
        foreach (var part in columns.Split(','))
            g.ColumnDefinitions.Add(new()
            {
                Width = Length(part)
            });
        return g;
    }
    static GridLength Length(string s) => s == "*" ? new(1, GridUnitType.Star) : s == "auto" ? GridLength.Auto : new(double.Parse(s, System.Globalization.CultureInfo.InvariantCulture));
    public static void Add(Grid grid, UIElement child, int row = 0, int column = 0)
    {
        Microsoft.UI.Xaml.Controls.Grid.SetRow((FrameworkElement)child, row);
        Microsoft.UI.Xaml.Controls.Grid.SetColumn((FrameworkElement)child, column);
        grid.Children.Add(child);
    }
}
