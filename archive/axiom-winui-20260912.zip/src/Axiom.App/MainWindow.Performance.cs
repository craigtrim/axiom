using System.Diagnostics;
using System.Text.Json;
using Axiom.Core;
using Axiom.Fixture;

namespace Axiom.App;

public sealed partial class MainWindow
{
    private async Task MeasureNativePerformance()
    {
        var directory = Path.GetFullPath(Path.Combine("artifacts", "frames-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")));
        Directory.CreateDirectory(directory);
        var results = new List<object>();
        var themeArgument = Environment.GetCommandLineArgs().FirstOrDefault(a => a.StartsWith("--performance-theme="))?.Split('=')[1];
        var themes = themeArgument == "light" ? new[] { false } : themeArgument == "dark" ? new[] { true } : new[] { false, true };
        var json = new JsonSerializerOptions { WriteIndented = true };
        void Stage(string message) => File.AppendAllText(Path.Combine(directory, "progress.log"), DateTimeOffset.UtcNow + " " + message + Environment.NewLine);
        File.WriteAllText("artifacts/latest-frames.txt", directory);
        try
        {
            await Task.Delay(700);
            await graph.WaitIdle();
            Stage("Generating and indexing 100000 orders");
            var generated = await Task.Run(() => PizzaFixture.Generate(100000));
            store.LoadGenerated(generated.Individuals, generated.Customers);
            await graph.WaitIdle();
            foreach (var dark in themes)
            {
                Theme.Set(dark, root);
                foreach (var (layout, budget, requirement) in new[] { ("force", 3000, "PB-01"), ("grid", 3000, "PB-02"), ("force", 1000, "PB-03") })
                {
                    var runs = new List<GraphFrameRun>();
                    for (var run = 1; run <= 3; run++)
                    {
                        Stage($"{requirement} {(dark ? "dark" : "light")} run {run}");
                        graph.Run(() =>
                        {
                            graph.View.Clear();
                            graph.View.SetBudget(budget);
                            graph.Layout.Choice = layout;
                            graph.View.Seed([Ns.Pizza + "Margherita"], true, true);
                        }, true, true);
                        await graph.WaitIdle();
                        if (graph.View.Nodes.Count != budget)
                            throw new InvalidOperationException($"Expected {budget} nodes, got {graph.View.Nodes.Count}.");
                        var sample = await graph.MeasureFrames(run);
                        runs.Add(sample);
                        File.WriteAllText(Path.Combine(directory, $"{requirement}-{(dark ? "dark" : "light")}-{run}.json"), JsonSerializer.Serialize(sample, json));
                    }
                    var p95 = GraphFrameRun.Percentile(runs.Select(r => r.P95WorkMs), .5);
                    var p99 = GraphFrameRun.Percentile(runs.Select(r => r.P99WorkMs), .5);
                    results.Add(new
                    {
                        Requirement = requirement,
                        Theme = dark ? "dark" : "light",
                        Layout = layout,
                        Nodes = budget,
                        Repetitions = runs.Count,
                        ConsecutiveFramesPerRun = 600,
                        WarmupFramesPerRun = 30,
                        MedianP95WorkMs = p95,
                        MedianP99WorkMs = p99,
                        MedianP95DrawIntervalMs = GraphFrameRun.Percentile(runs.Select(r => r.P95IntervalMs), .5),
                        MedianP99DrawIntervalMs = GraphFrameRun.Percentile(runs.Select(r => r.P99IntervalMs), .5),
                        MissingCanvasFrames = runs.Sum(r => r.MissingCanvasFrames),
                        CpuWorkBudgetMet = p95 <= (budget == 1000 ? 8 : 16.7) && (budget == 1000 || p99 <= 33) && runs.All(r => r.MissingCanvasFrames == 0),
                        MeasuresPresentationCompletion = false
                    });
                    Save(true);
                }
            }
            Stage("Completed");
            Save(true);
        }
        catch (Exception ex)
        {
            Stage(ex.ToString());
            Save(false, ex.ToString());
            Environment.ExitCode = 1;
        }
        finally { Close(); }

        void Save(bool completed, string? error = null)
        {
            File.WriteAllText(Path.Combine(directory, "summary.json"), JsonSerializer.Serialize(new
            {
                HarnessSucceeded = completed && results.Count == themes.Length * 3,
                Error = error,
                Date = DateTimeOffset.UtcNow,
                Executable = Environment.ProcessPath,
                OS = Environment.OSVersion.ToString(),
                ProcessorCount = Environment.ProcessorCount,
                StopwatchFrequency = Stopwatch.Frequency,
                Build = "Release",
                DatasetSize = 100000,
                MinimumTargetCertification = false,
                Measurements = "CPU simulation and graph swap-chain draw submission, including minimap; draw-to-draw intervals recorded separately. The graph uses a composition swap chain with Present(1). No per-method profiler in measured frames. External presentation corroboration remains required.",
                Results = results
            }, json));
        }
    }
}
