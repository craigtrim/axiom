using Axiom.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
namespace Axiom.App;
public sealed class IndividualsView : UserControl
{
    public TableModel Model
    {
        get;
    }
    public VirtualGrid Rows { get; } = new();
    private readonly Store store;
    private readonly Selection selection;
    private readonly GraphView graph;
    private readonly Action<string, bool> report;
    private readonly Grid root = Ui.Grid("auto,*", "*");
    private readonly TextBox query = Ui.Field("Filter individuals", "Filter individuals");
    private readonly ComboBox type = Ui.Named(new ComboBox { Width = 180 }, "Filter by type");
    private readonly ComboBox branch = Ui.Named(new ComboBox { Width = 140 }, "Filter by branch");
    private readonly TextBlock count = Ui.Text("", 12, "text-secondary");
    private readonly TextBlock empty = Ui.Text("", Theme.Body, "text-secondary");
    private readonly StackPanel emptyState = new() { Spacing = Theme.S3, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, MaxWidth = 340, Margin = new(24) };
    private readonly DispatcherTimer debounce = new() { Interval = TimeSpan.FromMilliseconds(160) };
    private bool changing;
    public IndividualsView(Store store, Selection selection, GraphView graph, Action<string, bool> report)
    {
        this.store = store;
        this.selection = selection;
        this.graph = graph;
        this.report = report;
        Model = new(store);
        Content = root;
        query.Width = 220;
        var bar = Ui.Wrap(type, branch, query, Ui.Button("Reset", Reset), Ui.Button("Send page to graph", Send), count);
        bar.Padding = new(8, 4, 8, 4);
        Ui.Add(root, bar);
        Ui.Named(Rows, "Individuals");
        Rows.SelectionCleared += () => selection.Select(null);
        Ui.Add(root, Rows, 1);
        empty.HorizontalAlignment = HorizontalAlignment.Center;
        empty.TextWrapping = TextWrapping.Wrap;
        emptyState.Children.Add(Ui.Text("No individuals match", Theme.Subtitle));
        emptyState.Children.Add(empty);
        var recovery = Ui.Button("Reset filters", Reset);
        recovery.HorizontalAlignment = HorizontalAlignment.Center;
        recovery.Background = Theme.Brush("surface");
        recovery.BorderBrush = Theme.Brush("stroke-strong");
        recovery.BorderThickness = new(1);
        emptyState.Children.Add(recovery);
        Ui.Add(root, emptyState, 1);
        Rows.SortRequested += index => { Model.ToggleSort(TableModel.Columns[index].Id); Apply(true); };
        Rows.Activated += Activate;
        Rows.CommitRequested = (r, c, value) => r < Model.Rows.Count ? store.EditCell(Model.Rows[r].Iri, TableModel.Columns[c].Id, value) : "This individual is no longer in the Store.";
        Rows.Warning += message => report(message, true);
        type.SelectionChanged += (_, _) => { if (changing) return; Model.Type = type.SelectedItem is TypeItem item ? item.Iri : ""; Apply(true); };
        branch.SelectionChanged += (_, _) => { if (changing) return; Model.Branch = branch.SelectedIndex > 0 ? (string)branch.SelectedItem : ""; Apply(true); };
        query.TextChanged += (_, _) => { if (changing) return; debounce.Stop(); debounce.Start(); };
        debounce.Tick += (_, _) => { debounce.Stop(); Model.Query = query.Text.Trim(); Apply(true); };
        selection.Changed += _ => Rows.Render(true);
        Populate();
        Reset();
    }
    private sealed record TypeItem(string Iri, string Label)
    {
        public override string ToString() => Label;
    }
    private void Populate()
    {
        changing = true;
        var items = new[] { new TypeItem("", "All types") }.Concat(store.ByType.Keys.OrderBy(Ns.Local).Select(i => new TypeItem(i, Ns.Humanise(Ns.Local(i))))).ToArray();
        branch.ItemsSource = new[] { "All branches" }.Concat(Store.Branches).ToArray();
        type.ItemsSource = items;
        type.SelectedItem = items.FirstOrDefault(item => item.Iri == Model.Type) ?? items[0];
        branch.SelectedIndex = Array.IndexOf(Store.Branches, Model.Branch) + 1;
        changing = false;
    }
    private void Reset()
    {
        debounce.Stop();
        changing = true;
        type.SelectedIndex = branch.SelectedIndex = 0;
        query.Text = "";
        changing = false;
        Model.Reset();
        Apply(true);
    }
    public void Refresh(Change change)
    {
        if (change.Regenerated)
        {
            Populate();
            Reset();
        }
        else
        {
            if (change.Description.StartsWith("Created ") || change.Description.StartsWith("Undid Create "))
                Populate();
            Apply(false);
        }
    }
    private void Apply(bool reset)
    {
        Model.Apply();
        count.Text = $"{Ns.Count(Model.Rows.Count)} {(Model.Rows.Count == 1 ? "row" : "rows")} / {Ns.Count(store.Individuals.Count)} individuals";
        Rows.Set(TableModel.Columns, Model.Rows.Count, (r, c) => new((c == 0 ? "● " : "") + Model.Display(Model.Rows[r], TableModel.Columns[c].Id), Model.Rows[r].Iri, c == 0 ? "e-individual" : "text"), r => Model.Rows[r].Iri == selection.Iri, Model.Sort, Model.Direction, reset);
        emptyState.Visibility = Model.Rows.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        empty.Text = (store.Individuals.Count == 0 ? "The demo dataset is empty. Use Dataset on the command bar to generate individuals." : $"Loosen the type, branch or text filter, or press Reset to see all {Ns.Count(store.Individuals.Count)} individuals.");
    }
    private void Activate(int row, int column, bool reveal)
    {
        if (row >= Model.Rows.Count)
            return;
        var i = Model.Rows[row];
        selection.Select(i.Iri, reveal);
        if (reveal || column < 0)
            return;
        var col = TableModel.Columns[column];
        if (!col.Editable)
            return;
        Rows.BeginEdit(row, column, col.Id switch
        {
            "branch" => i.Branch,
            "price" => i.Price.ToString("F2", Ns.Culture),
            _ => i.Rating.ToString()
        }, col.Id == "branch" ? Store.Branches : null);
    }
    private void Send()
    {
        if (Model.Rows.Count == 0)
        {
            report("No rows to send — the filter matches nothing.", true);
            return;
        }
        var iris = Model.Rows.Take(graph.View.Budget).Select(i => i.Iri).ToArray();
        graph.Seed(iris, true, false);
        report($"Seeded the graph with {Ns.Count(iris.Length)} of {Ns.Count(Model.Rows.Count)} filtered rows. Double-click any node to expand it.", false);
    }
}
