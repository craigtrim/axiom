using Microsoft.UI.Xaml.Automation.Peers;
using System.Text.RegularExpressions;
using Axiom.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Documents;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Automation;
namespace Axiom.App;
public sealed class InspectorView : UserControl
{
    private readonly Store store;
    private readonly Selection selection;
    private readonly StackPanel body = new() { Spacing = Theme.S3, Padding = new Thickness(Theme.S4) };
    public event Action? RenameRequested;
    public event Action<string>? PageInstancesRequested;
    public InspectorView(Store s, Selection bus)
    {
        store = s;
        selection = bus;
        var root = Ui.Grid("auto,*", "*");
        var rename = Ui.Button("", () => RenameRequested?.Invoke(), "Rename (F2)");
        rename.Content = Ui.VectorIcon("M2,11 L10,3 L13,6 L5,14 L1,15 Z M11,2 L13,0 L16,3 L14,5 Z");
        var reveal = Ui.Button("", () => { if (selection.Iri is { } iri) selection.Select(iri, true); }, "Reveal in graph");
        reveal.Content = Ui.VectorIcon("M1,3 L7,3 L7,5 L3,5 L3,13 L11,13 L11,9 L13,9 L13,15 L1,15 Z M9,1 L16,1 L16,8 L14,8 L14,4.4 L8,10.4 L6.6,9 L12.6,3 L9,3 Z");
        var header = Ui.Wrap(Ui.Text("Entity", Theme.Subtitle), rename, reveal);
        header.Padding = new(Theme.S3, Theme.S1, Theme.S3, Theme.S1);
        Ui.Add(root, header);
        Ui.Add(root, new ScrollViewer { Content = body }, 1);
        Content = root;
        Background = Theme.Brush("surface");
        Ui.Named(this, "Entity inspector");
        selection.Changed += _ => Render();
        Render();
    }
    private TextBlock Prose(string text, string colour = "text")
    {
        var t = Ui.Text(text, Theme.Body, colour);
        t.TextWrapping = TextWrapping.Wrap;
        t.IsTextSelectionEnabled = true;
        return t;
    }
    private TextBlock Axiom(string text)
    {
        var t = new TextBlock { FontFamily = new FontFamily(Theme.MonoFont), FontSize = Theme.Code, Foreground = Theme.Brush("text"), TextWrapping = TextWrapping.Wrap };
        var at = 0;
        foreach (Match match in Regex.Matches(text, @"(?:pizza|demo|owl|rdf|rdfs|xsd):[A-Za-z0-9_-]+"))
        {
            if (match.Index > at)
                t.Inlines.Add(new Run { Text = text[at..match.Index] });
            var iri = Ns.Expand(match.Value);
            if (iri.StartsWith(Ns.Xsd) || !store.Exists(iri))
                t.Inlines.Add(new Run { Text = match.Value });
            else
            {
                var link = new Hyperlink { Foreground = Theme.Brush("text") };
                link.Inlines.Add(new Run { Text = match.Value });
                link.Click += (_, _) => selection.Select(iri, true);
                t.Inlines.Add(link);
            }
            at = match.Index + match.Length;
        }
        if (at < text.Length)
            t.Inlines.Add(new Run { Text = text[at..] });
        return t;
    }
    private void Section(string title, IEnumerable<UIElement> contents)
    {
        var rows = contents.ToArray();
        if (rows.Length == 0)
            return;
        var heading = Ui.Text(title.ToUpperInvariant(), Theme.Caption, "text-secondary");
        heading.FontWeight = Microsoft.UI.Text.FontWeights.SemiBold;
        AutomationProperties.SetHeadingLevel(heading, AutomationHeadingLevel.Level2);
        body.Children.Add(heading);
        foreach (var row in rows)
            body.Children.Add(row);
    }
    public void Render()
    {
        body.Children.Clear();
        var iri = selection.Iri;
        var e = iri is null ? null : store.Resolve(iri);
        if (e is null)
        {
            body.Children.Add(Prose("Select an entity", "text-secondary"));
            body.Children.Add(Prose("Choose a class in the hierarchy, a node in the graph, or a row in the individuals table to inspect its axioms.", "text-secondary"));
            return;
        }
        var title = Prose(store.Label(e.Iri));
        title.FontSize = Theme.Subtitle;
        title.FontWeight = Microsoft.UI.Text.FontWeights.SemiBold;
        body.Children.Add(title);
        body.Children.Add(Ui.Text(Kinds.Label(e.Kind), Theme.Caption, Theme.KindKey(e.Kind)));
        if (e.Generated)
            body.Children.Add(Ui.Text("generated demo data", Theme.Caption, "text-secondary"));
        var id = Prose(e.Iri, "text-secondary");
        id.FontFamily = new FontFamily(Theme.MonoFont);
        id.FontSize = Theme.Caption;
        body.Children.Add(id);
        if (e.Comment != "")
            Section("Annotations", [Prose(e.Comment)]);
        Section("Equivalent to", e.Equivalents.Count > 0 ? [Axiom("≡ " + string.Join("\nand ", e.Equivalents.Select(r => r.Text)))] : []);
        Section("SubClass of", e.Parents.Select(p => Axiom("⊑ " + Ns.Shorten(p))).Concat(e.Parents.Count > 0 ? e.Restrictions.Select(r => Axiom("⊑ " + r.Text)) : []));
        Section("Types", e.Types.Select(t => Axiom("a " + Ns.Shorten(t))));
        if (store.IndividualIndex.TryGetValue(e.Iri, out var order))
        {
            Section("Property assertions", new[] { "demo:orderRef " + order.Reference, "demo:branch " + order.Branch, "demo:priceGBP £" + order.Price.ToString("F2", Ns.Culture), "demo:rating " + order.Rating + " / 5", "demo:preparedAt " + DateTimeOffset.FromUnixTimeMilliseconds(order.Timestamp).ToString("dd MMM yyyy, HH:mm", Ns.Culture) }.Concat(order.CustomerIndex >= 0 && order.CustomerIndex < store.Customers.Count ? new[] { "demo:orderedBy " + Ns.Shorten(store.Customers[order.CustomerIndex].Iri) } : []).Select(Axiom));
            if (store.Entities.TryGetValue(order.Type, out var type))
                Section("Toppings entailed by its type", type.Restrictions.Where(r => r.Property == Ns.Pizza + "hasTopping" && r.Quantifier == "some").Select(r => Axiom(r.Text)));
        }
        if (store.CustomerIndex.TryGetValue(e.Iri, out var customer))
        {
            Section("Property assertions", [Axiom("rdfs:label " + customer.Name)]);
            Section("Orders", [Prose($"{Ns.Count(store.OrdersFor(e.Iri).Count)} generated orders reference this customer. Expand the node in the graph to page them in under the viewport budget.")]);
        }
        Section("Disjoint with", e.DisjointWith.Select(d => Axiom("⊥ " + Ns.Shorten(d))));
        var properties = new List<UIElement>();
        if (e.Domain is { } domain)
            properties.Add(Axiom("Domain " + Ns.Shorten(domain)));
        if (e.Range is { } range)
            properties.Add(Axiom("Range " + Ns.Shorten(range)));
        if (e.Inverse is { } inverse)
            properties.Add(Axiom("Inverse of " + Ns.Shorten(inverse)));
        if (e.Characteristics.Count > 0)
            properties.Add(Axiom("Characteristics " + string.Join(", ", e.Characteristics)));
        Section("Property axioms", properties);
        if (e.Kind is EntityKind.Class or EntityKind.Defined)
        {
            var usage = new List<UIElement>();
            foreach (var (label, value) in new[] { ("Subclasses", e.Children.Count), ("Descendants", store.DescendantCount(e.Iri)), ("Direct instances", store.InstanceCount(e.Iri)) })
            {
                var row = Ui.Grid("auto", "104,*");
                Ui.Add(row, Ui.Text(label, Theme.Caption, "text-secondary"));
                Ui.Add(row, Ui.Text(Ns.Count(value)), 0, 1);
                usage.Add(row);
            }
            if (store.InstanceCount(e.Iri) > 0)
                usage.Add(Ui.Button("Page instances into the graph", () => PageInstancesRequested?.Invoke(e.Iri)));
            Section("Usage", usage);
        }
        Section("Inferred axioms", [Prose("No reasoner has run. This build shows asserted axioms only. Inferred axioms would appear here, marked with the amber rule, once a reasoner is attached.", "text-secondary")]);
    }
}
