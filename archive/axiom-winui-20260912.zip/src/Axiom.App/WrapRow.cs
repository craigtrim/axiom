using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.Foundation;

namespace Axiom.App;

public sealed class WrapRow : Panel
{
    public double Spacing { get; set; } = Theme.S2;
    public Thickness Padding
    {
        get; set;
    }
    protected override Size MeasureOverride(Size availableSize)
    {
        var width = Math.Max(0, availableSize.Width - Padding.Left - Padding.Right);
        double x = 0, y = 0, rowHeight = 0, used = 0;
        foreach (var child in Children.Where(c => c.Visibility != Visibility.Collapsed))
        {
            child.Measure(new(width, double.PositiveInfinity));
            var size = child.DesiredSize;
            if (x > 0 && x + size.Width > width)
            {
                used = Math.Max(used, x - Spacing);
                y += rowHeight + Spacing;
                x = rowHeight = 0;
            }
            x += size.Width + Spacing;
            rowHeight = Math.Max(rowHeight, size.Height);
        }
        used = Math.Max(used, Math.Max(0, x - Spacing));
        return new(used + Padding.Left + Padding.Right, y + rowHeight + Padding.Top + Padding.Bottom);
    }
    protected override Size ArrangeOverride(Size finalSize)
    {
        var width = Math.Max(0, finalSize.Width - Padding.Left - Padding.Right);
        double x = 0, y = 0, rowHeight = 0;
        foreach (var child in Children.Where(c => c.Visibility != Visibility.Collapsed))
        {
            var size = child.DesiredSize;
            if (x > 0 && x + size.Width > width)
            {
                y += rowHeight + Spacing;
                x = rowHeight = 0;
            }
            child.Arrange(new(Padding.Left + x, Padding.Top + y, Math.Min(width, size.Width), size.Height));
            x += size.Width + Spacing;
            rowHeight = Math.Max(rowHeight, size.Height);
        }
        return finalSize;
    }
}
