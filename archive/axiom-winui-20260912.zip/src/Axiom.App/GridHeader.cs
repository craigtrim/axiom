using Microsoft.UI.Xaml.Automation.Peers;
using Microsoft.UI.Xaml.Controls;

namespace Axiom.App;

public sealed class GridHeaderRow : Grid
{
    private AutomationPeer? peer;
    internal AutomationPeer Peer => peer ??= new HeaderRowPeer(this);
    protected override AutomationPeer OnCreateAutomationPeer() => Peer;
    private sealed class HeaderRowPeer(GridHeaderRow row) : FrameworkElementAutomationPeer(row)
    {
        protected override string GetClassNameCore() => "AxiomHeaderRow";
        protected override string GetNameCore() => "Column headers";
        protected override AutomationControlType GetAutomationControlTypeCore() => AutomationControlType.Header;
        protected override List<AutomationPeer> GetChildrenCore() => row.Children.OfType<GridHeaderButton>().Select(button => button.Peer).ToList();
    }
}

public sealed class GridHeaderButton : Button
{
    private AutomationPeer? peer;
    internal AutomationPeer Peer => peer ??= new HeaderPeer(this);
    protected override AutomationPeer OnCreateAutomationPeer() => Peer;
    private sealed class HeaderPeer(GridHeaderButton button) : ButtonAutomationPeer(button)
    {
        protected override string GetClassNameCore() => "AxiomColumnHeader";
        protected override AutomationControlType GetAutomationControlTypeCore() => AutomationControlType.HeaderItem;
        protected override string GetLocalizedControlTypeCore() => "column header";
    }
}
