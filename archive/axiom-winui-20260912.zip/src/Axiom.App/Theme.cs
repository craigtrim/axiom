using Microsoft.UI.Xaml.Controls.Primitives;
using Axiom.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Windows.UI;
namespace Axiom.App;
public static class Theme
{
    public static readonly double Caption = DesignTokens.Number("fs-caption"), Body = DesignTokens.Number("fs-body"), Subtitle = DesignTokens.Number("fs-subtitle"), Title = DesignTokens.Number("fs-title"), Code = DesignTokens.Number("fs-code");
    private static readonly double BaseControlHeight = DesignTokens.Number("h-control"), BaseRowHeight = DesignTokens.Number("h-row"), BaseTreeRowHeight = DesignTokens.Number("h-tree-row");
    public static double TextScale { get; private set; } = Math.Max(1, new Windows.UI.ViewManagement.UISettings().TextScaleFactor);
    public static double ControlHeight => BaseControlHeight * TextScale;
    public static double RowHeight => BaseRowHeight * TextScale;
    public static double TreeRowHeight => BaseTreeRowHeight * TextScale;
    public static readonly double TitleBarHeight = DesignTokens.Number("h-titlebar"), CommandBarHeight = DesignTokens.Number("h-commandbar"), StatusBarHeight = DesignTokens.Number("h-statusbar");
    public static void SetTextScale(double scale) => TextScale = Math.Max(1, scale);
    public static readonly double S1 = DesignTokens.Number("sp-1"), S2 = DesignTokens.Number("sp-2"), S3 = DesignTokens.Number("sp-3"), S4 = DesignTokens.Number("sp-4"), S5 = DesignTokens.Number("sp-5"), S6 = DesignTokens.Number("sp-6"), S8 = DesignTokens.Number("sp-8"), Radius = DesignTokens.Number("r-control"), CardRadius = DesignTokens.Number("r-card");
    public const double SplitterSize = 4;
    public const double LeftWidth = 260, RightWidth = 320, DockHeight = 280, MinWidth = 1180, MinHeight = 720;
    public static readonly string UiFont = DesignTokens.Font("font-ui"), MonoFont = DesignTokens.Font("font-mono");
    private static readonly Dictionary<string, SolidColorBrush> brushes = [];
    public static bool Dark
    {
        get; private set;
    }
    public static bool HighContrast
    {
        get; private set;
    }
    public static event Action? Changed;
    public static Color Color(string key)
    {
        var c = DesignTokens.Colour(key, Dark);
        return Windows.UI.Color.FromArgb((byte)(c >> 24), (byte)(c >> 16), (byte)(c >> 8), (byte)c);
    }
    public static SolidColorBrush Brush(string key)
    {
        if (!brushes.TryGetValue(key, out var b))
            brushes.Add(key, b = new(Color(key)));
        return b;
    }
    public static string KindKey(EntityKind kind) => kind switch { EntityKind.Class => "e-class", EntityKind.Defined => "e-defined", EntityKind.Individual => "e-individual", EntityKind.ObjectProperty => "e-objprop", _ => "e-dataprop" };
    public static void Set(bool dark, FrameworkElement root)
    {
        Dark = dark;
        var access = new Windows.UI.ViewManagement.AccessibilitySettings();
        HighContrast = access.HighContrast;
        if (HighContrast)
        {
            var settings = new Windows.UI.ViewManagement.UISettings();
            uint Pack(Windows.UI.Color c) => ((uint)c.A << 24) | ((uint)c.R << 16) | ((uint)c.G << 8) | c.B;
            var background = Pack(settings.UIElementColor(Windows.UI.ViewManagement.UIElementType.Window));
            var foreground = Pack(settings.UIElementColor(Windows.UI.ViewManagement.UIElementType.WindowText));
            var accent = Pack(settings.UIElementColor(Windows.UI.ViewManagement.UIElementType.Highlight));
            var onAccent = Pack(settings.UIElementColor(Windows.UI.ViewManagement.UIElementType.HighlightText));
            DesignTokens.Overrides = DesignTokens.Values(dark ? "dark" : "light").Keys.Where(k => !k.StartsWith("shadow")).ToDictionary(k => k, k => k is "ground" or "surface" or "surface-alt" or "surface-sunken" or "canvas" or "accent-subtle" or "danger-subtle" or "layer-hover" or "layer-pressed" ? background : k is "accent" or "accent-hover" or "accent-pressed" or "layer-selected" ? accent : k == "text-on-accent" ? onAccent : foreground);
        }
        else
            DesignTokens.Overrides = null;
        root.RequestedTheme = dark ? ElementTheme.Dark : ElementTheme.Light;
        foreach (var (key, b) in brushes)
            b.Color = Color(key);
        var resources = Application.Current.Resources;
        resources["SystemAccentColor"] = Color("accent");
        resources["AccentFillColorDefaultBrush"] = Brush("accent");
        resources["AccentFillColorSecondaryBrush"] = Brush("accent-hover");
        resources["AccentFillColorTertiaryBrush"] = Brush("accent-pressed");
        Changed?.Invoke();
    }
    public static void Install(ResourceDictionary resources)
    {
        resources["TextControlThemeMinHeight"] = ControlHeight;
        resources["ComboBoxThemeMinHeight"] = ControlHeight;
        resources["ButtonMinHeight"] = ControlHeight;
        foreach (var type in new[] { typeof(Button), typeof(ToggleButton), typeof(TextBox), typeof(ComboBox) })
        {
            var style = new Style(type);
            style.Setters.Add(new Setter(Control.FontSizeProperty, Body));
            style.Setters.Add(new Setter(Control.FontFamilyProperty, new FontFamily(UiFont)));
            style.Setters.Add(new Setter(FrameworkElement.MinHeightProperty, ControlHeight));
            style.Setters.Add(new Setter(FrameworkElement.HeightProperty, double.NaN));
            style.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(S2, 0, S2, 0)));
            style.Setters.Add(new Setter(Control.CornerRadiusProperty, new CornerRadius(Radius)));
            resources[type] = style;
        }
    }
}
