using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Automation.Peers;
using Microsoft.UI.Xaml.Automation.Provider;
using Windows.System;
namespace Axiom.App;

public sealed class TabButton : Button
{
    internal TabStrip? Strip;
    internal bool Selected;
    internal Action Activate = () => { };
    internal void Select()
    {
        Strip?.Select(this);
        Activate();
    }
    protected override AutomationPeer OnCreateAutomationPeer() => new TabPeer(this);
    private sealed class TabPeer(TabButton tab) : ButtonAutomationPeer(tab), ISelectionItemProvider
    {
        protected override AutomationControlType GetAutomationControlTypeCore() => AutomationControlType.TabItem;
        protected override object GetPatternCore(PatternInterface pattern) => pattern == PatternInterface.SelectionItem ? this : base.GetPatternCore(pattern);
        public bool IsSelected => tab.Selected;
        public IRawElementProviderSimple SelectionContainer => ProviderFromPeer(CreatePeerForElement(tab.Strip!));
        public void AddToSelection() => Select();
        public void RemoveFromSelection()
        {
        }
        public void Select() => tab.Select();
    }
}
public sealed class TabStrip : StackPanel
{
    internal IEnumerable<TabButton> Tabs => Children.OfType<TabButton>();
    public TabStrip(params Button[] buttons)
    {
        Orientation = Orientation.Horizontal;
        Spacing = Theme.S2;
        foreach (var button in buttons)
        {
            var tab = (TabButton)button;
            tab.Strip = this;
            Children.Add(tab);
            tab.KeyDown += (_, e) =>
            {
                var all = Tabs.ToArray();
                var index = Array.IndexOf(all, tab);
                if (e.Key == VirtualKey.Left)
                    index = (index + all.Length - 1) % all.Length;
                else if (e.Key == VirtualKey.Right)
                    index = (index + 1) % all.Length;
                else if (e.Key == VirtualKey.Home)
                    index = 0;
                else if (e.Key == VirtualKey.End)
                    index = all.Length - 1;
                else
                    return;
                all[index].Select();
                all[index].Focus(FocusState.Keyboard);
                e.Handled = true;
            };
        }
        if (Tabs.FirstOrDefault() is { } first)
            Select(first);
    }
    public void Select(TabButton selected)
    {
        foreach (var tab in Tabs)
        {
            tab.Selected = tab == selected;
            tab.Background = Theme.Brush(tab.Selected ? "layer-selected" : "surface");
            Microsoft.UI.Xaml.Automation.AutomationProperties.SetItemStatus(tab, tab.Selected ? "Selected" : "");
        }
    }
    protected override AutomationPeer OnCreateAutomationPeer() => new StripPeer(this);
    private sealed class StripPeer(TabStrip strip) : FrameworkElementAutomationPeer(strip), ISelectionProvider
    {
        protected override AutomationControlType GetAutomationControlTypeCore() => AutomationControlType.Tab;
        protected override object GetPatternCore(PatternInterface pattern) => pattern == PatternInterface.Selection ? this : base.GetPatternCore(pattern);
        public bool CanSelectMultiple => false;
        public bool IsSelectionRequired => true;
        public IRawElementProviderSimple[] GetSelection() => strip.Tabs.Where(t => t.Selected).Select(t => ProviderFromPeer(CreatePeerForElement(t))).ToArray();
    }
}
