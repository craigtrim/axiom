using System.Diagnostics;
using Axiom.Core;

namespace Axiom.App;

public sealed record GraphFrameSample(long Timestamp, double IntervalMs, double SimulationMs, double CanvasMs, double MinimapMs, int CanvasDraws, int MinimapDraws, int CallbacksWithoutDraw)
{
    public double WorkMs => SimulationMs + CanvasMs + MinimapMs;
}

public sealed record GraphFrameRun(int Run, string Layout, int Nodes, int Edges, double WidthDip, double HeightDip, double RasterizationScale, bool ForceHeldActive, GraphFrameSample[] Frames)
{
    public int MissingCanvasFrames => Frames.Count(f => f.CanvasDraws == 0);
    public double P95WorkMs => Percentile(Frames.Select(f => f.WorkMs), .95);
    public double P99WorkMs => Percentile(Frames.Select(f => f.WorkMs), .99);
    public double P95IntervalMs => Percentile(Frames.Select(f => f.IntervalMs), .95);
    public double P99IntervalMs => Percentile(Frames.Select(f => f.IntervalMs), .99);
    public static double Percentile(IEnumerable<double> values, double percentile)
    {
        var sorted = values.Order().ToArray();
        return sorted.Length == 0 ? 0 : sorted[Math.Clamp((int)Math.Ceiling(sorted.Length * percentile) - 1, 0, sorted.Length - 1)];
    }
}

public sealed partial class GraphView
{
    private FrameMeasurement? measurement;

    // This measures actual graph swap-chain draw callbacks. CPU submission and draw
    // intervals remain separate: neither is proof of GPU presentation completion.
    public async Task<GraphFrameRun> MeasureFrames(int run, int frames = 600)
    {
        if (frames < 600)
            throw new ArgumentOutOfRangeException(nameof(frames));
        await WaitIdle();
        await gate.WaitAsync();
        var before = camera;
        IsEnabled = false;
        try
        {
            measurement = new(this, frames);
            Invalidate();
            var samples = await measurement.Completion.Task.WaitAsync(TimeSpan.FromMinutes(2));
            return new(run, Layout.Resolved, View.Nodes.Count, View.Edges.Count, canvas.ActualWidth, canvas.ActualHeight, XamlRoot.RasterizationScale, Layout.Resolved == "force", samples);
        }
        finally
        {
            measurement = null;
            camera = before;
            hitDirty = true;
            IsEnabled = true;
            gate.Release();
            Invalidate();
        }
    }

    private sealed class FrameMeasurement(GraphView graph, int count)
    {
        private const int WarmupFrames = 30;
        private readonly List<GraphFrameSample> samples = new(count);
        private readonly Camera origin = graph.camera;
        private long started, simulation, drawing, minimap;
        private int frame, draws, mapDraws, callbacksWithoutDraw;
        public TaskCompletionSource<GraphFrameSample[]> Completion { get; } = new();

        public void CompletionFailure(Exception error) => Completion.TrySetException(error);

        public void Advance()
        {
            var now = Stopwatch.GetTimestamp();
            if (started != 0 && draws == 0)
            {
                callbacksWithoutDraw++;
                return;
            }
            if (started != 0 && frame > WarmupFrames)
                samples.Add(new(started, Ms(now - started), Ms(simulation), Ms(drawing), Ms(minimap), draws, mapDraws, callbacksWithoutDraw));
            if (samples.Count == count)
            {
                Completion.TrySetResult(samples.ToArray());
                return;
            }
            started = now;
            simulation = drawing = minimap = 0;
            draws = mapDraws = callbacksWithoutDraw = 0;
            frame++;
            // A slow, bounded pan across the fitted scene. A constant residual alpha
            // keeps force work present for every sample rather than timing a sleeping graph.
            graph.camera = origin with
            {
                X = origin.X + 48 * Math.Sin(frame * .007),
                Y = origin.Y + 24 * Math.Sin(frame * .004)
            };
            if (graph.Layout.Resolved == "force")
            {
                var timer = Stopwatch.GetTimestamp();
                graph.View.Alpha = Math.Max(.05, graph.View.Alpha);
                graph.Layout.Force.Step();
                graph.hitDirty = true;
                simulation = Stopwatch.GetTimestamp() - timer;
            }
            graph.Invalidate();
        }

        public void Draw(Action action, bool map)
        {
            var timer = Stopwatch.GetTimestamp();
            action();
            var elapsed = Stopwatch.GetTimestamp() - timer;
            if (map)
            {
                minimap += elapsed;
                mapDraws++;
            }
            else
            {
                drawing += elapsed;
                draws++;
            }
        }
        private static double Ms(long ticks) => ticks * 1000d / Stopwatch.Frequency;
    }
}
