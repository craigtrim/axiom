using System.ComponentModel;
using System.Runtime.InteropServices;

namespace Axiom.App;

internal static class WindowCapture
{
    [StructLayout(LayoutKind.Sequential)]
    private struct Rect
    {
        public int Left, Top, Right, Bottom;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct BitmapInfo
    {
        public uint Size;
        public int Width, Height;
        public ushort Planes, BitCount;
        public uint Compression, SizeImage;
        public int XPelsPerMeter, YPelsPerMeter;
        public uint ClrUsed, ClrImportant;
    }
    [DllImport("user32.dll", SetLastError = true)] private static extern bool GetWindowRect(nint window, out Rect rectangle);
    [DllImport("user32.dll")] private static extern nint GetDC(nint window);
    [DllImport("user32.dll")] private static extern int ReleaseDC(nint window, nint dc);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool PrintWindow(nint window, nint dc, uint flags);
    [DllImport("gdi32.dll", SetLastError = true)] private static extern nint CreateCompatibleDC(nint dc);
    [DllImport("gdi32.dll", SetLastError = true)] private static extern nint CreateCompatibleBitmap(nint dc, int width, int height);
    [DllImport("gdi32.dll")] private static extern nint SelectObject(nint dc, nint value);
    [DllImport("gdi32.dll")] private static extern bool DeleteObject(nint value);
    [DllImport("gdi32.dll")] private static extern bool DeleteDC(nint dc);
    [DllImport("gdi32.dll", SetLastError = true)] private static extern int GetDIBits(nint dc, nint bitmap, uint start, uint lines, [Out] byte[] pixels, ref BitmapInfo info, uint usage);

    public static (uint Width, uint Height, byte[] Pixels) Read(nint window)
    {
        if (!GetWindowRect(window, out var bounds))
            throw new Win32Exception(Marshal.GetLastWin32Error());
        var width = bounds.Right - bounds.Left;
        var height = bounds.Bottom - bounds.Top;
        var screen = GetDC(window);
        nint memory = 0, bitmap = 0, previous = 0;
        try
        {
            if (screen == 0 || (memory = CreateCompatibleDC(screen)) == 0 || (bitmap = CreateCompatibleBitmap(screen, width, height)) == 0)
                throw new Win32Exception(Marshal.GetLastWin32Error());
            previous = SelectObject(memory, bitmap);
            if (!PrintWindow(window, memory, 2))
                throw new Win32Exception(Marshal.GetLastWin32Error());
            SelectObject(memory, previous);
            previous = 0;
            var pixels = new byte[checked(width * height * 4)];
            var info = new BitmapInfo { Size = (uint)Marshal.SizeOf<BitmapInfo>(), Width = width, Height = -height, Planes = 1, BitCount = 32, SizeImage = (uint)pixels.Length };
            if (GetDIBits(screen, bitmap, 0, (uint)height, pixels, ref info, 0) != height)
                throw new Win32Exception(Marshal.GetLastWin32Error());
            return ((uint)width, (uint)height, pixels);
        }
        finally
        {
            if (previous != 0)
                SelectObject(memory, previous);
            if (bitmap != 0)
                DeleteObject(bitmap);
            if (memory != 0)
                DeleteDC(memory);
            if (screen != 0)
                ReleaseDC(window, screen);
        }
    }
}
