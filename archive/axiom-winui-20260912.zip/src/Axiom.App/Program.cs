using Microsoft.UI.Xaml;
namespace Axiom.App;
public static class Program
{
    [STAThread]
    public static void Main(string[] args)
    {
        WinRT.ComWrappersSupport.InitializeComWrappers();
        Application.Start(parameters =>
        {
            var queue = Microsoft.UI.Dispatching.DispatcherQueue.GetForCurrentThread();
            SynchronizationContext.SetSynchronizationContext(new Microsoft.UI.Dispatching.DispatcherQueueSynchronizationContext(queue));
            new AxiomApplication();
        });
    }
}
public sealed partial class AxiomApplication : Application
{
    private Window? window;
    public AxiomApplication()
    {
        UnhandledException += (_, e) =>
        {
            if (Environment.GetCommandLineArgs().Any(a => a is "--smoke" or "--verify" or "--ui-test" or "--performance"))
            {
                System.IO.Directory.CreateDirectory("artifacts");
                System.IO.File.WriteAllText("artifacts/smoke-error.txt", e.Exception.ToString());
            }
        };
        InitializeComponent();
    }
    protected override void OnLaunched(LaunchActivatedEventArgs args)
    {
        window = new MainWindow();
        window.Activate();
    }
}
