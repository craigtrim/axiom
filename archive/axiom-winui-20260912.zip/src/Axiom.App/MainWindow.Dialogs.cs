using Axiom.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Automation.Peers;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;

namespace Axiom.App;

public sealed partial class MainWindow
{
    private sealed record DialogField(string Label, Control Control, bool Required = false, Func<string?>? Validate = null, bool ValidateOnBlur = false);
    private bool dialogOpen;

    private async void Form(string title, DialogField[] fields, Func<string?> commit, string? description = null, string? primaryText = null, Action? afterCommit = null)
    {
        if (busy || dialogOpen)
            return;
        dialogOpen = true;
        var invoking = FocusManager.GetFocusedElement(root.XamlRoot) as Control;
        var body = new StackPanel { Spacing = Theme.S3 };
        if (description != null)
        {
            var introduction = Ui.Text(description);
            introduction.TextWrapping = TextWrapping.Wrap;
            body.Children.Add(introduction);
        }
        var errors = new Dictionary<Control, TextBlock>();
        var submitting = false;
        var attempted = false;
        foreach (var field in fields)
        {
            var label = Ui.Text(field.Label, Theme.Caption);
            var labelRow = Ui.Wrap(label);
            if (field.Required)
                labelRow.Children.Add(Ui.Text("*", Theme.Caption, "danger"));
            body.Children.Add(labelRow);
            body.Children.Add(field.Control);
            AutomationProperties.SetLabeledBy(field.Control, label);
            AutomationProperties.SetAutomationId(field.Control, "DialogField:" + field.Label);
            AutomationProperties.SetIsRequiredForForm(field.Control, field.Required);
            var error = Ui.Text("", Theme.Caption, "danger");
            error.TextWrapping = TextWrapping.Wrap;
            error.Visibility = Visibility.Collapsed;
            AutomationProperties.SetLiveSetting(error, AutomationLiveSetting.Assertive);
            AutomationProperties.GetDescribedBy(field.Control).Add(error);
            body.Children.Add(error);
            errors.Add(field.Control, error);
            if (field.ValidateOnBlur)
                field.Control.LostFocus += (_, _) =>
                {
                    if (!submitting)
                        Mark(field, !attempted && field.Control is TextBox box && box.Text.Trim() == "" ? null : field.Validate?.Invoke());
                };
        }
        var dialog = new ContentDialog
        {
            XamlRoot = root.XamlRoot,
            Title = title,
            Content = new ScrollViewer { Content = body, VerticalScrollBarVisibility = ScrollBarVisibility.Auto },
            PrimaryButtonText = primaryText ?? (title.StartsWith("Delete") ? "Delete" : "Create"),
            CloseButtonText = "Cancel",
            DefaultButton = ContentDialogButton.Primary
        };
        var committed = false;
        dialog.Opened += (_, _) =>
        {
            foreach (var error in errors.Values)
                FrameworkElementAutomationPeer.CreatePeerForElement(error);
            if (fields.Length > 0)
                fields[0].Control.Focus(FocusState.Programmatic);
        };
        dialog.PrimaryButtonClick += (_, args) =>
        {
            submitting = true;
            attempted = true;
            var failed = fields.FirstOrDefault(field => Mark(field, field.Validate?.Invoke()));
            if (failed != null)
            {
                args.Cancel = true;
                DispatcherQueue.TryEnqueue(() => failed.Control.Focus(FocusState.Keyboard));
            }
            else if (commit() is { } message)
            {
                args.Cancel = true;
                if (fields.Length > 0)
                {
                    Mark(fields[0], message);
                    DispatcherQueue.TryEnqueue(() => fields[0].Control.Focus(FocusState.Keyboard));
                }
            }
            else
                committed = true;
            submitting = false;
        };
        try
        {
            await dialog.ShowAsync();
            if (committed)
                afterCommit?.Invoke();
        }
        catch (Exception ex) { Report(ex.Message, true); }
        finally
        {
            dialogOpen = false;
            if (invoking is { IsEnabled: true, Visibility: Visibility.Visible } && invoking.XamlRoot != null)
                invoking.Focus(FocusState.Programmatic);
        }

        bool Mark(DialogField field, string? message)
        {
            var error = errors[field.Control];
            error.Text = message ?? "";
            error.Visibility = message == null ? Visibility.Collapsed : Visibility.Visible;
            field.Control.BorderBrush = Theme.Brush(message == null ? "stroke-strong" : "danger");
            AutomationProperties.SetIsDataValidForForm(field.Control, message == null);
            AutomationProperties.SetHelpText(field.Control, message ?? "");
            AutomationProperties.SetItemStatus(field.Control, message == null ? "" : "Invalid: " + message);
            if (message != null)
                FrameworkElementAutomationPeer.CreatePeerForElement(error)?.RaiseAutomationEvent(AutomationEvents.LiveRegionChanged);
            return message != null;
        }
    }

    private void NewClass()
    {
        var name = Ui.Field("Class name", "e.g. TruffleTopping");
        var parents = store.Entities.Values.Where(e => e.Kind is EntityKind.Class or EntityKind.Defined)
            .OrderBy(e => e.Name, StringComparer.Create(Ns.Culture, false)).ToArray();
        var parent = Ui.Named(new ComboBox { ItemsSource = parents, DisplayMemberPath = "Name", SelectedItem = parents.FirstOrDefault(p => p.Iri == selection.Iri) ?? parents.First(p => p.Iri == Ns.Thing), IsTextSearchEnabled = true }, "Superclass");
        Entity? created = null;
        string? parentIri = null;
        Form("New class",
            [new("Class name", name, true, () => store.ValidateName(name.Text), true), new("Superclass", parent, true)],
            () =>
            {
                parentIri = ((Entity)parent.SelectedItem).Iri;
                hierarchy.ExpandAncestors(parentIri);
                var result = store.CreateClass(name.Text, parentIri);
                created = result.Entity;
                return result.Error;
            },
            "The new class is asserted as a subclass of the selection. Nothing else in the ontology changes.",
            "Create class",
            () =>
            {
                if (created == null)
                    return;
                selection.Select(created.Iri, true);
                Report($"Created {Ns.Shorten(created.Iri)} as a subclass of {Ns.Shorten(parentIri!)}.");
            });
    }

    private void NewIndividual()
    {
        var types = store.ByType.Keys.OrderBy(Ns.Local, StringComparer.Create(Ns.Culture, false)).ToArray();
        if (types.Length == 0 || store.Customers.Count == 0)
        {
            Report("Generate a dataset first — there are no instantiable types in the demo namespace yet.", true);
            return;
        }
        var type = Ui.Named(new ComboBox { ItemsSource = types.Select(i => new SearchItem(i, Ns.Humanise(Ns.Local(i)))).ToArray(), SelectedIndex = 0 }, "Type");
        var branch = Ui.Named(new ComboBox { ItemsSource = Store.Branches, SelectedIndex = 0 }, "Branch");
        var price = Ui.Field("Price", "11.50");
        price.Text = "11.50";
        price.InputScope = new InputScope { Names = { new InputScopeName(InputScopeNameValue.Number) } };
        var rating = Ui.Named(new ComboBox { ItemsSource = new[] { 1, 2, 3, 4, 5 }, SelectedIndex = 4 }, "Rating");
        var customer = Ui.Named(new ComboBox { ItemsSource = store.Customers, DisplayMemberPath = "Name", SelectedIndex = 0, IsTextSearchEnabled = true, MaxDropDownHeight = 280 }, "Customer");
        Individual? created = null;
        Form("New individual",
            [
                new("Type", type, true),
                new("Branch", branch, true),
                new("Price, GBP", price, true, () => Store.ValidatePrice(price.Text, out _)),
                new("Rating", rating, true),
                new("Customer", customer, true, () => customer.SelectedIndex < 0 ? "Choose a customer." : null)
            ],
            () =>
            {
                var result = store.CreateIndividual(((SearchItem)type.SelectedItem).Iri, (string)branch.SelectedItem, price.Text, rating: (int)rating.SelectedItem, customerIndex: customer.SelectedIndex);
                created = result.Individual;
                return result.Error;
            },
            "Adds one record to the generated demo dataset. It appears in the table, the graph and the query results immediately.",
            "Create individual",
            () =>
            {
                if (created == null)
                    return;
                selection.Select(created.Iri, true);
                Report($"Created {Ns.Shorten(created.Iri)}.");
            });
    }
}
