using System.Diagnostics;
using Axiom.Core;
using Microsoft.Graphics.Canvas;
using Windows.Storage;
using Windows.Storage.Streams;
namespace Axiom.App;
public sealed partial class GraphView
{
    public async Task WaitIdle()
    {
        await gate.WaitAsync();
        gate.Release();
    }
    public async Task<object> VerifyRendering(string directory, string theme)
    {
        await WaitIdle();
        await gate.WaitAsync();
        layingOut = true;
        try
        {
            Directory.CreateDirectory(directory);
            const double width = 1600, height = 1000;
            var fitted = Camera.Fit(View, width, height);
            var timings = new List<double>();
            ProfileDraw? profile = null;
            using (var target = new CanvasRenderTarget(canvas.Device, (float)width, (float)height, 96))
            {
                for (var i = 0; i < 63; i++)
                {
                    File.AppendAllText(Path.Combine(directory, "native-progress.log"), "Frame " + i + " " + DateTimeOffset.Now + "\n");
                    var timer = Stopwatch.StartNew();
                    using (var session = target.CreateDrawingSession())
                    {
                        SceneRenderer.Render(new Win2DDraw(session, textCache!), View, Layout, fitted, width, height, Theme.Dark, null);
                    }
                    if (i >= 3)
                        timings.Add(timer.Elapsed.TotalMilliseconds);
                }
                using (var session = target.CreateDrawingSession())
                {
                    profile = new ProfileDraw(new Win2DDraw(session, textCache!));
                    SceneRenderer.Render(profile, View, Layout, fitted, width, height, Theme.Dark, null);
                }
                var file = await StorageFile.GetFileFromPathAsync(Path.GetFullPath(Path.Combine(directory, "graph-" + theme + ".png")).Replace('/', Path.DirectorySeparatorChar)).AsTask().ContinueWith(t => t.IsCompletedSuccessfully ? t.Result : null);
                if (file == null)
                {
                    var folder = await StorageFolder.GetFolderFromPathAsync(Path.GetFullPath(directory));
                    file = await folder.CreateFileAsync("graph-" + theme + ".png", CreationCollisionOption.ReplaceExisting);
                }
                using var output = await file.OpenAsync(FileAccessMode.ReadWrite);
                output.Size = 0;
                await target.SaveAsync(output, CanvasBitmapFileFormat.Png);
            }
            var bounds = SceneRenderer.Bounds(View)!.Value;
            using var metrics = new SvgDraw(1, 1, textCache!.Measure);
            var ew = SceneRenderer.ExportWidth(metrics, bounds.Width, View, Layout, DateTimeOffset.Now);
            var eh = Math.Max(240, bounds.Height) + 144;
            using (var svg = new SvgDraw(ew, eh, textCache!.Measure))
            {
                SceneRenderer.Render(svg, View, Layout, new((ew - bounds.Width) / 2 - bounds.X, 86 - bounds.Y, 1), ew, eh, Theme.Dark, null, 4000);
                SceneRenderer.ExportChrome(svg, View, Layout, ew, eh, Theme.Dark, DateTimeOffset.Now);
                File.WriteAllText(Path.Combine(directory, "export-" + theme + ".svg"), svg.Finish());
            }
            timings.Sort();
            return new
            {
                Theme = theme,
                Nodes = View.Nodes.Count,
                Edges = View.Edges.Count,
                RecordedFrames = timings.Count,
                MedianCommandTimeMs = timings[timings.Count / 2],
                P95CommandTimeMs = timings[(int)(timings.Count * .95)],
                P99CommandTimeMs = GraphFrameRun.Percentile(timings, .99),
                MeasuresPresentation = false,
                ProfilingExcludedFromTimings = true,
                Profile = profile!.Samples.ToDictionary(p => p.Key, p => new { p.Value.Calls, Ms = p.Value.Ticks * 1000d / Stopwatch.Frequency })
            };
        }
        finally { layingOut = false; gate.Release(); Invalidate(); }
    }
}
