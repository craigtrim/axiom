using Axiom.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Windows.System;
namespace Axiom.App;
public sealed record CellValue(string Text, string? Iri = null, string Colour = "text");
public sealed record CellAddress(int Row, int Column);
// A constant-size row window inside a true-height spacer. Event handlers belong to this container.
public sealed class VirtualGrid : UserControl
{
    private readonly Grid root = Ui.Grid("32,*", "*");
    private readonly ScrollViewer headerScroll = new() { HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden, VerticalScrollBarVisibility = ScrollBarVisibility.Disabled, IsTabStop = false };
    private readonly ScrollViewer scroll = new() { HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollMode = ScrollMode.Enabled };
    private readonly Canvas spacer = new();
    private readonly GridHeaderRow header = new() { Height = Theme.RowHeight };
    private int rowCount, lastFirst = -1, lastCount = -1, currentRow, currentColumn;
    private double lastWidth;
    private TableColumn[] columns = [];
    private Func<int, int, CellValue> cell = (_, _) => new("");
    private Func<int, bool> selected = _ => false;
    private bool editing;
    private Border? editorCell;
    private UIElement? previous;
    private Control? editor;
    private (string? Iri, int Row, int Column, string Message)? invalid;
    private readonly DispatcherTimer invalidTimer = new() { Interval = TimeSpan.FromMilliseconds(1800) };
    public event Action? SelectionCleared;
    public event Action<int, int, bool>? Activated;
    public event Action<int>? SortRequested;
    public Func<int, int, string, string?>? CommitRequested;
    public event Action<string>? Warning;
    public int RealizedRows => spacer.Children.Count;
    public VirtualGrid()
    {
        Content = root;
        root.RowDefinitions[0].Height = new(Theme.RowHeight);
        invalidTimer.Tick += (_, _) => { invalidTimer.Stop(); invalid = null; Render(true); };
        IsTabStop = true;
        Ui.Named(this, "Data grid");
        root.Background = Theme.Brush("surface");
        headerScroll.Content = header;
        Ui.Add(root, headerScroll);
        scroll.Content = spacer;
        Ui.Add(root, scroll, 1);
        scroll.ViewChanged += (_, _) => { headerScroll.ChangeView(scroll.HorizontalOffset, null, null, true); Render(); };
        SizeChanged += (_, _) => { root.Clip = new RectangleGeometry { Rect = new(0, 0, ActualWidth, ActualHeight) }; Render(true); };
        Loaded += (_, _) => Render(true);
        spacer.Tapped += (_, e) => { if (Address(e.OriginalSource as DependencyObject) is { } a) { currentRow = a.Row; currentColumn = a.Column; Activated?.Invoke(a.Row, a.Column, false); if (!editing) Focus(FocusState.Pointer); e.Handled = true; } };
        spacer.DoubleTapped += (_, e) => { if (Address(e.OriginalSource as DependencyObject) is { } a) { Activated?.Invoke(a.Row, a.Column, true); e.Handled = true; } };

        KeyDown += Keys;
        GotFocus += (_, _) => Render(true);
        LostFocus += (_, _) => Render(true);
    }

    protected override Microsoft.UI.Xaml.Automation.Peers.AutomationPeer OnCreateAutomationPeer() => new GridPeer(this);
    internal IEnumerable<Microsoft.UI.Xaml.Automation.Peers.AutomationPeer> AutomationHeaders() => header.Children.OfType<GridHeaderButton>().Select(button => button.Peer);
    internal Microsoft.UI.Xaml.Automation.Peers.AutomationPeer AutomationHeaderRow() => header.Peer;
    internal string AutomationColumnId(int column) => columns[column].Id;
    internal IEnumerable<int> AutomationSelectedRows() => Enumerable.Range(0, rowCount).Where(selected).Take(1);
    internal void AutomationSelectRow(int row) => Activated?.Invoke(row, -1, false);
    internal void AutomationClearSelection() => SelectionCleared?.Invoke();
    internal string? AutomationError(int row, int column) => invalid is { } error && error.Column == column && (error.Iri != null ? row < rowCount && cell(row, 0).Iri == error.Iri : error.Row == row) ? error.Message : null;
    internal bool AutomationOffscreen(int row, int column, bool entireRow = false)
    {
        if (row < 0 || row >= rowCount)
            return true;
        var widths = TableModel.Widths(Math.Max(0, scroll.ViewportWidth), columns);
        var x = widths.Take(column).Sum() - scroll.HorizontalOffset;
        var y = row * Theme.RowHeight - scroll.VerticalOffset;
        return y + Theme.RowHeight <= 0 || y >= scroll.ViewportHeight || (!entireRow && (x + widths[column] <= 0 || x >= scroll.ViewportWidth));
    }
    internal object? AutomationScroll() => Microsoft.UI.Xaml.Automation.Peers.FrameworkElementAutomationPeer.CreatePeerForElement(scroll)?.GetPattern(Microsoft.UI.Xaml.Automation.Peers.PatternInterface.Scroll);
    internal Microsoft.UI.Xaml.Automation.Peers.AutomationPeer? AutomationEditor(int row, int column) => editing && editor != null && editorCell?.Tag is CellAddress address && address.Row == row && address.Column == column ? Microsoft.UI.Xaml.Automation.Peers.FrameworkElementAutomationPeer.CreatePeerForElement(editor) : null;
    internal int AutomationRowCount => rowCount;
    internal int AutomationColumnCount => columns.Length;
    internal int FirstRealized => Math.Max(0, lastFirst);
    internal string AutomationHeader(int column) => columns[column].Header;
    internal string AutomationValue(int row, int column) => row < rowCount ? cell(row, column).Text : "";
    internal bool AutomationEditable(int column) => columns[column].Editable;
    internal bool AutomationSelected(int row) => row < rowCount && selected(row);
    internal CellAddress? CurrentEditableCell => FocusState != FocusState.Unfocused && rowCount > 0 && columns.Length > 0 && columns[currentColumn].Editable ? new(currentRow, currentColumn) : null;
    internal bool HasCellFocus(int row, int column) => FocusState != FocusState.Unfocused && currentRow == row && currentColumn == column;
    internal void AutomationEdit(int row, int column, string value)
    {
        var error = CommitRequested?.Invoke(row, column, value);
        if (error != null)
        {
            SetInvalid(row, column, error);
            throw new ArgumentException(error);
        }
        Render(true);
    }
    internal void AutomationInvoke(int row, int column) => Activated?.Invoke(row, column, !columns[column].Editable);
    internal void AutomationRealize(int row, int column)
    {
        currentRow = row;
        currentColumn = column;
        EnsureCurrentVisible();
        Render(true);
        Focus(FocusState.Programmatic);
        Activated?.Invoke(row, -1, false);
    }
    internal Windows.Foundation.Rect AutomationBounds(int row, int column)
    {
        var b = new Microsoft.UI.Xaml.Automation.Peers.FrameworkElementAutomationPeer(scroll).GetBoundingRectangle();
        var scale = XamlRoot?.RasterizationScale ?? 1;
        var widths = TableModel.Widths(Math.Max(0, scroll.ViewportWidth), columns);
        return new(b.X + (widths.Take(column).Sum() - scroll.HorizontalOffset) * scale, b.Y + (row * Theme.RowHeight - scroll.VerticalOffset) * scale, widths[column] * scale, Theme.RowHeight * scale);
    }

    private static CellAddress? Address(DependencyObject? element)
    {
        while (element != null)
        {
            if (element is FrameworkElement { Tag: CellAddress a })
                return a;
            element = VisualTreeHelper.GetParent(element);
        }
        return null;
    }
    public void Set(TableColumn[] columns, int count, Func<int, int, CellValue> values, Func<int, bool>? selection = null, string? sort = null, int direction = 1, bool reset = false)
    {
        CancelEdit();
        this.columns = columns;
        rowCount = count;
        cell = values;
        selected = selection ?? (_ => false);
        spacer.Height = count * Theme.RowHeight;
        if (reset)
            scroll.ChangeView(null, 0, null, true);
        currentRow = Math.Clamp(currentRow, 0, Math.Max(0, count - 1));
        currentColumn = Math.Clamp(currentColumn, 0, Math.Max(0, columns.Length - 1));
        BuildHeader(sort, direction);
        Render(true);
    }
    private void BuildHeader(string? sort, int direction)
    {
        header.Children.Clear();
        header.ColumnDefinitions.Clear();
        var widths = TableModel.Widths(Math.Max(0, scroll.ViewportWidth), columns);
        header.Width = widths.Sum();
        for (var c = 0; c < columns.Length; c++)
        {
            var col = columns[c];
            header.ColumnDefinitions.Add(new()
            {
                Width = new(widths[c])
            });
            var index = c;
            var button = Ui.Named(new GridHeaderButton { Content = col.Header + (sort == col.Id ? (direction == 1 ? " ↑" : " ↓") : ""), IsTabStop = false, FontFamily = new(Theme.UiFont), FontSize = Theme.Body }, col.Header);
            button.Click += (_, _) => SortRequested?.Invoke(index);
            button.Tag = new CellAddress(-1, c);
            button.Height = Theme.RowHeight;
            button.HorizontalAlignment = HorizontalAlignment.Stretch;
            button.HorizontalContentAlignment = HorizontalAlignment.Left;
            button.Padding = new(12, 0, 12, 0);
            button.BorderThickness = new(0);
            button.Background = Theme.Brush("surface-alt");
            Microsoft.UI.Xaml.Automation.AutomationProperties.SetItemStatus(button, sort == col.Id ? (direction == 1 ? "ascending" : "descending") : "none");
            button.KeyDown += (_, e) => { if (e.Key is VirtualKey.Enter or VirtualKey.Space) { SortRequested?.Invoke(((CellAddress)button.Tag).Column); e.Handled = true; } };
            Ui.Add(header, button, 0, c);
        }
    }
    public void RefreshMetrics()
    {
        root.RowDefinitions[0].Height = new(Theme.RowHeight);
        header.Height = Theme.RowHeight;
        foreach (var button in header.Children.OfType<GridHeaderButton>())
            button.Height = Theme.RowHeight;
        spacer.Height = rowCount * Theme.RowHeight;
        foreach (var row in spacer.Children.OfType<Grid>())
        {
            row.Height = Theme.RowHeight;
            if (row.Tag is CellAddress address)
                Canvas.SetTop(row, address.Row * Theme.RowHeight);
        }
        if (editor != null)
            editor.Height = Theme.RowHeight - 8 * Theme.TextScale;
        EnsureCurrentVisible();
        Render(true);
    }
    public void Render(bool force = false)
    {
        if (columns.Length == 0 || editing)
            return;
        var width = Math.Max(0, scroll.ViewportWidth);
        if (width == 0)
            width = Math.Max(0, ActualWidth - 16);
        var window = TableModel.Window(scroll.VerticalOffset, Math.Max(0, scroll.ViewportHeight), rowCount, Theme.RowHeight);
        if (!force && lastFirst == window.First && lastCount == window.Count && Math.Abs(lastWidth - width) < .5)
            return;
        lastFirst = window.First;
        lastCount = window.Count;
        lastWidth = width;
        var widths = TableModel.Widths(width, columns);
        spacer.Width = widths.Sum();
        header.Width = spacer.Width;
        for (var c = 0; c < columns.Length && c < header.ColumnDefinitions.Count; c++)
            header.ColumnDefinitions[c].Width = new(widths[c]);
        while (spacer.Children.Count > window.Count)
            spacer.Children.RemoveAt(spacer.Children.Count - 1);
        for (var slot = 0; slot < window.Count; slot++)
        {
            var r = window.First + slot;
            Grid row;
            if (slot < spacer.Children.Count && spacer.Children[slot] is Grid old && old.Children.Count == columns.Length)
                row = old;
            else
            {
                row = new Grid { Height = Theme.RowHeight };
                for (var c = 0; c < columns.Length; c++)
                {
                    row.ColumnDefinitions.Add(new());
                    var text = Ui.Text("");
                    text.TextTrimming = TextTrimming.CharacterEllipsis;
                    text.TextWrapping = TextWrapping.NoWrap;
                    Ui.Add(row, new Border { Child = text, Padding = new(12, 0, 12, 0), BorderBrush = Theme.Brush("stroke"), BorderThickness = new(0, 0, 0, 1) }, 0, c);
                }
                if (slot < spacer.Children.Count)
                    spacer.Children[slot] = row;
                else
                    spacer.Children.Add(row);
            }
            row.Height = Theme.RowHeight;
            row.Width = spacer.Width;
            row.Background = Theme.Brush(selected(r) ? "layer-selected" : "surface");
            row.Tag = new CellAddress(r, 0);
            Ui.Named(row, $"Row {r + 1}" + (selected(r) ? ", selected" : ""));
            for (var c = 0; c < columns.Length; c++)
            {
                row.ColumnDefinitions[c].Width = new(widths[c]);
                var value = cell(r, c);
                var column = columns[c];
                var border = (Border)row.Children[c];
                var text = (TextBlock)border.Child;
                text.Text = value.Text;
                text.FontSize = column.Mono ? Theme.Code : Theme.Body;
                text.Foreground = Theme.Brush(selected(r) && Theme.HighContrast ? "text-on-accent" : value.Colour);
                text.FontFamily = new(column.Mono ? Theme.MonoFont : Theme.UiFont);
                text.HorizontalAlignment = column.Numeric ? HorizontalAlignment.Right : HorizontalAlignment.Stretch;
                border.Tag = new CellAddress(r, c);
                var invalidCell = AutomationError(r, c) != null;
                var focusedCell = FocusState != FocusState.Unfocused && r == currentRow && c == currentColumn;
                border.BorderBrush = Theme.Brush(invalidCell ? "danger" : focusedCell ? "accent" : "stroke");
                border.BorderThickness = invalidCell || focusedCell ? new(2) : new(0, 0, 0, 1);
                Ui.Named(border, column.Header + ": " + value.Text);
                ToolTipService.SetToolTip(border, value.Iri ?? value.Text);
            }
            Canvas.SetTop(row, r * Theme.RowHeight);
        }
    }

    public void BeginEdit(int row, int column, string value, string[]? options = null)
    {
        if (editing)
            return;
        var cellBorder = spacer.Children.OfType<Grid>().SelectMany(g => g.Children.OfType<Border>()).FirstOrDefault(b => b.Tag is CellAddress a && a.Row == row && a.Column == column);
        if (cellBorder == null)
            return;
        currentRow = row;
        currentColumn = column;
        editorCell = cellBorder;
        previous = cellBorder.Child;
        editing = true;
        if (options != null)
            editor = new ComboBox { ItemsSource = options, SelectedItem = value };
        else
            editor = new TextBox { Text = value, InputScope = new InputScope { Names = { new InputScopeName(InputScopeNameValue.Number) } } };
        Ui.Named(editor, columns[column].Header);
        editor.Height = Theme.RowHeight - 8 * Theme.TextScale;
        editor.MinHeight = 0;
        editor.Padding = new(4, 0, 4, 0);
        editor.BorderThickness = new(1);
        editor.BorderBrush = Theme.Brush("accent");
        editor.CornerRadius = new(2);
        editor.HorizontalAlignment = HorizontalAlignment.Stretch;
        editor.VerticalAlignment = VerticalAlignment.Center;
        cellBorder.Child = editor;
        editor.KeyDown += (_, e) => { if (e.Key == VirtualKey.Escape) { CancelEdit(); Focus(FocusState.Keyboard); e.Handled = true; } else if (e.Key == VirtualKey.Enter) { Focus(FocusState.Keyboard); e.Handled = true; } };
        editor.LostFocus += (_, _) => Commit(row, column);
        if (editor is ComboBox combo)
            combo.SelectionChanged += (_, _) => Commit(row, column);
        editor.Focus(FocusState.Programmatic);
        if (editor is TextBox box)
            box.SelectAll();
    }
    private void Commit(int row, int column)
    {
        if (!editing)
            return;
        var identity = row < rowCount ? cell(row, 0).Iri : null;
        var input = editor is TextBox text ? text.Text : (string?)((ComboBox)editor!).SelectedItem ?? "";
        CancelEdit();
        var message = CommitRequested?.Invoke(row, column, input);
        currentRow = Math.Clamp(row, 0, Math.Max(0, rowCount - 1));
        currentColumn = column;
        if (identity != null)
            for (var index = 0; index < rowCount; index++)
                if (cell(index, 0).Iri == identity)
                {
                    currentRow = index;
                    break;
                }
        if (message != null)
            SetInvalid(currentRow, column, message);
        EnsureCurrentVisible();
        Render(true);
        Focus(FocusState.Keyboard);
    }
    private void SetInvalid(int row, int column, string message)
    {
        invalid = (row < rowCount ? cell(row, 0).Iri : null, row, column, message);
        invalidTimer.Stop();
        invalidTimer.Start();
        Warning?.Invoke(message);
        Render(true);
    }
    private void EnsureCurrentVisible()
    {
        var widths = TableModel.Widths(Math.Max(0, scroll.ViewportWidth), columns);
        if (currentColumn >= widths.Length)
            return;
        var x = widths.Take(currentColumn).Sum();
        var left = scroll.HorizontalOffset;
        if (x < left)
            left = x;
        else if (x + widths[currentColumn] > left + scroll.ViewportWidth)
            left = x + widths[currentColumn] - scroll.ViewportWidth;
        var top = scroll.VerticalOffset;
        var y = currentRow * Theme.RowHeight;
        if (y < top)
            top = y;
        else if (y + Theme.RowHeight > top + scroll.ViewportHeight)
            top = y + Theme.RowHeight - scroll.ViewportHeight;
        scroll.ChangeView(Math.Max(0, left), Math.Max(0, top), null, true);
    }
    private void CancelEdit()
    {
        if (!editing)
            return;
        editing = false;
        if (editorCell != null)
            editorCell.Child = previous;
        editorCell = null;
        editor = null;
        previous = null;
    }
    private void Keys(object sender, KeyRoutedEventArgs e)
    {
        if (editing || rowCount == 0 || columns.Length == 0)
            return;
        var control = Microsoft.UI.Input.InputKeyboardSource.GetKeyStateForCurrentThread(VirtualKey.Control).HasFlag(Windows.UI.Core.CoreVirtualKeyStates.Down);
        if (e.Key is VirtualKey.Up or VirtualKey.Down or VirtualKey.Left or VirtualKey.Right or VirtualKey.Home or VirtualKey.End or VirtualKey.PageUp or VirtualKey.PageDown)
        {
            var page = Math.Max(1, (int)(scroll.ViewportHeight / Theme.RowHeight));
            switch (e.Key)
            {
                case VirtualKey.Up:
                    currentRow--;
                    break;
                case VirtualKey.Down:
                    currentRow++;
                    break;
                case VirtualKey.Left:
                    currentColumn--;
                    break;
                case VirtualKey.Right:
                    currentColumn++;
                    break;
                case VirtualKey.Home:
                    currentColumn = 0;
                    if (control)
                        currentRow = 0;
                    break;
                case VirtualKey.End:
                    currentColumn = columns.Length - 1;
                    if (control)
                        currentRow = rowCount - 1;
                    break;
                case VirtualKey.PageUp:
                    currentRow -= page;
                    break;
                case VirtualKey.PageDown:
                    currentRow += page;
                    break;
            }
            currentRow = Math.Clamp(currentRow, 0, rowCount - 1);
            currentColumn = Math.Clamp(currentColumn, 0, columns.Length - 1);
            EnsureCurrentVisible();
            Activated?.Invoke(currentRow, -1, false);
            Render(true);
            Microsoft.UI.Xaml.Automation.AutomationProperties.SetHelpText(this, columns[currentColumn].Header + ": " + cell(currentRow, currentColumn).Text);
            if (Microsoft.UI.Xaml.Automation.Peers.FrameworkElementAutomationPeer.FromElement(this) is GridPeer peer)
                peer.AnnounceCell(currentRow, currentColumn);
        }
        else if (e.Key == VirtualKey.F2 || e.Key == VirtualKey.Enter && columns[currentColumn].Editable)
            Activated?.Invoke(currentRow, currentColumn, false);
        else if (e.Key == VirtualKey.Enter)
            Activated?.Invoke(currentRow, currentColumn, true);
        else
            return;
        e.Handled = true;
    }
}
