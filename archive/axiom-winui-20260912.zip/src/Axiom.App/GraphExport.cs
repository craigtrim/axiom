using System.Numerics;
using Axiom.Core;
using Microsoft.Graphics.Canvas;
using Microsoft.UI.Xaml;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.Storage.Streams;
namespace Axiom.App;
public static class GraphExport
{
    public static async Task Save(Window owner, Viewport view, Layouts layout, CanvasDevice device, TextCache cache, string kind, bool dark, Action<string, bool> report)
    {
        var bounds = SceneRenderer.Bounds(view)!.Value;
        var timestamp = DateTimeOffset.Now;
        using var metrics = new SvgDraw(1, 1, cache.Measure);
        var width = SceneRenderer.ExportWidth(metrics, bounds.Width, view, layout, timestamp);
        var height = Math.Max(240, bounds.Height) + 144;
        var camera = new Camera((width - bounds.Width) / 2 - bounds.X, 86 - bounds.Y, 1);
        var stem = "axiom-graph-" + layout.Resolved + "-" + view.Nodes.Count + "-nodes-" + timestamp.ToString("yyyyMMdd-HHmmss");
        report("Rendering graph export…", false);
        if (kind == "svg")
        {
            using var svg = new SvgDraw(width, height, cache.Measure);
            SceneRenderer.Render(svg, view, layout, camera, width, height, dark, null, 4000);
            SceneRenderer.ExportChrome(svg, view, layout, width, height, dark, timestamp);
            var file = await Pick(owner, stem, ".svg");
            if (file == null)
            {
                report("Export cancelled.", false);
                return;
            }
            var content = svg.Finish();
            await FileIO.WriteTextAsync(file, content, UnicodeEncoding.Utf8);
            report($"Exported {file.Name} · {System.Text.Encoding.UTF8.GetByteCount(content) / 1024:N0} KB · {file.Path}", false);
            return;
        }
        var scale = SceneRenderer.RasterScale(width, height, kind == "png3" ? 3d : 2d);
        using var target = new CanvasRenderTarget(device, (float)width, (float)height, (float)(96 * scale));
        using (var session = target.CreateDrawingSession())
        {
            var d = new Win2DDraw(session, cache, false);
            SceneRenderer.Render(d, view, layout, camera, width, height, dark, null, 4000);
            SceneRenderer.ExportChrome(d, view, layout, width, height, dark, timestamp);
        }
        using var stream = new InMemoryRandomAccessStream();
        await target.SaveAsync(stream, CanvasBitmapFileFormat.Png);
        if (kind == "clipboard")
        {
            try
            {
                stream.Seek(0);
                var package = new DataPackage();
                package.SetBitmap(RandomAccessStreamReference.CreateFromStream(stream));
                package.SetData("PNG", RandomAccessStreamReference.CreateFromStream(stream));
                Clipboard.SetContent(package);
                Clipboard.Flush();
                report($"Copied graph image · {Math.Round(width * scale):N0} × {Math.Round(height * scale):N0} pixels.", false);
            }
            catch (Exception) { report("Windows refused clipboard access. Use Export PNG and choose a location to save the image.", true); }
            return;
        }
        var output = await Pick(owner, stem, ".png");
        if (output == null)
        {
            report("Export cancelled.", false);
            return;
        }
        using (var destination = await output.OpenAsync(FileAccessMode.ReadWrite))
        {
            destination.Size = 0;
            stream.Seek(0);
            await RandomAccessStream.CopyAsync(stream, destination);
            await destination.FlushAsync();
        }
        report($"Exported {output.Name} · {Math.Round(width * scale):N0} × {Math.Round(height * scale):N0} pixels · {stream.Size / 1024:N0} KB · {output.Path}", false);
    }
    private static async Task<StorageFile?> Pick(Window owner, string name, string extension)
    {
        var picker = new FileSavePicker { SuggestedFileName = name, SuggestedStartLocation = PickerLocationId.Downloads };
        picker.FileTypeChoices.Add(extension == ".svg" ? "SVG vector image" : "PNG image", [extension]);
        WinRT.Interop.InitializeWithWindow.Initialize(picker, WinRT.Interop.WindowNative.GetWindowHandle(owner));
        return await picker.PickSaveFileAsync();
    }
}
