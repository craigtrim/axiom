using System.Numerics;
using Axiom.Core;
using Microsoft.Graphics.Canvas;
using Microsoft.Graphics.Canvas.Geometry;
using Microsoft.Graphics.Canvas.Text;
using Windows.Foundation;
using Windows.UI;
namespace Axiom.App;

public sealed class TextCache : IDisposable
{
    private readonly CanvasDevice device;
    public CanvasStrokeStyle Solid { get; } = new() { LineJoin = CanvasLineJoin.Round };
    public CanvasStrokeStyle Dashed { get; } = new() { LineJoin = CanvasLineJoin.Round, CustomDashStyle = [4, 3] };
    public CanvasCachedGeometry Arrow
    {
        get;
    }
    public CanvasRenderTarget SolidStrip
    {
        get;
    }
    public CanvasRenderTarget DashStrip
    {
        get;
    }
    public CanvasRenderTarget ArrowImage
    {
        get;
    }
    private readonly Dictionary<(string, double, bool, bool), TextEntry> text = [];
    private readonly Dictionary<(double, bool, bool), CanvasTextFormat> formats = [];
    private readonly Dictionary<(double, double), CanvasCachedGeometry> circles = [];
    private readonly Dictionary<(double, double, double, double), CanvasCachedGeometry> rectangles = [];
    public sealed class TextEntry(CanvasTextLayout layout, double width)
    {
        public CanvasTextLayout Layout { get; } = layout; public double Width { get; } = width; public CanvasGeometry? Geometry; public Dictionary<(uint, uint), ShapeTile> Images { get; } = [];
    }

    public TextCache(CanvasDevice device)
    {
        this.device = device;
        using var builder = new CanvasPathBuilder(device);
        builder.BeginFigure(0, 0);
        builder.AddLine(-6, 3);
        builder.AddLine(-6, -3);
        builder.EndFigure(CanvasFigureLoop.Closed);
        using var geometry = CanvasGeometry.CreatePath(builder);
        Arrow = CanvasCachedGeometry.CreateFill(geometry);
        SolidStrip = new CanvasRenderTarget(device, 1, 3, 96);
        using (var draw = SolidStrip.CreateDrawingSession())
        {
            draw.Clear(Windows.UI.Color.FromArgb(0, 0, 0, 0));
            draw.FillRectangle(0, 1, 1, 1, Windows.UI.Color.FromArgb(255, 255, 255, 255));
        }
        DashStrip = new CanvasRenderTarget(device, 8190, 3, 96);
        using (var draw = DashStrip.CreateDrawingSession())
        {
            draw.Clear(Windows.UI.Color.FromArgb(0, 0, 0, 0));
            for (var x = 0; x < 8190; x += 7)
                draw.FillRectangle(x, 1, 4, 1, Windows.UI.Color.FromArgb(255, 255, 255, 255));
        }
        ArrowImage = new CanvasRenderTarget(device, 8, 8, 192);
        using (var draw = ArrowImage.CreateDrawingSession())
        {
            draw.Clear(Windows.UI.Color.FromArgb(0, 0, 0, 0));
            draw.FillGeometry(geometry, 7, 4, Windows.UI.Color.FromArgb(255, 255, 255, 255));
        }

    }

    public TextEntry Get(string value, double size, bool bold, bool mono)
    {
        var key = (value, size, bold, mono);
        if (text.TryGetValue(key, out var entry))
            return entry;
        if (text.Count > 6000)
            Clear();
        if (!formats.TryGetValue((size, bold, mono), out var format))
        {
            format = new CanvasTextFormat
            {
                FontFamily = mono ? Theme.MonoFont : Theme.UiFont,
                FontSize = (float)size,
                FontWeight = bold ? Microsoft.UI.Text.FontWeights.SemiBold : Microsoft.UI.Text.FontWeights.Normal,
                WordWrapping = CanvasWordWrapping.NoWrap
            };
            formats.Add((size, bold, mono), format);
        }
        var layout = new CanvasTextLayout(device, value, format, 100000, 100);
        entry = new(layout, layout.LayoutBounds.Width);
        text.Add(key, entry);
        return entry;
    }

    public CanvasCachedGeometry Circle(double radius, double stroke)
    {
        if (circles.TryGetValue((radius, stroke), out var cached))
            return cached;
        if (circles.Count > 2000)
        {
            foreach (var value in circles.Values)
                value.Dispose();
            circles.Clear();
        }
        using var shape = CanvasGeometry.CreateCircle(device, 0, 0, (float)radius);
        cached = stroke > 0 ? CanvasCachedGeometry.CreateStroke(shape, (float)stroke) : CanvasCachedGeometry.CreateFill(shape);
        circles.Add((radius, stroke), cached);
        return cached;
    }
    public CanvasCachedGeometry Rectangle(double width, double height, double radius, double stroke)
    {
        var key = (width, height, radius, stroke);
        if (rectangles.TryGetValue(key, out var result))
            return result;
        if (rectangles.Count > 4000)
        {
            foreach (var item in rectangles.Values)
                item.Dispose();
            rectangles.Clear();
        }
        using var geometry = CanvasGeometry.CreateRoundedRectangle(device, 0, 0, (float)width, (float)height, (float)radius, (float)radius);
        result = stroke > 0 ? CanvasCachedGeometry.CreateStroke(geometry, (float)stroke, Solid) : CanvasCachedGeometry.CreateFill(geometry);
        rectangles.Add(key, result);
        return result;
    }

    private readonly List<CanvasRenderTarget> labelPages = [];
    private readonly List<CanvasRenderTarget> retiredLabels = [];
    private CanvasRenderTarget? labelPage;
    private double labelX, labelY, labelRow;
    private readonly Dictionary<(string Text, uint Surface, uint Stroke, uint Foreground, double Scale), ShapeTile> badgeImages = [];
    private ShapeTile AllocateLabel(double w, double h)
    {
        if (labelX + w > 1024)
        {
            labelX = 0;
            labelY += labelRow;
            labelRow = 0;
        }
        if (labelPage == null || labelY + h > 1024)
        {
            if (labelPages.Count >= 4)
            {
                retiredLabels.AddRange(labelPages);
                labelPages.Clear();
                foreach (var entry in text.Values)
                    entry.Images.Clear();
                badgeImages.Clear();
            }
            labelPage = new CanvasRenderTarget(device, 1024, 1024, 192);
            labelPages.Add(labelPage);
            labelX = labelY = labelRow = 0;
            using var clear = labelPage.CreateDrawingSession();
            clear.Clear(Windows.UI.Color.FromArgb(0, 0, 0, 0));
        }
        var tile = new ShapeTile(labelPage, new(labelX, labelY, w, h));
        labelX += w;
        labelRow = Math.Max(labelRow, h);
        return tile;
    }
    public ShapeTile LabelImage(TextEntry entry, uint colour, uint halo)
    {
        if (entry.Images.TryGetValue((colour, halo), out var tile))
            return tile;
        tile = AllocateLabel(Math.Ceiling(entry.Width + 8), Math.Ceiling(entry.Layout.LayoutBounds.Height + 8));
        entry.Geometry ??= CanvasGeometry.CreateText(entry.Layout);
        using (var draw = tile.Image.CreateDrawingSession())
        {
            draw.DrawGeometry(entry.Geometry, (float)tile.Source.X + 4, (float)tile.Source.Y + 4, Win2DDraw.Colour(halo), 3.5f, Solid);
            draw.DrawTextLayout(entry.Layout, (float)tile.Source.X + 4, (float)tile.Source.Y + 4, Win2DDraw.Colour(colour));
        }
        entry.Images.Add((colour, halo), tile);
        return tile;
    }
    public ShapeTile BadgeImage(string value, uint surface, uint stroke, uint foreground, double scale)
    {
        var key = (value, surface, stroke, foreground, scale);
        if (badgeImages.TryGetValue(key, out var tile))
            return tile;
        var entry = Get(value, 9.5 * scale, true, false);
        var width = entry.Width + 9 * scale;
        var height = 14 * scale;
        tile = AllocateLabel(Math.Ceiling(width + 4), Math.Ceiling(height + 4));
        using (var draw = tile.Image.CreateDrawingSession())
        {
            var bounds = new Rect(tile.Source.X + 2, tile.Source.Y + 2, width, height);
            draw.FillRoundedRectangle(bounds, (float)(7 * scale), (float)(7 * scale), Win2DDraw.Colour(surface));
            draw.DrawRoundedRectangle(bounds, (float)(7 * scale), (float)(7 * scale), Win2DDraw.Colour(stroke), 1);
            draw.DrawTextLayout(entry.Layout, (float)(bounds.X + (width - entry.Width) / 2), (float)(bounds.Y + (height - entry.Layout.LayoutBounds.Height) / 2 + .5 * scale), Win2DDraw.Colour(foreground));
        }
        badgeImages.Add(key, tile);
        return tile;
    }
    public void RetireLabels()
    {
        foreach (var page in retiredLabels)
            page.Dispose();
        retiredLabels.Clear();
    }

    public sealed record ShapeTile(CanvasRenderTarget Image, Rect Source);
    private CanvasRenderTarget? atlas;
    private double atlasX, atlasY, atlasRow;
    private readonly Dictionary<(bool, double, double, double, double), ShapeTile> tiles = [];
    private readonly List<CanvasRenderTarget> retired = [];
    public ShapeTile Tile(bool circle, double width, double height, double radius, double stroke)
    {
        var key = (circle, width, height, radius, stroke);
        if (tiles.TryGetValue(key, out var tile))
            return tile;
        var pad = 2 + stroke / 2;
        var w = Math.Ceiling(width + pad * 2);
        var h = Math.Ceiling(height + pad * 2);
        if (atlas == null || atlasY + h > 512)
        {
            if (atlas != null)
                retired.Add(atlas);
            atlas = new CanvasRenderTarget(device, 512, 512, 192);
            using (var clear = atlas.CreateDrawingSession())
                clear.Clear(Windows.UI.Color.FromArgb(0, 0, 0, 0));
            atlasX = atlasY = atlasRow = 0;
            tiles.Clear();
        }
        if (atlasX + w > 512)
        {
            atlasX = 0;
            atlasY += atlasRow;
            atlasRow = 0;
            if (atlasY + h > 512)
                return NewTile();
        }
        return DrawTile();
        ShapeTile NewTile()
        {
            retired.Add(atlas!);
            atlas = null;
            return Tile(circle, width, height, radius, stroke);
        }
        ShapeTile DrawTile()
        {
            using (var draw = atlas!.CreateDrawingSession())
            {
                var colour = Windows.UI.Color.FromArgb(255, 255, 255, 255);
                if (circle)
                {
                    if (stroke > 0)
                        draw.DrawCircle((float)(atlasX + pad + width / 2), (float)(atlasY + pad + height / 2), (float)(width / 2), colour, (float)stroke);
                    else
                        draw.FillCircle((float)(atlasX + pad + width / 2), (float)(atlasY + pad + height / 2), (float)(width / 2), colour);
                }
                else
                {
                    var rect = new Rect(atlasX + pad, atlasY + pad, width, height);
                    if (stroke > 0)
                        draw.DrawRoundedRectangle(rect, (float)radius, (float)radius, colour, (float)stroke);
                    else
                        draw.FillRoundedRectangle(rect, (float)radius, (float)radius, colour);
                }
            }
            var result = new ShapeTile(atlas!, new(atlasX, atlasY, w, h));
            tiles[key] = result;
            atlasX += w;
            atlasRow = Math.Max(atlasRow, h);
            return result;
        }
    }
    public void RetireAtlases()
    {
        foreach (var image in retired)
            image.Dispose();
        retired.Clear();
    }

    private (double Step, uint Colour, CanvasRenderTarget Image, Microsoft.Graphics.Canvas.Brushes.CanvasImageBrush Brush)? dots;
    public Microsoft.Graphics.Canvas.Brushes.CanvasImageBrush Dots(double step, uint colour)
    {
        if (dots is { } old && old.Step == step && old.Colour == colour)
            return old.Brush;
        var image = new CanvasRenderTarget(device, (float)Math.Ceiling(step), (float)Math.Ceiling(step), 192);
        using (var draw = image.CreateDrawingSession())
        {
            draw.Clear(Windows.UI.Color.FromArgb(0, 0, 0, 0));
            foreach (var x in new[] { 0d, step })
                foreach (var y in new[] { 0d, step })
                    draw.FillCircle((float)x, (float)y, .7f, Win2DDraw.Colour(colour));
        }
        var brush = new Microsoft.Graphics.Canvas.Brushes.CanvasImageBrush(device, image) { ExtendX = CanvasEdgeBehavior.Wrap, ExtendY = CanvasEdgeBehavior.Wrap, SourceRectangle = new Rect(0, 0, step, step) };
        if (dots is { } previous)
        {
            previous.Brush.Dispose();
            previous.Image.Dispose();
        }
        dots = (step, colour, image, brush);
        return brush;
    }

    public double Measure(string value, double size, bool bold = false, bool mono = false) => Get(value, size, bold, mono).Width;
    public void Clear()
    {
        foreach (var entry in text.Values)
        {
            entry.Geometry?.Dispose();
            entry.Images.Clear();
            entry.Layout.Dispose();
        }
        text.Clear();
    }
    public void Dispose()
    {
        RetireLabels();
        foreach (var page in labelPages)
            page.Dispose();
        labelPages.Clear();
        RetireAtlases();
        atlas?.Dispose();
        tiles.Clear();
        foreach (var shape in circles.Values)
            shape.Dispose();
        circles.Clear();
        foreach (var format in formats.Values)
            format.Dispose();
        formats.Clear();
        SolidStrip.Dispose();
        DashStrip.Dispose();
        ArrowImage.Dispose();
        if (dots is { } tile)
        {
            tile.Brush.Dispose();
            tile.Image.Dispose();
            dots = null;
        }
        Clear();
        foreach (var item in rectangles.Values)
            item.Dispose();
        rectangles.Clear();
        Arrow.Dispose();
        Solid.Dispose();
        Dashed.Dispose();
    }
}

public sealed class Win2DDraw(CanvasDrawingSession session, TextCache cache, bool rasterLabels = true) : IDraw
{

    private CanvasSpriteBatch? labelSprites;
    public void BeginBadges()
    {
        if (rasterLabels)
            labelSprites = session.CreateSpriteBatch();
    }
    public void EndBadges() => EndLabels();
    public void Badge(string value, PointD anchor, uint surface, uint stroke, uint foreground, double scale = 1)
    {
        var entry = cache.Get(value, 9.5 * scale, true, false);
        var width = entry.Width + 9 * scale;
        var height = 14 * scale;
        if (rasterLabels)
        {
            var tile = cache.BadgeImage(value, surface, stroke, foreground, scale);
            var target = new Rect(anchor.X - width / 2 - 2, anchor.Y - height / 2 - 2, tile.Source.Width, tile.Source.Height);
            if (labelSprites != null)
                labelSprites.DrawFromSpriteSheet(tile.Image, target, tile.Source);
            else
                session.DrawImage(tile.Image, target, tile.Source);
        }
        else
        {
            var bounds = new Rect(anchor.X - width / 2, anchor.Y - height / 2, width, height);
            session.FillRoundedRectangle(bounds, (float)(7 * scale), (float)(7 * scale), Colour(surface));
            session.DrawRoundedRectangle(bounds, (float)(7 * scale), (float)(7 * scale), Colour(stroke), 1);
            session.DrawTextLayout(entry.Layout, (float)(anchor.X - entry.Width / 2), (float)(anchor.Y - entry.Layout.LayoutBounds.Height / 2 + .5 * scale), Colour(foreground));
        }
    }
    public void BeginLabels()
    {
        if (rasterLabels)
            labelSprites = session.CreateSpriteBatch(CanvasSpriteSortMode.Bitmap);
    }
    public void EndLabels()
    {
        labelSprites?.Dispose();
        labelSprites = null;
        cache.RetireLabels();
    }
    private bool nodeBatch;
    private CanvasSpriteBatch? nodeSprites;
    public void BeginNodes()
    {
        nodeBatch = rasterLabels;
        if (nodeBatch)
            nodeSprites = session.CreateSpriteBatch();
    }
    public void EndNodes()
    {
        nodeSprites?.Dispose();
        nodeSprites = null;
        nodeBatch = false;
        cache.RetireAtlases();
    }
    private void Tile(bool circle, double x, double y, double width, double height, double radius, double stroke, uint colour)
    {
        var tile = cache.Tile(circle, width, height, radius, stroke);
        var pad = 2 + stroke / 2;
        nodeSprites!.DrawFromSpriteSheet(tile.Image, new Rect(x - pad, y - pad, tile.Source.Width, tile.Source.Height), tile.Source, Tint(colour));
    }

    private bool batching;
    private CanvasSpriteBatch? sprites;
    private readonly List<(PointD[] Points, uint Colour, double Stroke, bool Closed, bool Fill, bool Dashed, PointD? Quadratic)> deferred = [];
    public void BeginPaths()
    {
        batching = rasterLabels;
        if (batching)
            sprites = session.CreateSpriteBatch(CanvasSpriteSortMode.Bitmap);
    }
    public void EndPaths()
    {
        batching = false;
        sprites?.Dispose();
        sprites = null;
        foreach (var p in deferred)
            Path(p.Points, p.Colour, p.Stroke, p.Closed, p.Fill, p.Dashed, p.Quadratic);
        deferred.Clear();
    }
    private static Vector4 Tint(uint colour) => new((colour >> 16 & 255) / 255f, (colour >> 8 & 255) / 255f, (colour & 255) / 255f, (colour >> 24) / 255f);
    private void SpriteLine(PointD p, PointD q, uint colour, double stroke, bool dashed)
    {
        var dx = q.X - p.X;
        var dy = q.Y - p.Y;
        var length = Math.Sqrt(dx * dx + dy * dy);
        if (length < .001)
            return;
        var angle = (float)Math.Atan2(dy, dx);
        var rotation = Matrix3x2.CreateRotation(angle);
        var tint = Tint(colour);
        if (!dashed)
        {
            var transform = Matrix3x2.CreateTranslation(0, -1.5f) * Matrix3x2.CreateScale((float)length, (float)stroke) * rotation * Matrix3x2.CreateTranslation(V(p));
            sprites!.Draw(cache.SolidStrip, transform, tint);
            return;
        }
        for (double offset = 0; offset < length; offset += 8190)
        {
            var span = Math.Min(8190, length - offset);
            var source = Math.Ceiling(span);
            var transform = Matrix3x2.CreateTranslation(0, -1.5f) * Matrix3x2.CreateScale((float)(span / source), (float)stroke) * rotation * Matrix3x2.CreateTranslation((float)(p.X + dx / length * offset), (float)(p.Y + dy / length * offset));
            sprites!.DrawFromSpriteSheet(cache.DashStrip, transform, new Rect(0, 0, source, 3), tint);
        }
    }
    public void Dots(double step, double x, double y, double width, double height, uint colour)
    {
        var brush = cache.Dots(step, colour);
        brush.Transform = Matrix3x2.CreateTranslation((float)x, (float)y);
        session.FillRectangle(new Rect(0, 0, width, height), brush);
    }

    public static Color Colour(uint c) => Color.FromArgb((byte)(c >> 24), (byte)(c >> 16), (byte)(c >> 8), (byte)c);
    private static Vector2 V(PointD p) => new((float)p.X, (float)p.Y);
    public double Measure(string value, double size, bool bold = false, bool mono = false) => cache.Measure(value, size, bold, mono);

    public void Rectangle(RectD r, uint c, double radius = 0, double stroke = 0)
    {
        if (r.Width <= 0 || r.Height <= 0)
            return;
        if (nodeBatch)
        {
            Tile(false, r.X, r.Y, r.Width, r.Height, radius, stroke, c);
            return;
        }
        if (radius == 0)
        {
            var rect = new Rect(r.X, r.Y, r.Width, r.Height);
            if (stroke > 0)
                session.DrawRectangle(rect, Colour(c), (float)stroke);
            else
                session.FillRectangle(rect, Colour(c));
            return;
        }
        session.DrawCachedGeometry(cache.Rectangle(r.Width, r.Height, radius, stroke), (float)r.X, (float)r.Y, Colour(c));
    }

    public void Circle(PointD p, double r, uint c, double stroke = 0)
    {
        if (nodeBatch)
        {
            Tile(true, p.X - r, p.Y - r, r * 2, r * 2, 0, stroke, c);
            return;
        }
        session.DrawCachedGeometry(cache.Circle(r, stroke), (float)p.X, (float)p.Y, Colour(c));
    }

    public void Line(PointD p, PointD q, uint colour, double stroke = 1, bool dashed = false)
    {
        if (batching)
            SpriteLine(p, q, colour, stroke, dashed);
        else
            session.DrawLine(V(p), V(q), Colour(colour), (float)stroke, dashed ? cache.Dashed : cache.Solid);
    }
    public void Arrow(PointD tip, double ux, double uy, uint colour)
    {
        if (batching)
        {
            var transform = Matrix3x2.CreateTranslation(-7, -4) * Matrix3x2.CreateRotation((float)Math.Atan2(uy, ux)) * Matrix3x2.CreateTranslation(V(tip));
            sprites!.Draw(cache.ArrowImage, transform, Tint(colour));
            return;
        }
        Path([tip, new(tip.X - ux * 6 - uy * 3, tip.Y - uy * 6 + ux * 3), new(tip.X - ux * 6 + uy * 3, tip.Y - uy * 6 - ux * 3)], colour, closed: true, fill: true);
    }
    public void Path(PointD[] points, uint c, double stroke = 1, bool closed = false, bool fill = false, bool dashed = false, PointD? quadratic = null)
    {
        if (points.Length == 0)
            return;
        if (nodeBatch)
        {
            nodeSprites?.Dispose();
            nodeSprites = session.CreateSpriteBatch();
        }
        if (batching)
        {
            if (points.Length == 2 && quadratic == null && !fill)
            {
                SpriteLine(points[0], points[1], c, stroke, dashed);
                return;
            }
            if (points.Length == 3 && closed && fill)
            {
                var tip = points[0];
                var angle = (float)Math.Atan2(tip.Y - (points[1].Y + points[2].Y) / 2, tip.X - (points[1].X + points[2].X) / 2);
                var transform = Matrix3x2.CreateTranslation(-7, -4) * Matrix3x2.CreateRotation(angle) * Matrix3x2.CreateTranslation(V(tip));
                sprites!.Draw(cache.ArrowImage, transform, Tint(c));
                return;
            }
            deferred.Add((points, c, stroke, closed, fill, dashed, quadratic));
            return;
        }
        if (points.Length == 2 && quadratic == null && !closed && !fill)
        {
            session.DrawLine(V(points[0]), V(points[1]), Colour(c), (float)stroke, dashed ? cache.Dashed : cache.Solid);
            return;
        }
        if (points.Length == 3 && closed && fill)
        {
            var p = points[0];
            var ux = (p.X - (points[1].X + points[2].X) / 2) / 6;
            var uy = (p.Y - (points[1].Y + points[2].Y) / 2) / 6;
            var original = session.Transform;
            session.Transform = new Matrix3x2((float)ux, (float)uy, (float)-uy, (float)ux, (float)p.X, (float)p.Y) * original;
            session.DrawCachedGeometry(cache.Arrow, Colour(c));
            session.Transform = original;
            return;
        }
        using var builder = new CanvasPathBuilder(session);
        builder.BeginFigure(V(points[0]));
        if (quadratic is { } q)
            builder.AddQuadraticBezier(V(q), V(points[^1]));
        else
            foreach (var p in points.Skip(1))
                builder.AddLine(V(p));
        builder.EndFigure(closed ? CanvasFigureLoop.Closed : CanvasFigureLoop.Open);
        using var geometry = CanvasGeometry.CreatePath(builder);
        if (fill)
            session.FillGeometry(geometry, Colour(c));
        else
            session.DrawGeometry(geometry, Colour(c), (float)stroke, dashed ? cache.Dashed : cache.Solid);
    }

    public void Text(string value, PointD p, uint c, double size, bool bold = false, bool mono = false, bool centred = false, uint? halo = null)
    {
        var entry = cache.Get(value, size, bold, mono);
        var x = (float)(p.X - (centred ? entry.Width / 2 : 0));
        var y = (float)p.Y;
        if (halo is { } h && rasterLabels)
        {
            var tile = cache.LabelImage(entry, c, h);
            var destination = new Rect(x - 4, y - 4, tile.Source.Width, tile.Source.Height);
            if (labelSprites != null)
                labelSprites.DrawFromSpriteSheet(tile.Image, destination, tile.Source);
            else
                session.DrawImage(tile.Image, destination, tile.Source);
            return;
        }
        if (halo is { } background)
        {
            entry.Geometry ??= CanvasGeometry.CreateText(entry.Layout);
            session.DrawGeometry(entry.Geometry, x, y, Colour(background), 3.5f, cache.Solid);
        }
        session.DrawTextLayout(entry.Layout, x, y, Colour(c));
    }
}
