using Axiom.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
namespace Axiom.App;
public sealed partial class MainWindow
{
    private GraphView graph = null!;
    private IndividualsView individuals = null!;
    private QueryView console = null!;
    private readonly Grid dockPages = new();
    partial void SetupGraph()
    {
        graph = new(store, selection, this, Report);
        graphHost.Children.Add(graph);
        Closed += (_, _) => { graph.Dispose(); console.Dispose(); };
    }
    partial void SetupTable()
    {
        individuals = new(store, selection, graph, Report);
        dockPages.Children.Add(individuals);
        Ui.Add(dock, dockPages, 1);
    }
    partial void SetupConsole()
    {
        console = new(store, selection, graph, Report)
        {
            Visibility = Visibility.Collapsed
        };
        dockPages.Children.Add(console);
    }
    partial void RefreshSurfaces(Change change)
    {
        graph.Refresh(change);
        individuals.Refresh(change);
        console.Refresh(change);
    }
    partial void Reveal(string iri) => graph.Reveal(iri);
    partial void ShowDockTab(int index)
    {
        var tab = (TabButton)(index == 0 ? individualsTab : queryTab);
        tab.Strip?.Select(tab);
        individuals.Visibility = index == 0 ? Visibility.Visible : Visibility.Collapsed;
        console.Visibility = index == 1 ? Visibility.Visible : Visibility.Collapsed;
        if (root.RowDefinitions[3].Height.Value == 0)
            ToggleDock();
        if (index == 0)
            individuals.Rows.Render(true);
        else
            console.Results.Render(true);
    }
}
