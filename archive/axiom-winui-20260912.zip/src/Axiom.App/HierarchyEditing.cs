using Axiom.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Windows.System;
namespace Axiom.App;
public sealed partial class HierarchyView
{
    private bool renaming;
    public event Action<string>? Warning;
    public void BeginRename()
    {
        if (renaming || selection.Iri is not { } iri || !nodes.TryGetValue(iri, out var node) || !store.Entities.TryGetValue(iri, out var entity))
            return;
        var original = node.Content;
        var input = Ui.Field("Rename " + entity.Name);
        input.Text = entity.Name;
        input.Height = Theme.TreeRowHeight;
        input.MinWidth = 100;
        input.Padding = new(4, 0, 4, 0);
        renaming = true;
        node.Content = input;
        void Finish(bool commit)
        {
            if (!renaming)
                return;
            renaming = false;
            var value = input.Text;
            node.Content = original;
            if (commit && store.Rename(iri, value) is { } error)
                Warning?.Invoke(error);
            tree.Focus(FocusState.Programmatic);
        }
        input.KeyDown += (_, e) => { if (e.Key == VirtualKey.Enter) { Finish(true); e.Handled = true; } else if (e.Key == VirtualKey.Escape) { Finish(false); e.Handled = true; } };
        input.LostFocus += (_, _) => Finish(true);
        DispatcherQueue.TryEnqueue(() => { input.Focus(FocusState.Programmatic); input.SelectAll(); });
    }
    private void ShowContext(RightTappedRoutedEventArgs args)
    {
        var target = args.OriginalSource as DependencyObject;
        string? iri = null;
        while (target != null)
        {
            if (target is FrameworkElement { Tag: string key })
            {
                iri = key;
                break;
            }
            target = VisualTreeHelper.GetParent(target);
        }
        if (iri == null)
            return;
        selection.Select(iri);
        var menu = new MenuFlyout();
        void Item(string label, Action action, bool enabled = true)
        {
            var item = new MenuFlyoutItem { Text = label, IsEnabled = enabled };
            item.Click += (_, _) => action();
            menu.Items.Add(item);
        }
        Item("Show in graph", () => selection.Select(iri, true));
        Item("Rename", BeginRename);
        Item("New class", () => CreateRequested?.Invoke());
        Item("Delete class", () => DeleteRequested?.Invoke(), iri != Ns.Thing && store.Entities[iri].Kind is EntityKind.Class or EntityKind.Defined);
        menu.ShowAt(tree, args.GetPosition(tree));
        args.Handled = true;
    }
}
