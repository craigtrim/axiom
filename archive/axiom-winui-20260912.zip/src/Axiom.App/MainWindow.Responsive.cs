using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace Axiom.App;

public sealed partial class MainWindow
{
    private bool hierarchyVisible = true, inspectorVisible = true, narrow;
    private double hierarchyWidth = Theme.LeftWidth, inspectorWidth = Theme.RightWidth;

    private void Reflow()
    {
        if (graph == null || root.ActualWidth <= 0)
            return;
        var nextNarrow = root.ActualWidth <= 1180;
        if (nextNarrow != narrow)
        {
            if (nextNarrow)
            {
                if (workspace.ColumnDefinitions[0].Width.Value > 0)
                    hierarchyWidth = workspace.ColumnDefinitions[0].Width.Value;
                if (workspace.ColumnDefinitions[4].Width.Value > 0)
                    inspectorWidth = workspace.ColumnDefinitions[4].Width.Value;
            }
            narrow = nextNarrow;
        }
        var showInspector = inspectorVisible && !narrow;
        workspace.ColumnDefinitions[0].Width = new(hierarchyVisible ? narrow ? 240 : hierarchyWidth : 0);
        workspace.ColumnDefinitions[1].Width = new(hierarchyVisible ? Theme.SplitterSize : 0);
        workspace.ColumnDefinitions[3].Width = new(showInspector ? Theme.SplitterSize : 0);
        workspace.ColumnDefinitions[4].Width = new(showInspector ? inspectorWidth : 0);
        hierarchy.Visibility = hierarchyVisible ? Visibility.Visible : Visibility.Collapsed;
        inspector.Visibility = showInspector ? Visibility.Visible : Visibility.Collapsed;
        foreach (var child in workspace.Children.OfType<FrameworkElement>())
        {
            var column = Grid.GetColumn(child);
            if (column is 1 or 3)
                child.Visibility = (column == 1 ? hierarchyVisible : showInspector) ? Visibility.Visible : Visibility.Collapsed;
        }
        graph.SetNarrow(narrow, root.ActualWidth <= 1024);
    }
}
