using Axiom.Core;
using Microsoft.UI.Xaml.Automation.Peers;
using Microsoft.UI.Xaml.Automation.Provider;
namespace Axiom.App;
public sealed class GraphPeer(GraphView owner) : FrameworkElementAutomationPeer(owner), ISelectionProvider
{
    private readonly Dictionary<string, NodePeer> nodes = [];
    private NodePeer Node(string iri)
    {
        if (!nodes.TryGetValue(iri, out var peer))
            nodes.Add(iri, peer = new(owner, iri, this));
        return peer;
    }
    protected override string GetClassNameCore() => "AxiomGraph";
    protected override AutomationControlType GetAutomationControlTypeCore() => AutomationControlType.List;
    protected override string GetNameCore() => $"Graph viewport, {owner.View.Nodes.Count} nodes, budget {owner.View.Budget}";
    protected override List<AutomationPeer> GetChildrenCore()
    {
        foreach (var iri in nodes.Keys.Where(i => !owner.View.Nodes.ContainsKey(i)).ToArray())
            nodes.Remove(iri);
        var children = base.GetChildrenCore()?.ToList() ?? [];
        children.AddRange(owner.View.OrderedNodes.Select(n => (AutomationPeer)Node(n.Iri)));
        return children;
    }
    protected override object GetPatternCore(PatternInterface pattern) => pattern == PatternInterface.Selection ? this : base.GetPatternCore(pattern);
    public bool CanSelectMultiple => false;
    public bool IsSelectionRequired => false;
    public IRawElementProviderSimple[] GetSelection() => owner.Selected is { } iri && owner.View.Nodes.ContainsKey(iri) ? [ProviderFromPeer(Node(iri))] : [];
    private sealed class NodePeer(GraphView graph, string iri, GraphPeer parent) : AutomationPeer, IInvokeProvider, ISelectionItemProvider
    {
        private GraphNode? Node => graph.View.Nodes.GetValueOrDefault(iri);
        protected override string GetNameCore() => Node is { } n ? $"{n.Label}, {Kinds.Label(n.Kind)}, {n.Degree} neighbours, {n.Hidden} held back" + (n.Pinned ? ", pinned" : "") : iri;
        protected override string GetClassNameCore() => "AxiomGraphNode";
        protected override string GetAutomationIdCore() => iri;
        protected override AutomationControlType GetAutomationControlTypeCore() => AutomationControlType.ListItem;
        protected override string GetLocalizedControlTypeCore() => "graph node";
        protected override Windows.Foundation.Rect GetBoundingRectangleCore() => graph.NodeBounds(iri);
        protected override Windows.Foundation.Point GetClickablePointCore()
        {
            var r = GetBoundingRectangleCore();
            return new(r.X + r.Width / 2, r.Y + r.Height / 2);
        }
        protected override List<AutomationPeer> GetChildrenCore() => [];
        protected override bool IsContentElementCore() => true;
        protected override bool IsControlElementCore() => true;
        protected override bool IsEnabledCore() => graph.IsEnabled && Node != null;
        protected override bool IsKeyboardFocusableCore() => true;
        protected override bool HasKeyboardFocusCore() => graph.Selected == iri;
        protected override bool IsOffscreenCore() => !graph.NodeVisible(iri);
        protected override bool IsPasswordCore() => false;
        protected override bool IsRequiredForFormCore() => false;
        protected override string GetAcceleratorKeyCore() => "";
        protected override string GetAccessKeyCore() => "";
        protected override string GetHelpTextCore() => "Enter expands neighbours. P pins. Delete removes from viewport.";
        protected override string GetItemStatusCore() => IsSelected ? "Selected" : "";
        protected override string GetItemTypeCore() => Node is { } n ? Kinds.Label(n.Kind) : "";
        protected override AutomationPeer? GetLabeledByCore() => null;
        protected override AutomationOrientation GetOrientationCore() => AutomationOrientation.None;
        protected override void SetFocusCore() => Select();
        protected override object? GetPatternCore(PatternInterface pattern) => pattern is PatternInterface.Invoke or PatternInterface.SelectionItem ? this : null;
        public void Invoke() => graph.Reveal(iri);
        public bool IsSelected => graph.Selected == iri;
        public IRawElementProviderSimple SelectionContainer => ProviderFromPeer(parent);
        public void AddToSelection() => Select();
        public void RemoveFromSelection()
        {
        }
        public void Select() => graph.SelectNode(iri);
    }
}
