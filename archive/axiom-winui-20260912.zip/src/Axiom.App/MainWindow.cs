using System.Diagnostics;
using Axiom.Core;
using Axiom.Fixture;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Windows.System;
namespace Axiom.App;
public sealed partial class MainWindow : Window
{
    private readonly Store store = PizzaFixture.Build();
    private readonly Selection selection;
    private readonly Grid root = Ui.Grid("auto,*,4,280,auto", "*");
    private readonly Grid workspace = Ui.Grid("*", "260,4,*,4,320");
    private readonly Grid dock = Ui.Grid("auto,*", "*");
    private readonly Grid graphHost = Ui.Grid("*", "*");
    private readonly TextBlock counts = Ui.Text("", Theme.Caption, "text-secondary");
    private readonly TextBlock selected = Ui.Text("No selection", Theme.Caption, "text-secondary");
    private readonly InfoBar toast = new() { IsOpen = false, IsClosable = true };
    private readonly DispatcherTimer toastTimer = new() { Interval = TimeSpan.FromSeconds(6) };
    private readonly HierarchyView hierarchy;
    private readonly InspectorView inspector;
    private readonly AutoSuggestBox search = Ui.Named(new AutoSuggestBox { PlaceholderText = "Search entities  (Ctrl+F)", Width = 300 }, "Search entities");
    private Button undoButton = null!, themeButton = null!, individualsTab = null!, queryTab = null!;
    private bool busy, manualTheme;
    public MainWindow()
    {
        selection = new(store);
        hierarchy = new(store, selection);
        inspector = new(store, selection);
        Title = "pizza.owl — Axiom Ontology Workbench";
        Theme.Install(Application.Current.Resources);
        root.Background = Theme.Brush("ground");
        Content = root;
        AppWindow.Resize(new Windows.Graphics.SizeInt32(1560, 1000));
        root.Loaded += (_, _) => { var area = Microsoft.UI.Windowing.DisplayArea.GetFromWindowId(AppWindow.Id, Microsoft.UI.Windowing.DisplayAreaFallback.Primary).WorkArea; var scale = root.XamlRoot.RasterizationScale; AppWindow.MoveAndResize(new Windows.Graphics.RectInt32(area.X + 24, area.Y + 24, Math.Min((int)(1400 * scale), area.Width - 48), Math.Min((int)(920 * scale), area.Height - 48))); };
        var commands = Ui.Wrap(
            Ui.Button("New class", () => NewClass()), Ui.Button("New individual", () => NewIndividual()),
            undoButton = Ui.Button("Undo", () => store.Undo(), "Undo (Ctrl+Z)"),
            Ui.Button("Save", () => Report("Serialising to OWL is not wired in this build — no file is written.")),
            search, DatasetButton(), Ui.Button("Hierarchy", () => ToggleColumn(0, Theme.LeftWidth)),
            Ui.Button("Inspector", () => ToggleColumn(4, Theme.RightWidth)),
            Ui.Button("Dock", ToggleDock), themeButton = Ui.Button("Theme", () => { manualTheme = true; Theme.Set(!Theme.Dark, root); }, "Switch colour theme"));
        commands.Padding = new(Theme.S2, Theme.S1, Theme.S2, Theme.S1);
        Ui.Add(root, commands);
        Ui.Add(workspace, hierarchy);
        Ui.Add(workspace, Splitter(true, true), 0, 1);
        Ui.Add(workspace, graphHost, 0, 2);
        Ui.Add(workspace, Splitter(true, false), 0, 3);
        Ui.Add(workspace, inspector, 0, 4);
        Ui.Add(root, workspace, 1);
        Ui.Add(root, Splitter(false, false), 2);
        var dockTabs = Ui.Wrap(Ui.Named(new TabStrip(individualsTab = Ui.Tab("Individuals", () => ShowDockTab(0)), queryTab = Ui.Tab("SPARQL", () => ShowDockTab(1))), "Dock tabs"), Ui.Button("Collapse", ToggleDock));
        Ui.Add(dock, dockTabs);
        Ui.Add(root, dock, 3);
        var status = Ui.Wrap(Ui.Text("pizza.owl", Theme.Caption), counts, selected);
        status.Padding = new(Theme.S3, 0, Theme.S3, 0);
        Ui.Add(root, status, 4);
        status.Background = Theme.Brush("surface");
        Ui.Named(status, "Application status");
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetLiveSetting(status, Microsoft.UI.Xaml.Automation.Peers.AutomationLiveSetting.Off);
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetLiveSetting(toast, Microsoft.UI.Xaml.Automation.Peers.AutomationLiveSetting.Polite);
        root.SizeChanged += (_, _) => Reflow();
        toast.VerticalAlignment = VerticalAlignment.Bottom;
        toast.Background = Theme.Brush("surface");
        toast.Margin = new(0, 0, 0, 52);
        Ui.Add(workspace, toast, 0, 2);
        toastTimer.Tick += (_, _) => { toastTimer.Stop(); toast.IsOpen = false; };
        inspector.RenameRequested += Rename;
        inspector.PageInstancesRequested += iri => graph.PageInstances(iri);
        hierarchy.Warning += message => Report(message, true);
        hierarchy.CreateRequested += NewClass;
        hierarchy.RenameRequested += Rename;
        hierarchy.DeleteRequested += DeleteClass;
        selection.Changed += iri => { selected.Text = iri is null || !selection.IsResolved ? "No selection" : Kinds.Label(store.Kind(iri)) + " · " + store.Label(iri); };
        selection.RevealRequested += iri => Reveal(iri);
        store.Changed += change =>
        {
            if (change.Regenerated || (selection.Iri is { } iri && !store.Exists(iri)))
                selection.Select(null);
            hierarchy.Render();
            inspector.Render();
            UpdateCounts();
            RefreshSurfaces(change);
        };
        WireSearch();
        root.KeyDown += GlobalKey;
        UpdateCounts();
        SetupGraph();
        SetupTable();
        SetupConsole();
        var uiSettings = new Windows.UI.ViewManagement.UISettings();
        uiSettings.TextScaleFactorChanged += (_, _) => DispatcherQueue.TryEnqueue(() =>
        {
            Theme.SetTextScale(uiSettings.TextScaleFactor);
            hierarchy.RefreshMetrics();
            individuals.Rows.RefreshMetrics();
            console.Results.RefreshMetrics();
            graph.RefreshMetrics();
            Reflow();
        });
        var foreground = uiSettings.GetColorValue(Windows.UI.ViewManagement.UIColorType.Foreground);
        Theme.Changed += () => Ui.Named(themeButton, Theme.Dark ? "Switch to light theme" : "Switch to dark theme");
        Theme.Set(foreground.R + foreground.G + foreground.B > 384, root);
        uiSettings.ColorValuesChanged += (_, _) => DispatcherQueue.TryEnqueue(() => { var next = uiSettings.GetColorValue(Windows.UI.ViewManagement.UIColorType.Foreground); Theme.Set(manualTheme ? Theme.Dark : next.R + next.G + next.B > 384, root); });
        var accessibility = new Windows.UI.ViewManagement.AccessibilitySettings();
        try
        {
            accessibility.HighContrastChanged += (_, _) => DispatcherQueue.TryEnqueue(() => Theme.Set(Theme.Dark, root));
        }
        catch (System.Runtime.InteropServices.COMException ex) when ((uint)ex.HResult == 0x80070490) {/* Unpackaged Windows 10 uses the ColorValuesChanged fallback above. */}
        selection.Select(Ns.Pizza + "Pizza");
        if (Environment.GetCommandLineArgs().Contains("--performance"))
            root.Loaded += async (_, _) => await MeasureNativePerformance();
        if (Environment.GetCommandLineArgs().Contains("--verify"))
            root.Loaded += async (_, _) => await VerifyNative();
        if (Environment.GetCommandLineArgs().Contains("--smoke"))
        {
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
            timer.Tick += (_, _) => { timer.Stop(); Close(); };
            timer.Start();
        }
    }
    partial void SetupGraph(); partial void SetupTable(); partial void SetupConsole(); partial void RefreshSurfaces(Change change); partial void Reveal(string iri); partial void ShowDockTab(int index);
    private Button DatasetButton()
    {
        var button = Ui.Button("Dataset", () => { });
        var menu = new MenuFlyout();
        foreach (var n in PizzaFixture.Sizes)
        {
            var item = new MenuFlyoutItem { Text = $"{Ns.Count(n)} pizzas · {Ns.Count(379L + 7L * n + 2L * Math.Max(24, (int)Math.Round(n / 8d)))} triples" };
            item.Click += async (_, _) => await Regenerate(n);
            menu.Items.Add(item);
        }
        button.Flyout = menu;
        return button;
    }
    private async Task Regenerate(int n)
    {
        if (busy)
            return;
        busy = true;
        Report($"Generating {Ns.Count(n)} individuals…");
        try
        {
            var watch = Stopwatch.StartNew();
            var data = await Task.Run(() => PizzaFixture.Generate(n));
            store.LoadGenerated(data.Individuals, data.Customers);
            Report($"Store rebuilt: {Ns.Count(store.TripleCount)} triples, {Ns.Count(store.IndividualCount)} individuals, in {watch.ElapsedMilliseconds} ms. The viewport still holds at most {Ns.Count(graph.View.Budget)} nodes.");
        }
        catch (Exception ex) { Report("Dataset generation failed: " + ex.Message, true); }
        finally { busy = false; }
    }
    private void UpdateCounts()
    {
        counts.Text = $"{Ns.Count(store.TripleCount)} triples · {store.ClassCount} classes · {Ns.Count(store.IndividualCount)} individuals";
        undoButton.IsEnabled = store.CanUndo;
        if (individualsTab != null)
            individualsTab.Content = $"Individuals · {Ns.Count(store.Individuals.Count)}";
    }
    private void Report(string message, bool warning = false)
    {
        toast.Message = message;
        toast.Severity = warning ? InfoBarSeverity.Warning : InfoBarSeverity.Informational;
        toast.IsOpen = true;
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(toast, message);
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetLiveSetting(toast, Microsoft.UI.Xaml.Automation.Peers.AutomationLiveSetting.Polite);
        Microsoft.UI.Xaml.Automation.Peers.FrameworkElementAutomationPeer.FromElement(toast)?.RaiseAutomationEvent(Microsoft.UI.Xaml.Automation.Peers.AutomationEvents.LiveRegionChanged);
        toastTimer.Stop();
        toastTimer.Start();
    }
    private void ToggleColumn(int index, double width)
    {
        if (index == 0)
            hierarchyVisible = !hierarchyVisible;
        else
            inspectorVisible = !inspectorVisible;
        Reflow();
    }
    private void ToggleDock()
    {
        var visible = root.RowDefinitions[3].Height.Value > 0;
        root.RowDefinitions[3].Height = new(visible ? 0 : Theme.DockHeight);
        dock.Visibility = visible ? Visibility.Collapsed : Visibility.Visible;
    }
    private Button Splitter(bool vertical, bool left)
    {
        var grip = Ui.Button("", () => { }, vertical ? (left ? "Resize hierarchy panel" : "Resize inspector panel") : "Resize bottom dock");
        grip.Padding = new(0);
        grip.Background = Theme.Brush("stroke");
        grip.MinWidth = 0;
        grip.MinHeight = 0;
        grip.HorizontalAlignment = HorizontalAlignment.Stretch;
        grip.VerticalAlignment = VerticalAlignment.Stretch;
        grip.Height = double.NaN;
        var dragging = false;
        var start = 0d;
        var extent = 0d;
        void Resize(double delta)
        {
            if (vertical)
            {
                var i = left ? 0 : 4;
                var next = Math.Clamp(extent + (left ? delta : -delta), left ? 180 : 240, left ? 520 : 560);
                workspace.ColumnDefinitions[i].Width = new(next);
                if (left && !narrow)
                    hierarchyWidth = next;
                else if (!left)
                    inspectorWidth = next;
            }
            else
                root.RowDefinitions[3].Height = new(Math.Clamp(extent - delta, 120, Math.Max(120, root.ActualHeight - 260)));
        }
        grip.PointerPressed += (_, e) => { dragging = true; var p = e.GetCurrentPoint(root).Position; start = vertical ? p.X : p.Y; extent = vertical ? workspace.ColumnDefinitions[left ? 0 : 4].Width.Value : root.RowDefinitions[3].Height.Value; grip.CapturePointer(e.Pointer); e.Handled = true; };
        grip.PointerMoved += (_, e) => { if (dragging) { var p = e.GetCurrentPoint(root).Position; Resize((vertical ? p.X : p.Y) - start); } };
        grip.PointerReleased += (_, e) => { dragging = false; grip.ReleasePointerCapture(e.Pointer); };
        grip.PointerCaptureLost += (_, _) => dragging = false;
        grip.KeyDown += (_, e) => { if (e.Key is VirtualKey.Left or VirtualKey.Right or VirtualKey.Up or VirtualKey.Down) { extent = vertical ? workspace.ColumnDefinitions[left ? 0 : 4].Width.Value : root.RowDefinitions[3].Height.Value; Resize(e.Key is VirtualKey.Right or VirtualKey.Down ? 8 : -8); e.Handled = true; } };
        return grip;
    }
    private void WireSearch()
    {
        var debounce = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(160) };
        search.TextChanged += (_, args) => { if (args.Reason == AutoSuggestionBoxTextChangeReason.UserInput) { debounce.Stop(); debounce.Start(); } };
        debounce.Tick += (_, _) => { debounce.Stop(); var q = search.Text.Trim(); search.ItemsSource = q == "" ? Array.Empty<SearchItem>() : store.Entities.Keys.Concat(store.Individuals.Select(i => i.Iri)).Concat(store.Customers.Select(c => c.Iri)).Where(i => store.Label(i).Contains(q, StringComparison.OrdinalIgnoreCase) || Ns.Shorten(i).Contains(q, StringComparison.OrdinalIgnoreCase)).Take(20).Select(i => new SearchItem(i, store.Label(i))).ToArray(); };
        search.QuerySubmitted += (_, e) => { if (e.ChosenSuggestion is SearchItem item) { selection.Select(item.Iri, true); search.Text = ""; } };
    }
    private sealed record SearchItem(string Iri, string Label)
    {
        public override string ToString() => Label + "  " + Ns.Shorten(Iri);
    }
    private void GlobalKey(object sender, KeyRoutedEventArgs e)
    {
        var ctrl = Microsoft.UI.Input.InputKeyboardSource.GetKeyStateForCurrentThread(VirtualKey.Control).HasFlag(Windows.UI.Core.CoreVirtualKeyStates.Down);
        if (ctrl && e.Key == VirtualKey.F)
        {
            search.Focus(FocusState.Keyboard);
            e.Handled = true;
            return;
        }
        if (ctrl && e.Key == VirtualKey.S)
        {
            Report("Serialising to OWL is not wired in this build — no file is written.");
            e.Handled = true;
            return;
        }
        if (e.OriginalSource is TextBox || Microsoft.UI.Xaml.Input.FocusManager.GetFocusedElement(root.XamlRoot) is TextBox or RichEditBox)
            return;
        if (ctrl && e.Key == VirtualKey.Z)
        {
            store.Undo();
            e.Handled = true;
        }
        else if (e.Key == VirtualKey.F2)
        {
            Rename();
            e.Handled = true;
        }
        else if (e.Key == VirtualKey.Delete)
        {
            DeleteClass();
            e.Handled = true;
        }
    }
    private void Rename()
    {
        if (selection.Iri is not { } iri || !store.Entities.TryGetValue(iri, out var entity))
        {
            Report("Select a class or property in the hierarchy to rename.", true);
            return;
        }
        hierarchy.BeginRename();
    }
    private void DeleteClass()
    {
        if (selection.Iri is not { } iri || !store.Entities.TryGetValue(iri, out var e))
            return;
        if (iri == Ns.Thing)
        {
            Report("owl:Thing is the ontology root and cannot be deleted.", true);
            return;
        }
        var text = Ui.Field("Deletion consequences");
        text.Text = $"Reparent {e.Children.Count} direct subclasses. Instances keep their type assertion. This can be undone.";
        text.IsReadOnly = true;
        text.Height = Theme.RowHeight * 2;
        text.TextWrapping = TextWrapping.Wrap;
        Form("Delete " + e.Name + "?", [new("Consequences", text)], () => store.DeleteClass(iri));
    }
}
