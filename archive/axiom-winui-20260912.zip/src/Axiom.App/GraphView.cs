using Axiom.Core;
using Microsoft.Graphics.Canvas;
using Microsoft.Graphics.Canvas.UI.Xaml;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Windows.System;
namespace Axiom.App;
public sealed partial class GraphView : UserControl, IDisposable
{
    public Viewport View
    {
        get;
    }
    public Layouts Layout
    {
        get;
    }
    private readonly Store store;
    private readonly Selection selection;
    private readonly Action<string, bool> report;
    private readonly Window owner;
    private readonly Grid root = Ui.Grid("auto,*,auto", "*");
    private readonly GraphCanvas canvas = new() { IsTabStop = false };
    private readonly CanvasControl map = new() { Width = 180, Height = 120, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Bottom, Margin = new(12) };
    private readonly TextBlock status = Ui.Text("", 12, "text-secondary");
    private readonly TextBlock empty = Ui.Text("The viewport is empty. Search for an entity or choose Show in graph.", 14, "text-secondary");
    private readonly TextBlock tooltip = Ui.Text("", 12);
    private readonly Border tooltipBox;
    private readonly Slider budget = Ui.Named(new Slider { Minimum = 100, Maximum = 3000, StepFrequency = 100, Value = 1000, Width = 140 }, "Viewport budget");
    private readonly ComboBox modes = Ui.Named(new ComboBox { ItemsSource = new[] { "Auto layout", "Force-directed", "Hierarchy", "Radial", "Cluster grid" }, SelectedIndex = 0, Width = 144 }, "Graph layout");
    private readonly ToggleButton freeze = Ui.Named(new ToggleButton { Content = "Freeze" }, "Freeze force simulation");
    private readonly SemaphoreSlim gate = new(1, 1);
    private readonly Windows.UI.ViewManagement.UISettings settings = new();
    private readonly CanvasControl legend = new() { Width = 244, Height = 104, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Bottom, Margin = new(12), IsHitTestVisible = false };
    private readonly ProgressBar occupancy = Ui.Named(new ProgressBar { Minimum = 0, Maximum = 100, Width = 88, Height = 4 }, "Viewport occupancy");
    private readonly HitIndex hitIndex = new();
    private bool hitDirty = true;
    private readonly TextBlock meter = Ui.Text("", 12);
    private readonly FrameGuard frameGuard = new();
    private TextCache? textCache;
    private Camera camera = new(0, 0, 1);
    private GraphNode? drag;
    private bool dragging, panning, moved, layingOut, disposed, budgetUpdate;
    private Windows.Foundation.Point last, press;
    private string? hovered;
    public bool ReducedMotion => !settings.AnimationsEnabled;
    public GraphView(Store store, Selection selection, Window owner, Action<string, bool> report)
    {
        this.store = store;
        this.selection = selection;
        this.owner = owner;
        this.report = report;
        View = new(store);
        Layout = new(View, store);
        IsTabStop = true;
        Ui.Named(this, "Graph viewport");
        Content = root;
        frameGuard.Failed += ex => { measurement?.CompletionFailure(ex); freeze.IsChecked = true; report("Graph rendering paused: " + ex.Message + ". Choose Relayout to retry.", true); };
        root.Background = Theme.Brush("canvas");
        var export = Ui.Button("Export", () => { });
        var menu = new MenuFlyout();
        foreach (var (label, kind) in new[] { ("PNG · 2×", "png2"), ("PNG · 3×", "png3"), ("SVG · vector", "svg"), ("Copy image", "clipboard") })
        {
            var item = new MenuFlyoutItem { Text = label };
            item.Click += async (_, _) => await Export(kind);
            menu.Items.Add(item);
        }
        export.Flyout = menu;
        var toolbar = Ui.Wrap(Ui.Button("Fit", Fit, "Fit graph (F)"), Ui.Button("Relayout", () => Run(() => { }, true, true), "Relayout graph (L)"), modes, freeze, export, Ui.Button("Clear", () => Run(View.Clear, true, true)));
        toolbar.Padding = new(8, 4, 8, 4);
        Ui.Add(root, toolbar);
        var surface = new Grid();
        surface.Children.Add(canvas);
        surface.Children.Add(empty);
        empty.HorizontalAlignment = HorizontalAlignment.Center;
        empty.TextWrapping = TextWrapping.Wrap;
        empty.Margin = new(32);
        surface.Children.Add(map);
        surface.Children.Add(legend);
        Ui.Named(legend, "Legend: class square, defined class square with plus, individual circle, object property diamond, data property hexagon; dot means pinned; +n means neighbours held back.");
        legend.Draw += DrawLegend;
        tooltipBox = new Border { Child = tooltip, Padding = new(8), Background = Theme.Brush("surface"), BorderBrush = Theme.Brush("stroke-strong"), BorderThickness = new(1), CornerRadius = new(4), HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top, Visibility = Visibility.Collapsed, IsHitTestVisible = false };
        surface.Children.Add(tooltipBox);
        Ui.Add(root, surface, 1);
        var eviction = Ui.Named(new ComboBox { ItemsSource = new[] { "Distant, low degree", "Least recently used", "Refuse new nodes" }, SelectedIndex = 0, Width = 160 }, "Eviction policy");
        eviction.SelectionChanged += (_, _) => View.EvictionMode = new[] { "degree", "lru", "refuse" }[eviction.SelectedIndex];
        var bottom = new StackPanel { Spacing = 4, Padding = new(8, 4, 8, 4) };
        bottom.Children.Add(Ui.Wrap(Ui.Text("Budget", 12), budget, meter, occupancy, eviction));
        bottom.Children.Add(status);
        status.TextWrapping = TextWrapping.Wrap;
        Ui.Add(root, bottom, 2);
        budget.ValueChanged += (_, _) => { if (budgetUpdate) return; Run(() => { var result = View.SetBudget((int)budget.Value); budgetUpdate = true; budget.Value = View.Budget; budgetUpdate = false; report(result.Message, !result.Accepted); }, false); };
        modes.SelectionChanged += (_, _) => { Layout.Choice = new[] { "auto", "force", "hierarchy", "radial", "grid" }[Math.Max(0, modes.SelectedIndex)]; Run(() => { }, true, true); };
        freeze.Checked += (_, _) => Invalidate();
        freeze.Unchecked += (_, _) => Invalidate();
        canvas.CreateResources += (_, _) => { textCache?.Dispose(); textCache = new(canvas.Device); };
        canvas.Draw += Draw;
        map.Draw += DrawMap;
        canvas.SizeChanged += (_, _) => { if (canvas.ActualWidth > 0) Fit(); };
        canvas.PointerPressed += Pressed;
        canvas.PointerMoved += Moved;
        canvas.PointerReleased += Released;
        canvas.PointerCaptureLost += (_, _) => EndDrag();
        canvas.PointerExited += (_, _) => { if (!dragging) { hovered = null; tooltipBox.Visibility = Visibility.Collapsed; Invalidate(); } };
        canvas.PointerWheelChanged += (_, e) => { if (layingOut) return; var p = e.GetCurrentPoint(canvas); var world = camera.World(p.Position.X, p.Position.Y); var k = Math.Clamp(camera.Zoom * Math.Exp(p.Properties.MouseWheelDelta * .001), .05, 4); camera = new(p.Position.X - world.X * k, p.Position.Y - world.Y * k, k); e.Handled = true; Invalidate(); };
        canvas.DoubleTapped += (_, e) => { if (Hit(e.GetPosition(canvas)) is { } n) Run(() => ReportAdmission(View.Expand(n.Iri)), false); e.Handled = true; };
        canvas.RightTapped += (_, e) => { var n = Hit(e.GetPosition(canvas)); if (n != null) { selection.Select(n.Iri); Context(n).ShowAt(canvas, e.GetPosition(canvas)); } e.Handled = true; };
        map.PointerPressed += (_, e) => { var p = e.GetCurrentPoint(map).Position; var mc = Camera.Fit(View, 180, 120); var world = mc.World(p.X, p.Y); camera = camera with { X = canvas.ActualWidth / 2 - world.X * camera.Zoom, Y = canvas.ActualHeight / 2 - world.Y * camera.Zoom }; e.Handled = true; Invalidate(); };
        KeyDown += GraphKey;
        selection.Changed += Select;
        Theme.Changed += PaletteChanged;
        RefreshMetrics();
        canvas.PreparingDraw += Frame;
        canvas.CanDraw = () => !layingOut && !disposed && textCache != null;
        canvas.Failed += ex => frameGuard.Run(() => throw ex);
        Loaded += (_, _) => { if (View.Nodes.Count == 0) Seed([Ns.Pizza + "Pizza"], true, true); };
        Update();
    }
    protected override Microsoft.UI.Xaml.Automation.Peers.AutomationPeer OnCreateAutomationPeer() => new GraphPeer(this);
    internal bool NodeVisible(string iri)
    {
        if (!View.Nodes.TryGetValue(iri, out var n))
            return false;
        var p = camera.Screen(n.X, n.Y);
        var r = n.Radius * camera.Zoom;
        return p.X + r >= 0 && p.Y + r >= 0 && p.X - r <= canvas.ActualWidth && p.Y - r <= canvas.ActualHeight;
    }
    internal string? Selected => selection.Iri;
    internal void SelectNode(string iri)
    {
        if (!NodeVisible(iri) && View.Nodes.TryGetValue(iri, out var n))
            camera = camera with
            {
                X = canvas.ActualWidth / 2 - n.X * camera.Zoom,
                Y = canvas.ActualHeight / 2 - n.Y * camera.Zoom
            };
        selection.Select(iri);
        Focus(FocusState.Keyboard);
        Invalidate();
    }
    internal Windows.Foundation.Rect NodeBounds(string iri)
    {
        if (!View.Nodes.TryGetValue(iri, out var n))
            return new();
        var p = camera.Screen(n.X, n.Y);
        var bounds = new Microsoft.UI.Xaml.Automation.Peers.FrameworkElementAutomationPeer(canvas).GetBoundingRectangle();
        var scale = XamlRoot?.RasterizationScale ?? 1;
        return new(bounds.X + (p.X - n.Radius * camera.Zoom) * scale, bounds.Y + (p.Y - n.Radius * camera.Zoom) * scale, Math.Max(1, n.Radius * camera.Zoom * 2 * scale), Math.Max(1, n.Radius * camera.Zoom * 2 * scale));
    }
    private void Select(string? iri)
    {
        if (iri == null || View.Nodes.ContainsKey(iri))
            View.Selected = iri;
        Invalidate();
    }
    public void Seed(IEnumerable<string> iris, bool replace = true, bool expand = true)
    {
        var copy = iris.ToArray();
        Run(() => ReportAdmission(View.Seed(copy, replace, expand)), true, true);
    }
    public void PageInstances(string iri)
    {
        Run(() => { var total = store.InstanceCount(iri); if (!View.Nodes.ContainsKey(iri)) View.Seed([iri], false, false); if (!View.Nodes.TryGetValue(iri, out var seed)) return; var result = View.Admit(store.InstanceIris(iri), 1, seed); var message = $"Paged {Ns.Count(result.Added)} of {Ns.Count(total)} instances into the view" + (result.Evicted > 0 ? $", evicting {Ns.Count(result.Evicted)}" : "") + (result.Refused > 0 ? $". {Ns.Count(result.Refused)} stayed out — the budget is {Ns.Count(View.Budget)}" : "") + "."; report(message, result.Refused > 0); }, false, true);
    }
    public void Reveal(string iri)
    {
        Run(() => { if (!View.Nodes.ContainsKey(iri)) ReportAdmission(View.Seed([iri], false, true)); View.Selected = iri; }, false, true);
    }
    public void Refresh(Change change)
    {
        Run(() => { if (change.Regenerated) View.Clear(); else View.Refresh(); }, false, change.Regenerated);
    }
    public async void Run(Action action, bool fresh = false, bool fit = false)
    {
        await gate.WaitAsync();
        if (disposed)
        {
            gate.Release();
            return;
        }
        try
        {
            layingOut = true;
            IsEnabled = false;
            action();
            hitDirty = true;
            var reduced = ReducedMotion;
            if (fresh || Layout.NeedsLayout)
            {
                if (Layout.Choose() == "force")
                    await Task.Run(() => Layout.Run(fresh, reduced));
                else
                    Layout.Run(fresh, reduced);
            } // deterministic layout, no Store access during frames
            if (fit)
                Fit();
            Update();
        }
        catch (Exception ex) { report("Graph operation failed: " + ex.Message, true); }
        finally { layingOut = false; IsEnabled = true; gate.Release(); Invalidate(); }
    }
    private void ReportAdmission(Admission a) => report(a.Report(View.Budget), a.Refused > 0);
    public void Fit()
    {
        camera = Camera.Fit(View, Math.Max(100, canvas.ActualWidth), Math.Max(100, canvas.ActualHeight));
        Invalidate();
    }
    private void Update()
    {
        meter.Text = $"{Ns.Count(View.Nodes.Count)}/{Ns.Count(View.Budget)}";
        status.Text = $"{Layouts.Name(Layout.Resolved)}{(Layout.Choice == "auto" ? " (auto)" : "")} · {Ns.Count(View.Nodes.Count)} nodes · {Ns.Count(View.Edges.Count)} relationships · {Ns.Count(View.Hidden)} held back";
        occupancy.Value = View.Nodes.Count * 100d / View.Budget;
        occupancy.Foreground = Theme.Brush(occupancy.Value >= 98 ? "danger" : occupancy.Value >= 75 ? "warn" : "accent");
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetItemStatus(occupancy, occupancy.Value >= 98 ? "Full" : occupancy.Value >= 75 ? "Near capacity" : "Available");
        freeze.IsEnabled = Layout.Resolved == "force" && !ReducedMotion;
        ToolTipService.SetToolTip(freeze, Layout.Resolved != "force" ? "Freeze is available only for the force-directed layout." : ReducedMotion ? "Animations are disabled in Windows settings." : "Pause or resume the force simulation.");
        empty.Visibility = View.Nodes.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        map.Visibility = View.Nodes.Count == 0 ? Visibility.Collapsed : Visibility.Visible;
    }
    private void Invalidate()
    {
        if (disposed)
            return;
        canvas.Invalidate();
        map.Invalidate();
    }
    public void RefreshMetrics()
    {
        legend.Width = 244 * Theme.TextScale;
        legend.Height = 104 * Theme.TextScale;
        PaletteChanged();
    }
    public void SetNarrow(bool narrow, bool veryNarrow)
    {
        legend.Visibility = narrow ? Visibility.Collapsed : Visibility.Visible;
        budget.Width = veryNarrow ? 108 : 140;
    }
    private void PaletteChanged()
    {
        Invalidate();
        legend.Invalidate();
    }
    private void Frame(object? sender, object e)
    {
        if (measurement != null)
        {
            measurement.Advance();
            return;
        }
        if (!disposed && !layingOut && Layout.NeedsLayout)
        {
            Run(() => { });
            return;
        }
        if (disposed || layingOut || freeze.IsChecked == true || ReducedMotion || Layout.Resolved != "force" || View.Alpha < .004)
            return;
        frameGuard.Run(() => Layout.Force.Step());
        hitDirty = true;
        Invalidate();
    }
    private void Draw(GraphCanvas sender, GraphDrawEventArgs args)
    {
        if (layingOut || disposed || textCache == null)
            return;
        void Render() => SceneRenderer.Render(new Win2DDraw(args.DrawingSession, textCache), View, Layout, camera, canvas.ActualWidth, canvas.ActualHeight, Theme.Dark, hovered, textScale: Theme.TextScale);
        frameGuard.Run(() => { if (measurement is { } active) active.Draw(Render, false); else Render(); });
    }
    private void DrawLegend(CanvasControl sender, CanvasDrawEventArgs args)
    {
        if (textCache == null || disposed)
            return;
        args.DrawingSession.Transform = System.Numerics.Matrix3x2.CreateScale((float)Theme.TextScale);
        var d = new Win2DDraw(args.DrawingSession, textCache);
        uint C(string key) => DesignTokens.Colour(key, Theme.Dark);
        d.Rectangle(new(0, 0, 244, 104), C("surface"), 4);
        d.Rectangle(new(.5, .5, 243, 103), C("stroke-strong"), 4, 1);
        int i = 0;
        foreach (var kind in Enum.GetValues<EntityKind>())
        {
            double x = 10 + (i % 2) * 120, y = 14 + (i / 2) * 21;
            SceneRenderer.Shape(d, kind, new(x + 6, y), 6, C(SceneRenderer.KindToken(kind)));
            if (kind == EntityKind.Defined)
            {
                d.Path([new(x + 3, y), new(x + 9, y)], C("canvas"), 1);
                d.Path([new(x + 6, y - 3), new(x + 6, y + 3)], C("canvas"), 1);
            }
            d.Text(Kinds.Label(kind), new(x + 18, y - 8), C("text"), 10.5);
            i++;
        }
        d.Circle(new(136, 56), 3.5, C("warn"));
        d.Text("Pinned", new(148, 48), C("text"), 10.5);
        d.Text("+n = neighbours held back", new(10, 79), C("text-secondary"), 11);
    }
    private void DrawMap(CanvasControl sender, CanvasDrawEventArgs args)
    {
        if (measurement is { } active)
            active.Draw(() => DrawMapCore(args), true);
        else
            DrawMapCore(args);
    }
    private void DrawMapCore(CanvasDrawEventArgs args)
    {
        if (layingOut || disposed || textCache == null)
            return;
        var d = new Win2DDraw(args.DrawingSession, textCache);
        var mc = Camera.Fit(View, 180, 120);
        d.Rectangle(new(0, 0, 180, 120), DesignTokens.Colour("surface", Theme.Dark), 4);
        d.BeginNodes();
        foreach (var n in View.OrderedNodes)
            d.Circle(mc.Screen(n.X, n.Y), View.Focus.Contains(n.Iri) ? 2.5 : 1.5, DesignTokens.Colour(SceneRenderer.KindToken(n.Kind), Theme.Dark));
        d.EndNodes();
        var a = camera.World(0, 0);
        var b = camera.World(canvas.ActualWidth, canvas.ActualHeight);
        var p = mc.Screen(a.X, a.Y);
        d.Rectangle(new(p.X, p.Y, (b.X - a.X) * mc.Zoom, (b.Y - a.Y) * mc.Zoom), DesignTokens.Colour("accent", Theme.Dark), 0, 1);
        d.Rectangle(new(.5, .5, 179, 119), DesignTokens.Colour("stroke-strong", Theme.Dark), 4, 1);
    }
    private GraphNode? Hit(Windows.Foundation.Point p)
    {
        if (layingOut)
            return null;
        var w = camera.World(p.X, p.Y);
        if (hitDirty)
        {
            hitIndex.Rebuild(View.OrderedNodes);
            hitDirty = false;
        }
        return hitIndex.Hit(w, 6 / camera.Zoom);
    }
    private void Pressed(object sender, PointerRoutedEventArgs e)
    {
        var p = e.GetCurrentPoint(canvas);
        if (!p.Properties.IsLeftButtonPressed || layingOut)
            return;
        Focus(FocusState.Pointer);
        drag = Hit(p.Position);
        last = press = p.Position;
        moved = false;
        dragging = true;
        panning = drag == null;
        if (drag != null)
        {
            drag.Dragging = true;
            selection.Select(drag.Iri);
        }
        canvas.CapturePointer(e.Pointer);
        e.Handled = true;
    }
    private void Moved(object sender, PointerRoutedEventArgs e)
    {
        var p = e.GetCurrentPoint(canvas).Position;
        if (dragging)
        {
            if (Math.Abs(p.X - press.X) + Math.Abs(p.Y - press.Y) > 3)
                moved = true;
            if (panning)
                camera = camera with
                {
                    X = camera.X + p.X - last.X,
                    Y = camera.Y + p.Y - last.Y
                };
            else if (drag != null)
            {
                var w = camera.World(p.X, p.Y);
                drag.X = w.X;
                drag.Y = w.Y;
                hitDirty = true;
                drag.Vx = drag.Vy = 0;
                View.Alpha = Math.Max(.35, View.Alpha);
            }
            last = p;
            Invalidate();
            return;
        }
        var hit = Hit(p);
        if (hovered == hit?.Iri)
            return;
        hovered = hit?.Iri;
        tooltipBox.Visibility = hit == null ? Visibility.Collapsed : Visibility.Visible;
        if (hit != null)
        {
            tooltip.Text = $"{hit.Label}\n{Kinds.Label(hit.Kind)} · {Ns.Shorten(hit.Iri)}\n{Ns.Count(hit.Degree)} neighbours · {hit.Hidden} held back";
            tooltipBox.Margin = new(Math.Clamp(p.X + 14, 4, Math.Max(4, canvas.ActualWidth - 280)), Math.Clamp(p.Y + 14, 4, Math.Max(4, canvas.ActualHeight - 85)), 0, 0);
        }
        Invalidate();
    }
    private void Released(object sender, PointerRoutedEventArgs e)
    {
        if (dragging && !moved && drag == null)
            selection.Select(null);
        EndDrag();
        canvas.ReleasePointerCapture(e.Pointer);
        e.Handled = true;
    }
    private void EndDrag()
    {
        if (drag != null)
            drag.Dragging = false;
        drag = null;
        dragging = panning = false;
        Invalidate();
    }
    private MenuFlyout Context(GraphNode original)
    {
        var menu = new MenuFlyout();
        menu.Items.Add(new MenuFlyoutItem { Text = original.Label, IsEnabled = false });
        void Add(string name, Action<GraphNode> action, bool enabled = true)
        {
            var item = new MenuFlyoutItem { Text = name, IsEnabled = enabled };
            item.Click += (_, _) => Run(() => { if (View.Nodes.TryGetValue(original.Iri, out var current)) action(current); }, false);
            menu.Items.Add(item);
        }
        Add("Expand neighbours", n => ReportAdmission(View.Expand(n.Iri)), original.Hidden > 0);
        Add("Expand 20 only", n => ReportAdmission(View.Expand(n.Iri, 20)), original.Hidden > 0);
        Add("Collapse neighbourhood", n => report($"Collapsed {View.Collapse(n.Iri)} leaf neighbours of {n.Label}.", false));
        menu.Items.Add(new MenuFlyoutSeparator());
        Add("Focus here · reseeds view", n => ReportAdmission(View.Seed([n.Iri])));
        Add(original.Pinned ? "Unpin" : "Pin — never evict", n => { n.Pinned = !n.Pinned; report(n.Pinned ? $"{n.Label} pinned — it will not be evicted." : $"{n.Label} unpinned.", false); });
        Add("Remove from view · Del", n => View.Remove(n.Iri));
        return menu;
    }
    private void GraphKey(object sender, KeyRoutedEventArgs e)
    {
        if (e.OriginalSource is TextBox or ComboBox or Slider)
            return;
        var ctrl = Microsoft.UI.Input.InputKeyboardSource.GetKeyStateForCurrentThread(VirtualKey.Control).HasFlag(Windows.UI.Core.CoreVirtualKeyStates.Down);
        if (ctrl)
            return;
        if (e.Key == VirtualKey.F)
            Fit();
        else if (e.Key == VirtualKey.L)
            Run(() => { }, true, true);
        else if (e.Key == VirtualKey.Space)
        {
            if (freeze.IsEnabled)
                freeze.IsChecked = freeze.IsChecked != true;
        }
        else if (e.Key == VirtualKey.Enter && selection.Iri is { } iri)
            Run(() => ReportAdmission(View.Expand(iri)));
        else if (e.Key is VirtualKey.Delete or VirtualKey.Back && selection.Iri is { } remove)
            Run(() => View.Remove(remove));
        else if (e.Key == VirtualKey.P && selection.Iri is { } pin && View.Nodes.TryGetValue(pin, out var n))
            Run(() => n.Pinned = !n.Pinned);
        else if (e.Key is VirtualKey.Left or VirtualKey.Right or VirtualKey.Up or VirtualKey.Down)
        {
            var nodes = View.OrderedNodes.ToArray();
            if (nodes.Length > 0)
            {
                var index = Array.FindIndex(nodes, n => n.Iri == selection.Iri);
                index = (index + (e.Key is VirtualKey.Left or VirtualKey.Up ? -1 : 1) + nodes.Length) % nodes.Length;
                SelectNode(nodes[index].Iri);
            }
        }
        else if (e.Key == VirtualKey.Application && selection.Iri is { } key && View.Nodes.TryGetValue(key, out var selectedNode))
            Context(selectedNode).ShowAt(this);
        else
            return;
        e.Handled = true;
        Invalidate();
    }
    private async Task Export(string kind)
    {
        if (View.Nodes.Count == 0)
        {
            report("The viewport is empty. Add some entities before exporting.", true);
            return;
        }
        await gate.WaitAsync();
        try
        {
            layingOut = true;
            await GraphExport.Save(owner, View, Layout, canvas.Device, textCache!, kind, Theme.Dark, report);
        }
        catch (Exception ex) { report("Export failed: " + ex.Message, true); }
        finally { layingOut = false; gate.Release(); Invalidate(); }
    }
    public void Dispose()
    {
        disposed = true;
        canvas.PreparingDraw -= Frame;
        Theme.Changed -= PaletteChanged;
        selection.Changed -= Select;
        textCache?.Dispose();
        canvas.Dispose();
        map.RemoveFromVisualTree();
        legend.RemoveFromVisualTree();
    }
}
