using System.Diagnostics;
using Axiom.Core;
namespace Axiom.App;
public sealed class ProfileDraw(IDraw draw) : IDraw
{
    public void Line(PointD p, PointD q, uint colour, double stroke = 1, bool dashed = false)
    {
        var t = Stopwatch.GetTimestamp();
        draw.Line(p, q, colour, stroke, dashed);
        Add(dashed ? "Dashed line" : "Solid line", t);
    }
    public void Arrow(PointD tip, double ux, double uy, uint colour)
    {
        var t = Stopwatch.GetTimestamp();
        draw.Arrow(tip, ux, uy, colour);
        Add("Arrow", t);
    }
    public void BeginBadges() => draw.BeginBadges();
    public void EndBadges() => draw.EndBadges();
    public void Badge(string text, PointD anchor, uint surface, uint stroke, uint foreground, double scale = 1)
    {
        var t = Stopwatch.GetTimestamp();
        draw.Badge(text, anchor, surface, stroke, foreground, scale);
        Add("Badge", t);
    }
    public void BeginLabels() => draw.BeginLabels(); public void EndLabels()
    {
        var t = Stopwatch.GetTimestamp();
        draw.EndLabels();
        Add("Label batch", t);
    }
    public void BeginNodes() => draw.BeginNodes(); public void EndNodes()
    {
        var t = Stopwatch.GetTimestamp();
        draw.EndNodes();
        Add("Node batch", t);
    }
    public void BeginPaths() => draw.BeginPaths(); public void EndPaths()
    {
        var t = Stopwatch.GetTimestamp();
        draw.EndPaths();
        Add("Batched geometry", t);
    }
    public void Dots(double step, double x, double y, double width, double height, uint colour)
    {
        var t = Stopwatch.GetTimestamp();
        draw.Dots(step, x, y, width, height, colour);
        Add("Dot grid", t);
    }
    public Dictionary<string, (int Calls, long Ticks)> Samples { get; } = [];
    private void Add(string key, long start)
    {
        var old = Samples.GetValueOrDefault(key);
        Samples[key] = (old.Calls + 1, old.Ticks + Stopwatch.GetTimestamp() - start);
    }
    public double Measure(string text, double size, bool bold = false, bool mono = false)
    {
        var t = Stopwatch.GetTimestamp();
        var result = draw.Measure(text, size, bold, mono);
        Add("Measure", t);
        return result;
    }
    public void Rectangle(RectD r, uint c, double radius = 0, double stroke = 0)
    {
        var t = Stopwatch.GetTimestamp();
        draw.Rectangle(r, c, radius, stroke);
        Add("Rectangle", t);
    }
    public void Circle(PointD p, double r, uint c, double stroke = 0)
    {
        var t = Stopwatch.GetTimestamp();
        draw.Circle(p, r, c, stroke);
        Add("Circle", t);
    }
    public void Path(PointD[] ps, uint c, double stroke = 1, bool closed = false, bool fill = false, bool dashed = false, PointD? quadratic = null)
    {
        var t = Stopwatch.GetTimestamp();
        draw.Path(ps, c, stroke, closed, fill, dashed, quadratic);
        Add(ps.Length == 2 && quadratic == null ? (dashed ? "Dashed line" : "Solid line") : ps.Length == 3 ? "Arrow" : "Other path", t);
    }
    public void Text(string text, PointD p, uint c, double size, bool bold = false, bool mono = false, bool centred = false, uint? halo = null)
    {
        var t = Stopwatch.GetTimestamp();
        draw.Text(text, p, c, size, bold, mono, centred, halo);
        Add(halo.HasValue ? "Text halo" : "Text", t);
    }
}
