using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Automation.Peers;
using Microsoft.UI.Xaml.Automation.Provider;

namespace Axiom.App;

public sealed class GridPeer(VirtualGrid grid) : FrameworkElementAutomationPeer(grid), IGridProvider, ITableProvider, ISelectionProvider
{
    private readonly Dictionary<(int Row, int Column), CellPeer> cells = [];
    private readonly Dictionary<int, RowPeer> rows = [];
    private CellPeer Cell(int row, int column)
    {
        if (cells.Count > 4096)
            TrimCells();
        if (!cells.TryGetValue((row, column), out var peer))
            cells.Add((row, column), peer = new(grid, row, column, this));
        return peer;
    }
    private RowPeer Row(int index)
    {
        if (!rows.TryGetValue(index, out var peer))
            rows.Add(index, peer = new(grid, index, this));
        return peer;
    }
    private void TrimCells()
    {
        foreach (var key in cells.Keys.Where(k => k.Row < grid.FirstRealized || k.Row >= grid.FirstRealized + grid.RealizedRows || k.Column >= ColumnCount).ToArray())
            cells.Remove(key);
        foreach (var key in rows.Keys.Where(r => r < grid.FirstRealized || r >= grid.FirstRealized + grid.RealizedRows).ToArray())
            rows.Remove(key);
    }
    protected override string GetClassNameCore() => "AxiomVirtualGrid";
    protected override string GetNameCore() => AutomationProperties.GetName(grid);
    protected override AutomationControlType GetAutomationControlTypeCore() => AutomationControlType.DataGrid;
    protected override object GetPatternCore(PatternInterface pattern) => pattern is PatternInterface.Grid or PatternInterface.Table or PatternInterface.Selection ? this : pattern == PatternInterface.Scroll ? grid.AutomationScroll()! : base.GetPatternCore(pattern);
    protected override List<AutomationPeer> GetChildrenCore()
    {
        TrimCells();
        var result = new List<AutomationPeer> { grid.AutomationHeaderRow() };
        for (var row = grid.FirstRealized; row < Math.Min(RowCount, grid.FirstRealized + grid.RealizedRows); row++)
            result.Add(Row(row));
        return result;
    }
    public void AnnounceCell(int row, int column) => RaiseNotificationEvent(AutomationNotificationKind.Other, AutomationNotificationProcessing.MostRecent, Cell(row, column).GetName(), "GridNavigation");
    protected override object GetFocusedElementCore() => grid.CurrentEditableCell is { } address ? Cell(address.Row, address.Column) : base.GetFocusedElementCore();
    public int RowCount => grid.AutomationRowCount;
    public int ColumnCount => grid.AutomationColumnCount;
    public bool CanSelectMultiple => false;
    public bool IsSelectionRequired => false;
    public RowOrColumnMajor RowOrColumnMajor => RowOrColumnMajor.RowMajor;
    public IRawElementProviderSimple[] GetColumnHeaders() => grid.AutomationHeaders().Select(ProviderFromPeer).ToArray();
    public IRawElementProviderSimple[] GetRowHeaders() => [];
    public IRawElementProviderSimple[] GetSelection() => grid.AutomationSelectedRows().Select(r => ProviderFromPeer(Row(r))).ToArray();
    public IRawElementProviderSimple GetItem(int row, int column)
    {
        if (row < 0 || row >= RowCount || column < 0 || column >= ColumnCount)
            throw new ArgumentOutOfRangeException();
        return ProviderFromPeer(Cell(row, column));
    }
    private abstract class EntryPeer : AutomationPeer
    {
        protected abstract VirtualGrid Grid
        {
            get;
        }
        protected override bool IsContentElementCore() => true;
        protected override bool IsControlElementCore() => true;
        protected override bool IsEnabledCore() => Grid.IsEnabled;
        protected override bool IsPasswordCore() => false;
        protected override bool IsRequiredForFormCore() => false;
        protected override string GetAcceleratorKeyCore() => "";
        protected override string GetAccessKeyCore() => "";
        protected override AutomationPeer? GetLabeledByCore() => null;
        protected override AutomationOrientation GetOrientationCore() => AutomationOrientation.None;
        protected override Windows.Foundation.Point GetClickablePointCore()
        {
            var bounds = GetBoundingRectangleCore();
            return new(bounds.X + bounds.Width / 2, bounds.Y + bounds.Height / 2);
        }
    }
    private sealed class RowPeer(VirtualGrid grid, int row, GridPeer parent) : EntryPeer, ISelectionItemProvider
    {
        protected override VirtualGrid Grid => grid;
        protected override string GetClassNameCore() => "AxiomGridRow";
        protected override string GetNameCore() => $"Row {row + 1}";
        protected override string GetAutomationIdCore() => $"row-{row}";
        protected override string GetLocalizedControlTypeCore() => "row";
        protected override AutomationControlType GetAutomationControlTypeCore() => AutomationControlType.DataItem;
        protected override Windows.Foundation.Rect GetBoundingRectangleCore()
        {
            var first = grid.AutomationBounds(row, 0);
            var last = grid.AutomationBounds(row, parent.ColumnCount - 1);
            return new(first.X, first.Y, last.Right - first.X, first.Height);
        }
        protected override List<AutomationPeer> GetChildrenCore() => Enumerable.Range(0, parent.ColumnCount).Select(c => (AutomationPeer)parent.Cell(row, c)).ToList();
        protected override bool IsKeyboardFocusableCore() => false;
        protected override bool HasKeyboardFocusCore() => false;
        protected override bool IsOffscreenCore() => grid.AutomationOffscreen(row, 0, true);
        protected override string GetHelpTextCore() => "";
        protected override string GetItemStatusCore() => IsSelected ? "Selected" : "";
        protected override string GetItemTypeCore() => "row";
        protected override void SetFocusCore() => grid.AutomationRealize(row, 0);
        protected override object? GetPatternCore(PatternInterface pattern) => pattern == PatternInterface.SelectionItem ? this : null;
        public bool IsSelected => grid.AutomationSelected(row);
        public IRawElementProviderSimple SelectionContainer => ProviderFromPeer(parent);
        public void Select() => grid.AutomationSelectRow(row);
        public void AddToSelection() => Select();
        public void RemoveFromSelection()
        {
            if (IsSelected)
                grid.AutomationClearSelection();
        }
    }
    private sealed class CellPeer(VirtualGrid grid, int row, int column, GridPeer parent) : EntryPeer, IGridItemProvider, ITableItemProvider, IValueProvider, IInvokeProvider, IVirtualizedItemProvider
    {
        protected override VirtualGrid Grid => grid;
        protected override string GetClassNameCore() => "AxiomGridCell";
        protected override string GetNameCore() => IsReadOnly ? Value : grid.AutomationHeader(column) + ": " + Value + ", editable";
        protected override string GetAutomationIdCore() => $"row-{row}-column-{column}";
        protected override AutomationControlType GetAutomationControlTypeCore() => AutomationControlType.DataItem;
        protected override string GetLocalizedControlTypeCore() => "table cell";
        protected override Windows.Foundation.Rect GetBoundingRectangleCore() => grid.AutomationBounds(row, column);
        protected override List<AutomationPeer> GetChildrenCore() => grid.AutomationEditor(row, column) is { } peer ? [peer] : [];
        protected override bool IsKeyboardFocusableCore() => !IsReadOnly;
        protected override bool HasKeyboardFocusCore() => !IsReadOnly && grid.HasCellFocus(row, column);
        protected override bool IsOffscreenCore() => grid.AutomationOffscreen(row, column);
        protected override bool IsDataValidForFormCore() => grid.AutomationError(row, column) == null;
        protected override string GetHelpTextCore() => grid.AutomationError(row, column) ?? (IsReadOnly ? "Enter reveals the entity in the graph." : "Enter or F2 edits this cell. Enter commits; Escape cancels.");
        protected override string GetItemStatusCore() => grid.AutomationError(row, column) is { } error ? "Invalid: " + error : grid.AutomationSelected(row) ? "Selected" : "";
        protected override string GetItemTypeCore() => grid.AutomationColumnId(column);
        protected override void SetFocusCore() => Realize();
        protected override object? GetPatternCore(PatternInterface pattern) => pattern is PatternInterface.GridItem or PatternInterface.TableItem or PatternInterface.Value or PatternInterface.Invoke or PatternInterface.VirtualizedItem ? this : null;
        protected override AutomationPeer GetLabeledByCore() => grid.AutomationHeaders().ElementAt(column);
        public int Row => row;
        public int Column => column;
        public int RowSpan => 1;
        public int ColumnSpan => 1;
        public IRawElementProviderSimple ContainingGrid => ProviderFromPeer(parent);
        public IRawElementProviderSimple[] GetColumnHeaderItems() => [parent.GetColumnHeaders()[column]];
        public IRawElementProviderSimple[] GetRowHeaderItems() => [];
        public bool IsReadOnly => !grid.AutomationEditable(column);
        public string Value => grid.AutomationValue(row, column);
        public void SetValue(string value)
        {
            if (IsReadOnly)
                throw new InvalidOperationException("That column is not editable.");
            grid.AutomationEdit(row, column, value);
        }
        public void Invoke()
        {
            Realize();
            grid.AutomationInvoke(row, column);
        }
        public void Realize() => grid.AutomationRealize(row, column);
    }
}
