using Axiom.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.System;
namespace Axiom.App;
public sealed partial class HierarchyView : Grid
{
    private readonly Store store;
    private readonly Selection selection;
    private readonly TreeView tree = new() { SelectionMode = TreeViewSelectionMode.Single };
    private readonly TextBox filter = Ui.Field("Filter hierarchy", "Filter hierarchy");
    private readonly Dictionary<string, TreeViewNode> nodes = [];
    private readonly HashSet<string> expanded = [Ns.Thing, Ns.Pizza + "DomainConcept", Ns.Pizza + "Food", Ns.Pizza + "Pizza", Ns.Pizza + "PizzaTopping"];
    private readonly ComboBox mode = Ui.Named(new ComboBox { ItemsSource = new[] { "Classes", "Properties" }, SelectedIndex = 0 }, "Hierarchy mode");
    private Button classesTab = null!, propertiesTab = null!;
    private bool rendering;
    private readonly TextBlock totals = Ui.Text("", Theme.Caption, "text-secondary");
    private readonly DispatcherTimer debounce = new() { Interval = TimeSpan.FromMilliseconds(140) };
    public event Action? CreateRequested;
    public event Action? RenameRequested;
    public event Action? DeleteRequested;
    public HierarchyView(Store s, Selection bus)
    {
        store = s;
        selection = bus;
        Background = Theme.Brush("surface");
        RowDefinitions.Add(new()
        {
            Height = GridLength.Auto
        });
        RowDefinitions.Add(new()
        {
            Height = GridLength.Auto
        });
        RowDefinitions.Add(new()
        {
            Height = new(1, GridUnitType.Star)
        });
        classesTab = Ui.Tab("Classes", () => mode.SelectedIndex = 0);
        propertiesTab = Ui.Tab("Properties", () => mode.SelectedIndex = 1);
        var header = Ui.Named(new TabStrip(classesTab, propertiesTab), "Hierarchy tabs");
        header.Padding = new(Theme.S3);
        Ui.Add(this, header);
        var bar = Ui.Grid("auto", "*,auto");
        bar.Padding = new(Theme.S2);
        Ui.Add(bar, filter);
        Ui.Add(bar, Ui.Button("+", () => CreateRequested?.Invoke(), "New class"), 0, 1);
        Ui.Add(this, bar, 1);
        tree.ItemTemplate = (Microsoft.UI.Xaml.DataTemplate)Microsoft.UI.Xaml.Markup.XamlReader.Load("<DataTemplate xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"><ContentPresenter Content=\"{Binding Content}\" /></DataTemplate>");
        tree.Resources["TreeViewItemMinHeight"] = Theme.TreeRowHeight;
        Ui.Named(tree, "Ontology hierarchy");
        Ui.Add(this, tree, 2);
        filter.TextChanged += (_, _) => { debounce.Stop(); debounce.Start(); };
        debounce.Tick += (_, _) => { debounce.Stop(); Render(); };
        mode.SelectionChanged += (_, _) => Render();
        tree.SelectionChanged += (_, _) => { var node = tree.SelectedNode; if (node is not null && node.Content is FrameworkElement e && e.Tag is string iri) selection.Select(iri); };
        tree.RightTapped += (_, e) => ShowContext(e);
        tree.DoubleTapped += (_, _) => { if (selection.Iri is { } iri) selection.Select(iri, true); };
        tree.KeyDown += (_, e) => { if (e.Key == VirtualKey.Enter && selection.Iri is { } iri) { selection.Select(iri, true); e.Handled = true; } else if (e.Key == VirtualKey.F2) { RenameRequested?.Invoke(); e.Handled = true; } else if (e.Key == VirtualKey.Delete) { DeleteRequested?.Invoke(); e.Handled = true; } };
        tree.Expanding += (_, e) => { if (!rendering && filter.Text.Trim() == "" && e.Node.Content is FrameworkElement el && el.Tag is string iri) expanded.Add(iri); };
        tree.Collapsed += (_, e) => { if (!rendering && filter.Text.Trim() == "" && e.Node.Content is FrameworkElement el && el.Tag is string iri) expanded.Remove(iri); };
        selection.Changed += iri => { if (iri is not null && nodes.TryGetValue(iri, out var node)) tree.SelectedNode = node; };
        Render();
    }
    public void ExpandAncestors(string iri)
    {
        var seen = new HashSet<string>();
        var pending = new Stack<string>();
        pending.Push(iri);
        while (pending.TryPop(out var current))
            if (seen.Add(current) && store.Entities.TryGetValue(current, out var entity))
            {
                expanded.Add(current);
                foreach (var parent in entity.Parents)
                    pending.Push(parent);
            }
    }
    public void RefreshMetrics()
    {
        tree.Resources["TreeViewItemMinHeight"] = Theme.TreeRowHeight;
        Render();
    }
    public void Render()
    {
        rendering = true;
        nodes.Clear();
        tree.RootNodes.Clear();
        classesTab.Content = "Classes · " + store.ClassCount;
        propertiesTab.Content = "Properties · " + store.PropertyCount;
        classesTab.Background = Theme.Brush(mode.SelectedIndex == 0 ? "layer-selected" : "surface");
        propertiesTab.Background = Theme.Brush(mode.SelectedIndex == 1 ? "layer-selected" : "surface");
        var properties = mode.SelectedIndex == 1;
        var q = filter.Text.Trim();
        bool Eligible(Entity e) => properties ? e.Kind is EntityKind.ObjectProperty or EntityKind.DataProperty : e.Kind is EntityKind.Class or EntityKind.Defined;
        var keep = new HashSet<string>();
        if (q != "")
            foreach (var e in store.Entities.Values.Where(e => Eligible(e) && e.Name.Contains(q, StringComparison.OrdinalIgnoreCase)))
            {
                var queue = new Stack<string>();
                queue.Push(e.Iri);
                while (queue.TryPop(out var u))
                    if (keep.Add(u) && store.Entities.TryGetValue(u, out var a))
                        foreach (var parent in a.Parents)
                            queue.Push(parent);
            }
        TreeViewNode? Build(Entity entity, HashSet<string> ancestors)
        {
            if (!Eligible(entity) || (q != "" && !keep.Contains(entity.Iri)) || ancestors.Contains(entity.Iri))
                return null;
            var text = Ui.Text(store.Label(entity.Iri));
            var count = store.InstanceCount(entity.Iri);
            var row = Ui.Row(Ui.Text(entity.Kind == EntityKind.Defined ? "⊞" : entity.Kind == EntityKind.DataProperty ? "⬡" : properties ? "◇" : "□", Theme.Subtitle, Theme.KindKey(entity.Kind)), text, Ui.Text(count > 0 ? Ns.Count(count) : "", Theme.Caption, "text-secondary"));
            row.Tag = entity.Iri;
            Ui.Named(row, store.Label(entity.Iri));
            var node = new TreeViewNode { Content = row, IsExpanded = q != "" || expanded.Contains(entity.Iri) };
            nodes.TryAdd(entity.Iri, node);
            var next = new HashSet<string>(ancestors) { entity.Iri };
            foreach (var child in entity.Children)
                if (store.Entities.TryGetValue(child, out var e) && Build(e, next) is { } childNode)
                    node.Children.Add(childNode);
            return node;
        }
        IEnumerable<Entity> roots = properties ? store.Entities.Values.Where(e => Eligible(e) && e.Parents.Count == 0).OrderBy(e => e.Name, StringComparer.Create(Ns.Culture, false)) : store.Entities.TryGetValue(Ns.Thing, out var root) ? [root] : [];
        foreach (var entity in roots)
            if (Build(entity, []) is { } node)
                tree.RootNodes.Add(node);
        totals.Text = $"{store.ClassCount} classes · {store.PropertyCount} properties";
        if (selection.Iri is { } selected && nodes.TryGetValue(selected, out var match))
            tree.SelectedNode = match;
        rendering = false;
    }
}
