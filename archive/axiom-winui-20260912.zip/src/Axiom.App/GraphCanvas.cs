using Microsoft.Graphics.Canvas;
using Microsoft.Graphics.Canvas.UI.Xaml;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace Axiom.App;

public sealed class GraphDrawEventArgs(CanvasDrawingSession session) : EventArgs
{
    public CanvasDrawingSession DrawingSession { get; } = session;
}

// A composition swap chain presents each requested graph frame directly. All
// callbacks stay on the UI thread, which also owns graph mutations and input.
public sealed class GraphCanvas : UserControl, IDisposable
{
    private readonly CanvasSwapChainPanel panel = new();
    private CanvasSwapChain? chain;
    private bool queued, disposed, loaded;
    private float width, height, dpi;
    public CanvasDevice Device { get; private set; } = CanvasDevice.GetSharedDevice();
    public event EventHandler? CreateResources;
    public event EventHandler? PreparingDraw;
    public event Action<GraphCanvas, GraphDrawEventArgs>? Draw;
    public event Action<Exception>? Failed;
    public Func<bool>? CanDraw
    {
        get; set;
    }

    public GraphCanvas()
    {
        Content = panel;
        Loaded += (_, _) => { loaded = true; Invalidate(); };
        Unloaded += (_, _) => loaded = false;
        SizeChanged += (_, _) => Invalidate();
    }

    public void Invalidate()
    {
        if (disposed || queued)
            return;
        queued = DispatcherQueue.TryEnqueue(DispatcherQueuePriority.Low, Render);
    }

    private void Render()
    {
        queued = false;
        if (disposed || !loaded || ActualWidth <= 0 || ActualHeight <= 0)
            return;
        try
        {
            var nextWidth = (float)ActualWidth;
            var nextHeight = (float)ActualHeight;
            var nextDpi = (float)(96 * XamlRoot.RasterizationScale);
            if (chain == null)
            {
                chain = new(Device, nextWidth, nextHeight, nextDpi);
                panel.SwapChain = chain;
                CreateResources?.Invoke(this, EventArgs.Empty);
            }
            else if (width != nextWidth || height != nextHeight || dpi != nextDpi)
                chain.ResizeBuffers(nextWidth, nextHeight, nextDpi);
            width = nextWidth;
            height = nextHeight;
            dpi = nextDpi;
            PreparingDraw?.Invoke(this, EventArgs.Empty);
            if (CanDraw?.Invoke() == false)
                return;
            using (var session = chain.CreateDrawingSession(Microsoft.UI.Colors.Transparent))
                Draw?.Invoke(this, new(session));
            chain.Present(1);
        }
        catch (Exception ex)
        {
            if (Device.IsDeviceLost(ex.HResult))
            {
                panel.SwapChain = null;
                chain?.Dispose();
                chain = null;
                Device.RaiseDeviceLost();
                Device = CanvasDevice.GetSharedDevice();
                Invalidate();
            }
            else
                Failed?.Invoke(ex);
        }
    }

    public void Dispose()
    {
        if (disposed)
            return;
        disposed = true;
        panel.SwapChain = null;
        chain?.Dispose();
        chain = null;
        panel.RemoveFromVisualTree();
        Content = null;
    }
}
