using Axiom.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.System;
using Microsoft.UI.Text;
namespace Axiom.App;
public sealed class QueryView : UserControl, IDisposable
{
    private readonly Store store;
    private readonly Selection selection;
    private readonly GraphView graph;
    private readonly Action<string, bool> report;
    private readonly Grid root = Ui.Grid("auto,*,auto", "*,260");
    private readonly RichEditBox editor = Ui.Named(new RichEditBox { AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, FontFamily = new(Theme.MonoFont), FontSize = Theme.Code, Padding = new(12), BorderThickness = new(0), Background = Theme.Brush("surface"), Foreground = Theme.Brush("text"), MinHeight = 0 }, "SPARQL query editor");
    public VirtualGrid Results { get; } = new();
    private readonly TextBlock status = Ui.Text("Ready. Pick an example on the right, or write a query.", 12, "text-secondary");
    private readonly TextBlock resultMessage = Ui.Text("Run a query to see results.", 14, "text-secondary");
    private readonly Button run;
    private readonly Button send;
    private readonly ProgressRing progress = new() { Width = 20, Height = 20, IsActive = false };
    private QueryResult? result;
    private CancellationTokenSource? cancellation;
    private bool highlighting, disposed, highlightedDark; private string? highlightedText;
    public QueryView(Store store, Selection selection, GraphView graph, Action<string, bool> report)
    {
        this.store = store;
        this.selection = selection;
        this.graph = graph;
        this.report = report;
        Content = root;
        Ui.Named(Results, "Query results");
        Results.SelectionCleared += () => selection.Select(null);
        run = Ui.Button("Run", () => RunQuery(), "Run query (Ctrl+Enter)");
        send = Ui.Button("Results to graph", Send);
        send.IsEnabled = false;
        var help = Ui.Button("Supported syntax", Help);
        var bar = Ui.Wrap(run, Ui.Text("Ctrl+Enter", 12, "text-secondary"), Ui.Button("Cancel", () => cancellation?.Cancel()), progress, send, Ui.Text("Basic graph patterns · FILTER · LIMIT", 12, "text-secondary"), help);
        bar.Padding = new(8, 4, 8, 4);
        Ui.Add(root, bar);
        Grid.SetColumnSpan(bar, 2);
        var panes = Ui.Grid("*", "*,*");
        Ui.Add(panes, editor);
        var resultPanel = new Grid();
        resultPanel.Children.Add(Results);
        resultPanel.Children.Add(resultMessage);
        resultMessage.TextWrapping = TextWrapping.Wrap;
        resultMessage.Margin = new(16);
        resultMessage.HorizontalAlignment = HorizontalAlignment.Center;
        Ui.Add(panes, resultPanel, 0, 1);
        Ui.Add(root, panes, 1);
        var examples = new StackPanel { Spacing = 4, Padding = new(8) };
        examples.Children.Add(Ui.Text("Examples", 14));
        foreach (var example in QueryExamples.All)
        {
            var title = Ui.Text(example.Title, 12);
            title.TextWrapping = TextWrapping.Wrap;
            var note = Ui.Text(example.Note, 12, "text-secondary");
            note.TextWrapping = TextWrapping.Wrap;
            var body = new StackPanel { Spacing = 2 };
            body.Children.Add(title);
            body.Children.Add(note);
            var button = Ui.Button(example.Title, () => { SetText(example.Text); RunQuery(); });
            button.Content = body;
            button.Height = double.NaN;
            button.HorizontalAlignment = HorizontalAlignment.Stretch;
            button.HorizontalContentAlignment = HorizontalAlignment.Left;
            button.Padding = new(8);
            examples.Children.Add(button);
        }
        Ui.Add(root, new ScrollViewer { Content = examples, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled }, 1, 1);
        status.Margin = new(8, 4, 8, 4);
        status.TextWrapping = TextWrapping.Wrap;
        Ui.Add(root, status, 2);
        Grid.SetColumnSpan(status, 2);
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetAutomationId(status, "QueryStatus");
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetLiveSetting(status, Microsoft.UI.Xaml.Automation.Peers.AutomationLiveSetting.Polite);
        editor.ActualThemeChanged += (_, _) => DispatcherQueue.TryEnqueue(Highlight);
        editor.TextChanged += (_, _) => Highlight();
        editor.PreviewKeyDown += (_, e) =>
        {
            var ctrl = Microsoft.UI.Input.InputKeyboardSource.GetKeyStateForCurrentThread(VirtualKey.Control).HasFlag(Windows.UI.Core.CoreVirtualKeyStates.Down);
            if (ctrl && e.Key == VirtualKey.Enter)
            {
                RunQuery();
                e.Handled = true;
            }
            else if (e.Key == VirtualKey.Tab && !ctrl)
            {
                editor.Document.Selection.Text = "  ";
                editor.Document.Selection.Collapse(false);
                e.Handled = true;
            }
            else if (e.Key == VirtualKey.Escape || ctrl && e.Key == VirtualKey.Tab)
            {
                run.Focus(FocusState.Keyboard);
                e.Handled = true;
            }
        };
        Results.Activated += (r, c, reveal) => { if (result == null || r >= result.Rows.Count) return; var row = result.Rows[r]; var index = c < 0 ? Array.FindIndex(row, t => !t.IsLiteral) : c; if (index >= 0 && index < row.Length && !row[index].IsLiteral) selection.Select(row[index].Value, reveal); };
        Theme.Changed += Highlight;
        selection.Changed += _ => Results.Render(true);
        SetText(QueryExamples.All[0].Text);
    }
    private void Help()
    {
        var text = Ui.Text("SELECT only. Flat triple patterns, binary FILTER comparisons, DISTINCT, ORDER BY and LIMIT. Built-in prefixes: pizza, demo, rdf, rdfs, owl, xsd.\n\nNo OPTIONAL, UNION, aggregates, property paths or inference. Literal equality ignores datatype. Comparisons with unbound variables do not pass FILTER. Patterns run in written order; put selective patterns first.\n\nTab inserts two spaces. Ctrl+Tab or Escape moves to Run.", 14);
        text.TextWrapping = TextWrapping.Wrap;
        text.MaxWidth = 420;
        var flyout = new Flyout { Content = text };
        flyout.ShowAt(run);
    }
    public string Text
    {
        get
        {
            editor.Document.GetText(TextGetOptions.NoHidden, out var text);
            return text.EndsWith('\r') ? text[..^1].Replace("\r", "\n") : text.Replace("\r", "\n");
        }
    }
    public void SetText(string text)
    {
        editor.Document.SetText(TextSetOptions.None, text);
        Highlight();
    }
    private void Highlight()
    {
        if (highlighting || disposed)
            return;
        var source = Text;
        if (source == highlightedText && Theme.Dark == highlightedDark)
            return;
        highlightedText = source;
        highlightedDark = Theme.Dark;
        highlighting = true;
        try
        {
            var text = Text;
            var whole = editor.Document.GetRange(0, Math.Max(0, text.Length));
            whole.CharacterFormat.ForegroundColor = Theme.Color("text");
            foreach (var token in QueryParser.Tokenise(text))
            {
                var key = token.Kind switch
                {
                    "string" => "syntax-string",
                    "variable" => "syntax-variable",
                    "iri" or "name" => "syntax-iri",
                    "number" => "syntax-number",
                    _ => ""
                };
                if (token.Text == "a" || new[] { "PREFIX", "SELECT", "DISTINCT", "WHERE", "FILTER", "LIMIT", "ORDER", "BY", "ASC", "DESC" }.Contains(token.Text.ToUpperInvariant()))
                    key = "syntax-keyword";
                if (key != "")
                    editor.Document.GetRange(token.Offset, token.Offset + token.Text.Length).CharacterFormat.ForegroundColor = Theme.Color(key);
            }
            foreach (System.Text.RegularExpressions.Match match in System.Text.RegularExpressions.Regex.Matches(text, @"(?m)^\s*#[^\n]*"))
                editor.Document.GetRange(match.Index, match.Index + match.Length).CharacterFormat.ForegroundColor = Theme.Color("syntax-comment");
        }
        catch (QueryException) { }
        finally { highlighting = false; }
    }
    public void RunQuery() => _ = RunQueryAsync();
    public async Task RunQueryAsync()
    {
        if (cancellation != null)
            return;
        var query = Text;
        result = null;
        send.IsEnabled = false;
        Results.Set([], 0, (_, _) => new(""));
        resultMessage.Text = "Running query…";
        resultMessage.Visibility = Visibility.Visible;
        run.IsEnabled = false;
        progress.IsActive = true;
        status.Text = "Running query…";
        cancellation = new();
        var token = cancellation.Token;
        try
        {
            var snapshot = store.QuerySnapshot();
            var answer = await Task.Run(() => new QueryEngine(snapshot).Execute(query, token), token);
            if (disposed)
                return;
            if (answer.StoreVersion != store.Version)
            {
                status.Text = "The Store changed while the query ran. Run again to refresh results.";
                resultMessage.Text = status.Text;
                return;
            }
            result = answer;
            var columns = answer.Columns.Select(c => new TableColumn(c, c, 160, 1, Mono: true)).ToArray();
            Results.Set(columns, answer.Rows.Count, (r, c) => { var term = answer.Rows[r][c]; return new(term.ToString(), term.IsLiteral ? null : term.Value, term.IsLiteral ? "text" : SceneRenderer.KindToken(store.Kind(term.Value))); }, r => answer.Rows[r].Any(t => !t.IsLiteral && t.Value == selection.Iri), reset: true);
            status.Text = $"{Ns.Count(answer.Rows.Count)} {(answer.Rows.Count == 1 ? "row" : "rows")}" + (answer.Total > answer.Rows.Count ? $" of {Ns.Count(answer.Total)} (LIMIT applied)" : "") + $" · {answer.Milliseconds} ms · {Ns.Count(snapshot.TripleCount)} triples" + (answer.Capped ? " · Truncated at the 200,000 intermediate-solution cap" : "");
            resultMessage.Text = "No results. Check the patterns, prefixes and FILTER conditions.";
            resultMessage.Visibility = answer.Rows.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            send.IsEnabled = answer.Iris.Length > 0;
        }
        catch (QueryException ex) { status.Text = ex.Message + " " + ex.Hint; resultMessage.Text = ex.Message + "\n" + ex.Hint; }
        catch (OperationCanceledException) { status.Text = "Query cancelled. Run again when ready."; resultMessage.Text = status.Text; }
        catch (Exception ex) { status.Text = "Query failed: " + ex.Message; resultMessage.Text = status.Text; report(status.Text, true); }
        finally { cancellation?.Dispose(); cancellation = null; run.IsEnabled = true; progress.IsActive = false; }
    }
    public void Refresh(Change change)
    {
        cancellation?.Cancel();
        if (result == null)
            return;
        result = null;
        send.IsEnabled = false;
        Results.Set([], 0, (_, _) => new(""));
        status.Text = "The Store changed. Run the query again to refresh results.";
        resultMessage.Text = status.Text;
        resultMessage.Visibility = Visibility.Visible;
    }
    private void Send()
    {
        if (result == null)
            return;
        var iris = result.Iris.Take(graph.View.Budget).ToArray();
        if (iris.Length == 0)
        {
            report("No IRIs to send to the graph.", true);
            return;
        }
        graph.Seed(iris, true, false);
        report($"Seeded the graph with {Ns.Count(iris.Length)} of {Ns.Count(result.Iris.Length)} result IRIs.", false);
    }
    public void Dispose()
    {
        disposed = true;
        cancellation?.Cancel();
        Theme.Changed -= Highlight;
    }
}
