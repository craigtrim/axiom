using System.Text.Json;
using Axiom.Core;
using Axiom.Fixture;
using Microsoft.UI.Xaml.Media.Imaging;
using Windows.Graphics.Imaging;
using Windows.Storage;
using Windows.Storage.Streams;
namespace Axiom.App;
public sealed partial class MainWindow
{
    private async Task VerifyNative()
    {
        var checks = new List<string>();
        var frames = new List<object>();
        Directory.CreateDirectory("artifacts");
        File.WriteAllText("artifacts/native-progress.log", "Started " + DateTimeOffset.Now + "\n");
        void Stage(string value) => File.AppendAllText("artifacts/native-progress.log", DateTimeOffset.Now + " " + value + "\n");
        try
        {
            Stage("Waiting for first layout");
            await Task.Delay(700);
            await graph.WaitIdle();
            individuals.Rows.Render(true);
            var smallWindow = individuals.Rows.RealizedRows;
            if (smallWindow == 0)
                throw new Exception("The individuals table realized no native rows.");
            Stage("Generating 100000");
            var generated = await Task.Run(() => PizzaFixture.Generate(100000));
            store.LoadGenerated(generated.Individuals, generated.Customers);
            await graph.WaitIdle();
            await Task.Delay(150);
            individuals.Rows.Render(true);
            if (individuals.Rows.RealizedRows != smallWindow)
                throw new Exception("Native realized row count changed with dataset size.");
            checks.Add($"Native row count remains {smallWindow} when scaling from 12,000 to 100,000 records.");
            Stage("Seeding 1000-node grid");
            graph.Layout.Choice = "grid";
            graph.Seed(store.Entities.Keys.Concat(store.Individuals.Select(i => i.Iri)).Take(1000), true, false);
            await graph.WaitIdle();
            foreach (var dark in new[] { false, true })
            {
                Stage("Rendering " + dark);
                Theme.Set(dark, root);
                await Task.Delay(100);
                frames.Add(await graph.VerifyRendering("artifacts", dark ? "dark" : "light"));
                await CaptureShell("shell-" + (dark ? "dark" : "light") + ".png");
            }
            checks.Add("Both themes render 1,000-node PNG scenes and full SVG exports through the shared scene renderer.");
            Stage("Running query");
            ShowDockTab(1);
            console.SetText(QueryExamples.All[0].Text);
            await console.RunQueryAsync();
            await CaptureShell("query-console.png");
            checks.Add("The native rich-text editor executes the corrected NamedPizza example at 100,000 records.");
            Directory.CreateDirectory("artifacts");
            File.WriteAllText("artifacts/native-verification.json", JsonSerializer.Serialize(new
            {
                Passed = true,
                Checks = checks,
                Frames = frames,
                Date = DateTimeOffset.UtcNow,
                OS = Environment.OSVersion.ToString(),
                TripleCount = store.TripleCount
            }, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch (Exception ex) { Directory.CreateDirectory("artifacts"); File.WriteAllText("artifacts/native-verification.json", JsonSerializer.Serialize(new { Passed = false, Checks = checks, Error = ex.ToString() }, new JsonSerializerOptions { WriteIndented = true })); Environment.ExitCode = 1; }
        finally { Close(); }
    }
    private async Task CaptureShell(string name)
    {
        var capture = WindowCapture.Read(WinRT.Interop.WindowNative.GetWindowHandle(this));
        Directory.CreateDirectory("artifacts");
        var folder = await StorageFolder.GetFolderFromPathAsync(Path.GetFullPath("artifacts"));
        var file = await folder.CreateFileAsync(name, CreationCollisionOption.ReplaceExisting);
        using var stream = await file.OpenAsync(FileAccessMode.ReadWrite);
        var encoder = await BitmapEncoder.CreateAsync(BitmapEncoder.PngEncoderId, stream);
        encoder.SetPixelData(BitmapPixelFormat.Bgra8, BitmapAlphaMode.Ignore, capture.Width, capture.Height, 96, 96, capture.Pixels);
        await encoder.FlushAsync();
    }
}
