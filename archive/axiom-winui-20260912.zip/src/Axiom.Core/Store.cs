namespace Axiom.Core;

// M2/M3. STORE-25..101. Only the bounded adjacency result is materialised.
public sealed partial class Store
{
    public const int NeighbourCap = 4000;
    public Dictionary<string, Entity> Entities { get; } = new(StringComparer.Ordinal);
    public List<Triple> TBox { get; } = [];
    public List<Triple> RBox { get; } = [];
    public List<Individual> Individuals { get; private set; } = [];
    public List<Customer> Customers { get; private set; } = [];
    public Dictionary<string, Individual> IndividualIndex { get; private set; } = [];
    public Dictionary<string, List<Individual>> ByType { get; private set; } = [];
    public Dictionary<string, Customer> CustomerIndex { get; private set; } = [];
    public int Version
    {
        get; private set;
    }
    public int ClassCount => Entities.Values.Count(e => e.Kind is EntityKind.Class or EntityKind.Defined);
    public int PropertyCount => Entities.Values.Count(e => e.Kind is EntityKind.ObjectProperty or EntityKind.DataProperty);
    public int IndividualCount => Individuals.Count + Customers.Count + Entities.Values.Count(e => e.Kind == EntityKind.Individual);
    public long TripleCount => TBox.Count + RBox.Count + 7L * Individuals.Count + 2L * Customers.Count;
    public event Action<Change>? Changed;
    private Dictionary<string, List<Neighbour>> reverse = [];
    private Dictionary<string, List<Triple>> bySubject = [], byPredicate = [];
    private Dictionary<string, List<Individual>>? byCustomer;
    private int customerVersion = -1;
    private readonly Stack<(string Description, Action Undo)> undo = [];
    public bool CanUndo => undo.Count > 0;
    public string? UndoDescription => undo.TryPeek(out var op) ? op.Description : null;

    public Entity AddEntity(string iri, EntityKind kind)
    {
        if (!Entities.TryGetValue(iri, out var entity))
            Entities.Add(iri, entity = new(iri, kind));
        entity.Kind = kind;
        return entity;
    }
    public string Label(string iri)
    {
        if (IndividualIndex.TryGetValue(iri, out var order))
            return order.Reference;
        if (Entities.TryGetValue(iri, out var e))
            return Ns.Humanise(e.Name);
        if (CustomerIndex.TryGetValue(iri, out var c))
            return c.Name;
        return Ns.Humanise(Ns.Local(iri));
    }
    public int InstanceCount(string iri) => iri == Ns.Demo + "Order" ? Individuals.Count : iri == Ns.Demo + "Customer" ? Customers.Count : ByType.GetValueOrDefault(iri)?.Count ?? 0;
    public IEnumerable<string> InstanceIris(string iri) => iri == Ns.Demo + "Order" ? Individuals.Select(i => i.Iri) : iri == Ns.Demo + "Customer" ? Customers.Select(c => c.Iri) : (ByType.GetValueOrDefault(iri) ?? []).Select(i => i.Iri);
    public int DescendantCount(string iri)
    {
        var seen = new HashSet<string> { iri };
        var pending = new Stack<string>();
        pending.Push(iri);
        while (pending.TryPop(out var current))
            if (Entities.TryGetValue(current, out var entity))
                foreach (var child in entity.Children)
                    if (seen.Add(child))
                        pending.Push(child);
        return seen.Count - 1;
    }
    public EntityKind Kind(string iri) => Entities.TryGetValue(iri, out var e) ? e.Kind : EntityKind.Individual;
    public bool Exists(string iri) => Entities.ContainsKey(iri) || IndividualIndex.ContainsKey(iri) || CustomerIndex.ContainsKey(iri);
    public Entity? Resolve(string iri)
    {
        if (Entities.TryGetValue(iri, out var e))
            return e;
        if (IndividualIndex.TryGetValue(iri, out var i))
            return new(iri, EntityKind.Individual)
            {
                Types = [i.Type],
                Comment = "Generated demo individual."
            };
        if (CustomerIndex.TryGetValue(iri, out var c))
            return new(iri, EntityKind.Individual)
            {
                Name = c.Name,
                Types = [Ns.Demo + "Customer"],
                Comment = "Generated demo individual."
            };
        return null;
    }
    public void LoadGenerated(List<Individual> individuals, List<Customer> customers)
    {
        var index = new Dictionary<string, Individual>(individuals.Count, StringComparer.Ordinal);
        var types = new Dictionary<string, List<Individual>>(StringComparer.Ordinal);
        foreach (var item in individuals)
        {
            index.Add(item.Iri, item);
            if (!types.TryGetValue(item.Type, out var bucket))
                types.Add(item.Type, bucket = []);
            bucket.Add(item);
        }
        var ci = customers.ToDictionary(c => c.Iri, StringComparer.Ordinal);
        Individuals = individuals;
        Customers = customers;
        IndividualIndex = index;
        ByType = types;
        CustomerIndex = ci;
        byCustomer = null;
        undo.Clear();
        Notify("Dataset regenerated", regenerated: true);
    }
    public void RebuildSchemaIndexes()
    {
        RBox.Clear();
        foreach (var e in Entities.Values)
        {
            e.Children.Clear();
            foreach (var r in e.Restrictions.Concat(e.Equivalents))
                if (r.Shape == "restriction" && r.Quantifier is "some" or "value")
                    foreach (var target in r.Fillers)
                        RBox.Add(new(e.Iri, r.Property!, new(target)));
        }
        RebuildReverseIndex();
        foreach (var e in Entities.Values)
            foreach (var parent in e.Parents.Distinct())
                if (Entities.TryGetValue(parent, out var p))
                    p.Children.Add(e.Iri);
        foreach (var e in Entities.Values)
            SortChildren(e);
        bySubject = TBox.Concat(RBox).GroupBy(t => t.Subject).ToDictionary(g => g.Key, g => g.ToList());
        byPredicate = TBox.Concat(RBox).GroupBy(t => t.Predicate).ToDictionary(g => g.Key, g => g.ToList());
    }
    private static void SortChildren(Entity entity) => entity.Children.Sort((a, b) => Ns.Culture.CompareInfo.Compare(Ns.Local(a), Ns.Local(b)));
    private void RebuildReverseIndex()
    {
        reverse.Clear();
        foreach (var e in Entities.Values)
        {
            foreach (var r in e.Restrictions.Concat(e.Equivalents))
                foreach (var target in r.Fillers)
                    Reverse(target, new(e.Iri, r.Property ?? Ns.Owl + "equivalentClass", false));
            if (e.Domain is not null)
                Reverse(e.Domain, new(e.Iri, Ns.Rdfs + "domain", false));
            if (e.Range is not null)
                Reverse(e.Range, new(e.Iri, Ns.Rdfs + "range", false));
        }
    }
    private void AddSchemaTriple(Triple triple)
    {
        TBox.Add(triple);
        if (!bySubject.TryGetValue(triple.Subject, out var subjects))
            bySubject.Add(triple.Subject, subjects = []);
        subjects.Add(triple);
        if (!byPredicate.TryGetValue(triple.Predicate, out var predicates))
            byPredicate.Add(triple.Predicate, predicates = []);
        predicates.Add(triple);
    }
    private void Reverse(string iri, Neighbour n)
    {
        if (!reverse.TryGetValue(iri, out var list))
            reverse.Add(iri, list = []);
        list.Add(n);
    }
    public IReadOnlyList<Individual> OrdersFor(string customer)
    {
        if (byCustomer is null || customerVersion != Version)
        {
            var map = new Dictionary<string, List<Individual>>(StringComparer.Ordinal);
            foreach (var i in Individuals)
            {
                if (i.CustomerIndex < 0 || i.CustomerIndex >= Customers.Count)
                    continue;
                var key = Customers[i.CustomerIndex].Iri;
                if (!map.TryGetValue(key, out var list))
                    map.Add(key, list = []);
                list.Add(i);
            }
            byCustomer = map;
            customerVersion = Version;
        }
        return byCustomer.TryGetValue(customer, out var records) ? records : Array.Empty<Individual>();
    }
    // The optional membership filter ensures edges across batches are never lost to the cap (DEF-17).
    public Adjacency Neighbours(string iri, IReadOnlySet<string>? membership = null)
    {
        var result = new List<Neighbour>();
        var distinct = new HashSet<Neighbour>();
        var total = 0;
        void Add(string target, string pred, bool outgoing)
        {
            var n = new Neighbour(target, pred, outgoing);
            if (!distinct.Add(n))
                return;
            total++;
            if (result.Count < NeighbourCap && (membership is null || membership.Contains(target)))
                result.Add(n);
        }
        if (IndividualIndex.TryGetValue(iri, out var individual))
        {
            Add(individual.Type, Ns.Type, true);
            if (individual.CustomerIndex >= 0 && individual.CustomerIndex < Customers.Count)
                Add(Customers[individual.CustomerIndex].Iri, Ns.Demo + "orderedBy", true);
        }
        else if (CustomerIndex.ContainsKey(iri))
        {
            Add(Ns.Demo + "Customer", Ns.Type, true);
            foreach (var i in OrdersFor(iri))
                Add(i.Iri, Ns.Demo + "orderedBy", false);
        }
        else if (Entities.TryGetValue(iri, out var e))
        {
            var pred = e.Kind is EntityKind.ObjectProperty or EntityKind.DataProperty ? Ns.SubProperty : Ns.SubClass;
            foreach (var p in e.Parents)
                Add(p, pred, true);
            foreach (var c in e.Children)
                Add(c, pred, false);
            foreach (var r in e.Restrictions.Concat(e.Equivalents))
                foreach (var f in r.Fillers)
                    Add(f, r.Property ?? Ns.Owl + "equivalentClass", true);
            foreach (var d in e.DisjointWith)
                Add(d, Ns.Owl + "disjointWith", true);
            if (e.Domain is not null)
                Add(e.Domain, Ns.Rdfs + "domain", true);
            if (e.Range is not null)
                Add(e.Range, Ns.Rdfs + "range", true);
            if (e.Inverse is not null)
                Add(e.Inverse, Ns.Owl + "inverseOf", true);
            foreach (var t in e.Types)
                Add(t, Ns.Type, true);
            if (reverse.TryGetValue(iri, out var incoming))
                foreach (var r in incoming)
                    Add(r.Iri, r.Predicate, false);
            if (ByType.TryGetValue(iri, out var bucket))
                foreach (var i in bucket)
                    Add(i.Iri, Ns.Type, false);
            if (iri == Ns.Demo + "Customer")
                foreach (var c in Customers)
                    Add(c.Iri, Ns.Type, false);
            if (iri == Ns.Demo + "Order")
                foreach (var i in Individuals)
                    Add(i.Iri, Ns.Type, false);
        }
        return new(result, total);
    }
    private void Notify(string description, bool structural = false, bool regenerated = false)
    {
        Version++;
        Changed?.Invoke(new(description, structural, regenerated));
    }
}
