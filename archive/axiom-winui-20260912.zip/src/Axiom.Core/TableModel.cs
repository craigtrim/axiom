namespace Axiom.Core;
public sealed record TableColumn(string Id, string Header, double Minimum, double Weight = 0, bool Mono = false, bool Numeric = false, bool Editable = false);
public sealed class TableModel(Store store)
{
    public static readonly double RowHeight = DesignTokens.Number("h-row");
    public static readonly TableColumn[] Columns = [
        new("iri", "Individual", 170, 1.1),
        new("type", "Type", 130, .9),
        new("ref", "Order ref", 108, Mono: true),
        new("branch", "Branch", 124, Editable: true),
        new("price", "Price", 92, Mono: true, Numeric: true, Editable: true),
        new("rating", "Rating", 84, Mono: true, Numeric: true, Editable: true),
        new("ts", "Prepared", 148),
        new("cust", "Customer", 140, .9)];
    public List<Individual> Rows { get; private set; } = [];
    public string Sort { get; private set; } = "iri";
    public int Direction { get; private set; } = 1;
    public string Type { get; set; } = "";
    public string Branch { get; set; } = "";
    public string Query { get; set; } = "";
    public string CustomerName(Individual i) => i.CustomerIndex >= 0 && i.CustomerIndex < store.Customers.Count ? store.Customers[i.CustomerIndex].Name : "";
    public string Display(Individual i, string column) => column switch
    {
        "iri" => Ns.Local(i.Iri),
        "type" => Ns.Humanise(i.TypeName),
        "ref" => i.Reference,
        "branch" => i.Branch,
        "price" => "£" + i.Price.ToString("F2", Ns.Culture),
        "rating" => i.Rating + " / 5",
        "ts" => DateTimeOffset.FromUnixTimeMilliseconds(i.Timestamp).ToString("dd MMM, HH:mm", Ns.Culture),
        "cust" => CustomerName(i) is { Length: > 0 } name ? name : "—",
        _ => ""
    };
    public void ToggleSort(string column)
    {
        if (Sort == column)
            Direction = -Direction;
        else
        {
            Sort = column;
            Direction = 1;
        }
    }
    public void Reset()
    {
        Type = Branch = Query = "";
        Apply();
    }
    public void Apply()
    {
        var q = Query.Trim().ToLowerInvariant();
        var rows = new List<Individual>();
        foreach (var i in store.Individuals)
        {
            if (Type != "" && i.Type != Type || Branch != "" && i.Branch != Branch)
                continue;
            if (q != "" && !string.Join(" ", i.Reference, i.TypeName, i.Branch, Ns.Local(i.Iri), CustomerName(i)).ToLowerInvariant().Contains(q, StringComparison.Ordinal))
                continue;
            rows.Add(i);
        }
        object Key(Individual i) => Sort switch
        {
            "iri" => i.Index,
            "type" => i.TypeName,
            "ref" => i.Reference,
            "branch" => i.Branch,
            "price" => i.Price,
            "rating" => i.Rating,
            "ts" => i.Timestamp,
            "cust" => CustomerName(i),
            _ => i.Index
        };
        if (Sort != "iri" || Direction != 1)
        {
            var comparer = Comparer<object>.Create((a, b) => a is string sa && b is string sb ? string.CompareOrdinal(sa, sb) : ((IComparable)a).CompareTo(b));
            rows = (Direction == 1 ? rows.OrderBy(Key, comparer) : rows.OrderByDescending(Key, comparer)).ToList();
        }
        Rows = rows;
    }
    public static (int First, int Count, double Height) Window(double offset, double height, int total, double rowHeight = double.NaN)
    {
        if (double.IsNaN(rowHeight))
            rowHeight = RowHeight;
        if (!double.IsFinite(rowHeight) || rowHeight <= 0)
            throw new ArgumentOutOfRangeException(nameof(rowHeight));
        var first = Math.Max(0, Math.Min(total, (int)Math.Floor(offset / rowHeight) - 6));
        var count = Math.Max(0, Math.Min(total - first, (int)Math.Ceiling(height / rowHeight) + 12));
        return (first, count, total * rowHeight);
    }
    public static double[] Widths(double available, TableColumn[]? columns = null)
    {
        columns ??= Columns;
        var spare = Math.Max(0, available - columns.Sum(c => c.Minimum));
        var weights = columns.Sum(c => c.Weight);
        return columns.Select(c => c.Minimum + (weights > 0 ? spare * c.Weight / weights : 0)).ToArray();
    }
}
