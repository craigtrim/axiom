namespace Axiom.Core;
public sealed class GraphNode(string iri, EntityKind kind, string label)
{
    public string Iri { get; } = iri;
    public EntityKind Kind { get; } = kind;
    public string Label { get; set; } = label;
    public double X, Y, Vx, Vy, Charge;
    public int Degree, ShownDegree, Distance;
    public double Radius = 8.5;
    public long Touched;
    public bool Pinned, Expanded, Dragging;
    public int Hidden => Math.Max(0, Degree - ShownDegree);
    public bool Fixed => Pinned || Dragging;
}
public readonly record struct EdgeKey(string Source, string Predicate, string Target);
public sealed class GraphEdge(EdgeKey key)
{
    public EdgeKey Key { get; } = key;
    public int ParallelIndex, ParallelCount = 1;
}
public sealed record Admission(int Added, int Evicted, int Refused, string[] EvictedNames, int Requested = 0, int TotalDegree = 0, string? SourceLabel = null)
{
    public string Report(int budget)
    {
        var source = SourceLabel ?? "the requested entities";
        if (Refused > 0)
            return $"Budget reached at {Ns.Count(budget)} nodes. {Ns.Count(Refused)} neighbours of {source} were left out — raise the budget or unpin something.";
        if (Evicted > 0)
        {
            var names = string.Join(", ", EvictedNames) + (Evicted > EvictedNames.Length ? ", …" : "");
            return $"Budget held at {Ns.Count(budget)}. Paged out {Ns.Count(Evicted)} {(Evicted == 1 ? "node" : "nodes")} furthest from the focus ({names}) to make room for {source}.";
        }
        return $"Added {Ns.Count(Added)} {(Added == 1 ? "node" : "nodes")} to the view.";
    }
}
// M4. VP-1/37/41/53/74/84/109. No renderer dependencies.
public sealed class Viewport
{
    private readonly Store store;
    public Dictionary<string, GraphNode> Nodes { get; } = new(StringComparer.Ordinal);
    public Dictionary<EdgeKey, GraphEdge> Edges { get; } = [];
    public HashSet<string> Focus { get; } = [];
    private readonly List<string> order = [];
    public IEnumerable<GraphNode> OrderedNodes => order.Select(i => Nodes[i]);
    public int Budget { get; private set; } = 1000;
    public string EvictionMode { get; set; } = "degree";
    public long Revision
    {
        get; private set;
    }
    private long clock;
    public double Alpha
    {
        get; set;
    }
    public string? Selected
    {
        get; set;
    }
    public string? Hovered
    {
        get; set;
    }
    public long Hidden => Nodes.Values.Sum(n => (long)n.Hidden);
    public Viewport(Store s)
    {
        store = s;
    }
    public static double NodeRadius(int degree, EntityKind kind) => (kind == EntityKind.Individual ? 5.5 : kind is EntityKind.ObjectProperty or EntityKind.DataProperty ? 7 : 8.5) + Math.Min(9, Math.Log2(1 + degree) * 1.6);
    public GraphNode[] EvictionOrder()
    {
        var candidates = OrderedNodes.Where(n => !n.Pinned && !Focus.Contains(n.Iri));
        return EvictionMode == "lru" ? candidates.OrderBy(n => n.Touched).ToArray() :
            candidates.OrderByDescending(n => n.Distance).ThenBy(n => n.ShownDegree).ThenBy(n => n.Touched).ToArray();
    }
    public Admission Admit(IEnumerable<string> iris, int distance = 0, GraphNode? seed = null)
    {
        var fresh = new List<string>();
        foreach (var iri in iris.Distinct(StringComparer.Ordinal))
        {
            if (Nodes.TryGetValue(iri, out var existing))
            {
                existing.Touched = ++clock;
                existing.Distance = Math.Min(existing.Distance, distance);
            }
            else
                fresh.Add(iri);
        }
        var evicted = new List<string>();
        var room = Budget - Nodes.Count;
        if (fresh.Count > room && EvictionMode != "refuse")
            foreach (var victim in EvictionOrder().Take(fresh.Count - room))
            {
                evicted.Add(victim.Label);
                Remove(victim.Iri);
            }
        room = Budget - Nodes.Count;
        var refused = Math.Max(0, fresh.Count - room);
        fresh = fresh.Take(room).ToList();
        foreach (var iri in fresh)
        {
            var degree = store.Neighbours(iri).Total;
            var kind = store.Kind(iri);
            var t = ++clock;
            var angle = t * 2.399963229728653;
            var radius = 34 * Math.Sqrt(t % 240 + 1);
            Nodes.Add(iri, new(iri, kind, store.Label(iri))
            {
                Degree = degree,
                Radius = NodeRadius(degree, kind),
                Distance = distance,
                Touched = t,
                X = (seed?.X ?? 0) + Math.Cos(angle) * radius,
                Y = (seed?.Y ?? 0) + Math.Sin(angle) * radius
            });
            order.Add(iri);
        }
        if (fresh.Count > 0)
        {
            Link(fresh);
            Alpha = Math.Max(Alpha, .9);
            Revision++;
        }
        return new(fresh.Count, evicted.Count, refused, evicted.Take(3).ToArray());
    }
    private void Link(IEnumerable<string> added)
    {
        var all = Nodes.Keys.ToHashSet(StringComparer.Ordinal);
        var fresh = added.ToHashSet(StringComparer.Ordinal);
        foreach (var n in OrderedNodes)
        {
            // Existing schema hubs must also contribute links omitted by a new individual's forward projection.
            if (!fresh.Contains(n.Iri) && !store.Entities.ContainsKey(n.Iri))
                continue;
            var membership = fresh.Contains(n.Iri) ? all : fresh;
            foreach (var a in store.Neighbours(n.Iri, membership).List)
            {
                if (!all.Contains(a.Iri))
                    continue;
                var key = a.Outgoing ? new EdgeKey(n.Iri, a.Predicate, a.Iri) : new EdgeKey(a.Iri, a.Predicate, n.Iri);
                if (Edges.TryAdd(key, new(key)))
                {
                    Nodes[key.Source].ShownDegree++;
                    Nodes[key.Target].ShownDegree++;
                }
            }
        }
        IndexParallelEdges();
    }
    public void IndexParallelEdges()
    {
        foreach (var group in Edges.Values.GroupBy(e => string.CompareOrdinal(e.Key.Source, e.Key.Target) < 0 ? (e.Key.Source, e.Key.Target) : (e.Key.Target, e.Key.Source)))
        {
            var edges = group.ToArray();
            for (var i = 0; i < edges.Length; i++)
            {
                edges[i].ParallelIndex = i;
                edges[i].ParallelCount = edges.Length;
            }
        }
    }
    public bool Remove(string iri)
    {
        if (!Nodes.ContainsKey(iri))
            return false;
        foreach (var key in Edges.Keys.Where(e => e.Source == iri || e.Target == iri).ToArray())
        {
            if (Nodes.TryGetValue(key.Source, out var a))
                a.ShownDegree--;
            if (Nodes.TryGetValue(key.Target, out var b))
                b.ShownDegree--;
            Edges.Remove(key);
        }
        Nodes.Remove(iri);
        order.Remove(iri);
        Focus.Remove(iri);
        if (Selected == iri)
            Selected = null;
        if (Hovered == iri)
            Hovered = null;
        Alpha = Math.Max(Alpha, .4);
        Revision++;
        return true;
    }
    public Admission Expand(string iri, int? limit = null)
    {
        if (!Nodes.TryGetValue(iri, out var node))
            return new(0, 0, 0, []);
        var adjacency = store.Neighbours(iri);
        var wanted = adjacency.List.Select(a => a.Iri).Where(i => !Nodes.ContainsKey(i)).Distinct().ToArray();
        var report = Admit(wanted.Take(limit ?? Budget), node.Distance + 1, node);
        node.Expanded = adjacency.Total <= Store.NeighbourCap && node.Hidden == 0;
        node.Touched = ++clock;
        return report with
        {
            Requested = Math.Max(wanted.Length, node.Hidden),
            TotalDegree = adjacency.Total,
            SourceLabel = node.Label
        };
    }
    public int Collapse(string iri)
    {
        if (!Nodes.TryGetValue(iri, out var node))
            return 0;
        var leaves = Edges.Keys.Select(e => e.Source == iri ? e.Target : e.Target == iri ? e.Source : null).Where(i => i != null && i != iri).Distinct()
            .Where(i => Nodes[i!].ShownDegree <= 1 && !Nodes[i!].Pinned && !Focus.Contains(i!)).ToArray();
        foreach (var leaf in leaves)
            Remove(leaf!);
        node.Expanded = false;
        return leaves.Length;
    }
    public Admission Seed(IEnumerable<string> iris, bool replace = true, bool expand = true)
    {
        var seeds = iris.Distinct().ToArray();
        if (replace)
            Clear();
        // Protect requested resident seeds before admitting the rest.
        foreach (var iri in seeds)
            if (Nodes.ContainsKey(iri))
                Focus.Add(iri);
        var result = Admit(seeds);
        foreach (var iri in seeds)
            if (Nodes.ContainsKey(iri))
                Focus.Add(iri);
        if (expand)
            foreach (var iri in seeds.Take(12))
            {
                var r = Expand(iri, Math.Max(1, Budget / Math.Max(1, seeds.Length)));
                result = result with
                {
                    Added = result.Added + r.Added,
                    Evicted = result.Evicted + r.Evicted,
                    Refused = result.Refused + r.Refused,
                    EvictedNames = result.EvictedNames.Concat(r.EvictedNames).Take(3).ToArray()
                };
            }
        return result;
    }
    public (bool Accepted, string Message) SetBudget(int value)
    {
        value = Math.Clamp((int)Math.Round(value / 100d) * 100, 100, 3000);
        var protectedCount = Nodes.Values.Count(n => n.Pinned || Focus.Contains(n.Iri));
        if (value < protectedCount)
            return (false, $"Budget unchanged at {Ns.Count(Budget)}. {Ns.Count(protectedCount)} pinned or focused nodes require a budget of at least {Ns.Count((int)Math.Ceiling(protectedCount / 100d) * 100)}.");
        var lowered = value < Budget;
        var remove = Math.Max(0, Nodes.Count - value);
        foreach (var n in EvictionOrder().Take(remove))
            Remove(n.Iri);
        Budget = value;
        Revision++;
        return (true, $"Budget {(lowered ? "lowered" : "set")} to {Ns.Count(Budget)}. Paged out {Ns.Count(remove)} nodes.");
    }
    public void Clear()
    {
        Nodes.Clear();
        Edges.Clear();
        order.Clear();
        Focus.Clear();
        Selected = null;
        Hovered = null;
        Revision++;
    }
    public void Refresh()
    {
        foreach (var node in OrderedNodes.ToArray())
        {
            if (!store.Exists(node.Iri))
            {
                Remove(node.Iri);
                continue;
            }
            node.Label = store.Label(node.Iri);
            node.Degree = store.Neighbours(node.Iri).Total;
            node.Radius = NodeRadius(node.Degree, node.Kind);
            node.ShownDegree = 0;
        }
        Edges.Clear();
        Link(order);
        Revision++;
    }
}
