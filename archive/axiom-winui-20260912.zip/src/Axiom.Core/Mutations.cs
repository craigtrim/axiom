using System.Globalization;
using System.Text.RegularExpressions;
namespace Axiom.Core;
public sealed partial class Store
{
    public static readonly string[] Branches = ["Soho", "Shoreditch", "Camden", "Clerkenwell", "Borough", "Islington"];
    public string? ValidateName(string input, string? except = null)
    {
        var name = input.Trim();
        if (name == "")
            return "A name is required.";
        if (name.Any(char.IsWhiteSpace))
            return "Names cannot contain spaces — use CamelCase, as the rest of the ontology does.";
        if (!Regex.IsMatch(name, @"^[A-Za-z][A-Za-z0-9_-]*$"))
            return "Start with a letter; use letters, digits, hyphen or underscore only.";
        var conflict = Entities.Values.FirstOrDefault(e => e.Iri != except && e.Name == name);
        return conflict is null ? null : $"An entity named {name} already exists at {Ns.Shorten(conflict.Iri)}.";
    }
    public static string? ValidatePrice(string input, out double value)
    {
        value = 0;
        var text = input.Trim();
        if (text == "")
            return "Price is required. Enter an amount in pounds, for example 12.50.";
        if (!double.TryParse((text.StartsWith('£') ? text[1..] : text), NumberStyles.Float, CultureInfo.InvariantCulture, out value) || !double.IsFinite(value))
            return $"“{text}” is not a number. Enter an amount in pounds, for example 12.50.";
        if (value < 0)
            return "Price cannot be negative.";
        if (value > 500)
            return $"Price looks wrong — £{value.ToString("F2", CultureInfo.InvariantCulture)} exceeds the £500 sanity limit for a single pizza.";
        value = Math.Floor(value * 100 + 0.5) / 100;
        return null;
    }
    public static string? ValidateRating(string input, out int rating)
    {
        rating = 0;
        var text = input.Trim();
        if (text == "")
            return "Rating is required. Enter a whole number from 1 to 5.";
        if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var n) || !double.IsFinite(n) || n != Math.Truncate(n))
            return $"Rating must be a whole number, not “{text}”.";
        if (n < 1 || n > 5)
            return $"Rating must be between 1 and 5. You entered {text}.";
        rating = (int)n;
        return null;
    }
    public string? Rename(string iri, string name)
    {
        if (!Entities.TryGetValue(iri, out var e))
            return "Generated individuals cannot be renamed.";
        var error = ValidateName(name, iri);
        if (error != null)
            return error;
        name = name.Trim();
        if (name == e.Name)
            return null;
        var old = e.Name;
        undo.Push(("Rename " + old, () => { if (Entities.TryGetValue(iri, out var current)) current.Name = old; }
        ));
        e.Name = name;
        Notify("Renamed " + name);
        return null;
    }
    public (Entity? Entity, string? Error) CreateClass(string name, string parent, string comment = "Added in this session.")
    {
        var error = ValidateName(name);
        if (error != null)
            return (null, error);
        if (!Entities.TryGetValue(parent, out var p) || p.Kind is not (EntityKind.Class or EntityKind.Defined))
            return (null, "Choose an existing superclass.");
        var iri = Ns.Pizza + name.Trim();
        if (Entities.ContainsKey(iri))
            return (null, "That IRI already exists. Choose a different name.");
        var snapshot = SchemaSnapshot();
        var e = AddEntity(iri, EntityKind.Class);
        e.Parents = [parent];
        e.Comment = comment.Trim();
        p.Children.Add(iri);
        SortChildren(p);
        AddSchemaTriple(new(iri, Ns.SubClass, new(parent)));
        undo.Push(("Create " + e.Name, snapshot));
        RebuildReverseIndex();
        Notify("Created " + e.Name, true);
        return (e, null);
    }
    public string? DeleteClass(string iri)
    {
        if (iri == Ns.Thing)
            return "owl:Thing is the ontology root and cannot be deleted.";
        if (!Entities.TryGetValue(iri, out var e) || e.Kind is not (EntityKind.Class or EntityKind.Defined))
            return "Select a class to delete.";
        var snapshot = SchemaSnapshot();
        var parents = e.Parents.Count > 0 ? e.Parents : [Ns.Thing];
        Entities.Remove(iri);
        TBox.RemoveAll(t => t.Subject == iri || (!t.Object.IsLiteral && t.Object.Value == iri));
        foreach (var child in Entities.Values)
        {
            if (child.Parents.Remove(iri))
                foreach (var p in parents.Where(p => p != child.Iri))
                {
                    if (!child.Parents.Contains(p))
                        child.Parents.Add(p);
                    var triple = new Triple(child.Iri, Ns.SubClass, new(p));
                    if (!TBox.Contains(triple))
                        TBox.Add(triple);
                }
            child.DisjointWith.Remove(iri);
            static List<Restriction> Clean(List<Restriction> rs, string deleted) => rs.Select(r => r with { Fillers = r.Fillers.Where(f => f != deleted).ToArray() }).Where(r => r.Fillers.Length > 0 || r.Quantifier == "max").ToList();
            child.Restrictions = Clean(child.Restrictions, iri);
            child.Equivalents = Clean(child.Equivalents, iri);
            if (child.Domain == iri)
                child.Domain = null;
            if (child.Range == iri)
                child.Range = null;
            if (child.Inverse == iri)
                child.Inverse = null;
            child.Types.Remove(iri);
        }
        undo.Push(("Delete " + e.Name, snapshot));
        RebuildSchemaIndexes();
        Notify("Deleted " + e.Name, true);
        return null;
    }
    private Action SchemaSnapshot()
    {
        var entities = Entities.Values.Select(e => e.Clone()).ToArray();
        var triples = TBox.ToArray();
        return () => { Entities.Clear(); foreach (var e in entities) Entities.Add(e.Iri, e.Clone()); TBox.Clear(); TBox.AddRange(triples); RebuildSchemaIndexes(); };
    }
    public string? EditCell(string iri, string column, string input)
    {
        if (!IndividualIndex.TryGetValue(iri, out var i))
            return "This individual is no longer in the Store.";
        Action apply, reverse;
        if (column == "branch")
        {
            var value = input.Trim();
            if (!Branches.Contains(value))
                return "Branch must be one of: " + string.Join(", ", Branches) + ".";
            var old = i.Branch;
            if (old == value)
                return null;
            apply = () => i.Branch = value;
            reverse = () => i.Branch = old;
        }
        else if (column == "price")
        {
            var error = ValidatePrice(input, out var value);
            if (error != null)
                return error;
            var old = i.Price;
            if (old == value)
                return null;
            apply = () => i.Price = value;
            reverse = () => i.Price = old;
        }
        else if (column == "rating")
        {
            var error = ValidateRating(input, out var value);
            if (error != null)
                return error;
            var old = i.Rating;
            if (old == value)
                return null;
            apply = () => i.Rating = value;
            reverse = () => i.Rating = old;
        }
        else
            return "That column is not editable.";
        undo.Push(("Edit " + column, reverse));
        apply();
        Notify("Updated " + Ns.Local(iri));
        return null;
    }
    public (Individual? Individual, string? Error) CreateIndividual(string type, string branch, string price, long? timestamp = null, int rating = 5, int customerIndex = 0)
    {
        if (!ByType.ContainsKey(type))
            return (null, "Choose an instantiated pizza type.");
        if (!Branches.Contains(branch))
            return (null, "Branch must be one of: " + string.Join(", ", Branches) + ".");
        var error = ValidatePrice(price, out var amount);
        if (error != null)
            return (null, error);
        error = ValidateRating(rating.ToString(CultureInfo.InvariantCulture), out _);
        if (error != null)
            return (null, error);
        if (customerIndex < 0 || customerIndex >= Customers.Count)
            return (null, "Choose an existing customer.");
        var index = Individuals.Count;
        var suffix = index + 1;
        string iri;
        do
        {
            iri = Ns.Demo + "Pizza_" + (suffix++).ToString("D6");
        } while (Exists(iri));
        var item = new Individual { Index = index, Iri = iri, Type = type, Reference = "AX-" + ((100000 + index) % 1000000).ToString("D6"), Branch = branch, Price = amount, Rating = rating, Timestamp = timestamp ?? DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(), CustomerIndex = customerIndex };
        Individuals.Add(item);
        IndividualIndex.Add(iri, item);
        ByType[type].Add(item);
        undo.Push(("Create " + Ns.Local(iri), () => { Individuals.Remove(item); IndividualIndex.Remove(iri); ByType[type].Remove(item); }
        ));
        Notify("Created " + Ns.Local(iri));
        return (item, null);
    }
    public bool Undo()
    {
        if (!undo.TryPop(out var operation))
            return false;
        operation.Undo();
        Notify("Undid " + operation.Description, true);
        return true;
    }
}
