using System.Globalization;
using System.Text.RegularExpressions;
namespace Axiom.Core;

// STORE-4/7/11: identity is always the full IRI.
public static class Ns
{
    public const string Pizza = "http://www.co-ode.org/ontologies/pizza/pizza.owl#";
    public const string Demo = "http://example.org/pizzeria#";
    public const string Rdf = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    public const string Rdfs = "http://www.w3.org/2000/01/rdf-schema#";
    public const string Owl = "http://www.w3.org/2002/07/owl#";
    public const string Xsd = "http://www.w3.org/2001/XMLSchema#";
    public const string Type = Rdf + "type", SubClass = Rdfs + "subClassOf", SubProperty = Rdfs + "subPropertyOf", Thing = Owl + "Thing";
    public static readonly Dictionary<string, string> Prefixes = new() { ["pizza"] = Pizza, ["demo"] = Demo, ["rdf"] = Rdf, ["rdfs"] = Rdfs, ["owl"] = Owl, ["xsd"] = Xsd };
    public static string Expand(string value)
    {
        var i = value.IndexOf(':');
        return i >= 0 && Prefixes.TryGetValue(value[..i], out var ns) ? ns + value[(i + 1)..] : value;
    }
    public static string Shorten(string value)
    {
        foreach (var (p, ns) in Prefixes)
            if (value.StartsWith(ns, StringComparison.Ordinal))
                return p + ":" + value[ns.Length..];
        return "<" + value + ">";
    }
    public static string Local(string value)
    {
        var index = Math.Max(value.LastIndexOf('#'), value.LastIndexOf('/'));
        return value[(index + 1)..];
    }
    public static string Humanise(string value) => Regex.Replace(value.Replace('_', ' '), @"([a-z0-9])([A-Z])", "$1 $2");
    public static readonly CultureInfo Culture = CreateCulture();
    private static CultureInfo CreateCulture()
    {
        var culture = (CultureInfo)CultureInfo.GetCultureInfo("en-GB").Clone();
        var months = new[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "" };
        culture.DateTimeFormat.AbbreviatedMonthNames = months;
        culture.DateTimeFormat.AbbreviatedMonthGenitiveNames = months;
        return CultureInfo.ReadOnly(culture);
    }
    public static string Count(long n) => n.ToString("N0", Culture);
}
public enum EntityKind
{
    Class, Defined, Individual, ObjectProperty, DataProperty
}
public static class Kinds
{
    public static string Label(EntityKind k) => k switch { EntityKind.Class => "Class", EntityKind.Defined => "Defined class", EntityKind.Individual => "Individual", EntityKind.ObjectProperty => "Object property", _ => "Data property" };
}
// FIX-17/21: one normal form for all asserted class expressions.
public sealed record Restriction(string Shape, string? Property, string? Quantifier, string[] Fillers, int? Cardinality = null)
{
    public string Text => Shape switch
    {
        "class" => Ns.Shorten(Fillers[0]),
        "not" => "not " + Ns.Shorten(Fillers[0]),
        _ => Ns.Shorten(Property!) + " " + Quantifier + (Cardinality.HasValue ? " " + Cardinality : "") +
          (Fillers.Length == 0 ? "" : Fillers.Length == 1 ? " " + Ns.Shorten(Fillers[0]) : " (" + string.Join(" or ", Fillers.Select(Ns.Shorten)) + ")")
    };
    public static Restriction Parse(string text)
    {
        var p = text.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (p[0] == "not")
            return new("not", null, null, [Ns.Expand(p[1])]);
        if (p.Length == 1)
            return new("class", null, null, [Ns.Expand(p[0])]);
        int? n = p.Length > 2 && int.TryParse(p[2], out var count) ? count : null;
        return new("restriction", Ns.Expand(p[0]), p[1], p.Skip(n.HasValue ? 3 : 2).Select(Ns.Expand).ToArray(), n);
    }
}
public sealed class Entity(string iri, EntityKind kind)
{
    public string Iri { get; } = iri;
    public string Name { get; set; } = Ns.Local(iri);
    public EntityKind Kind { get; set; } = kind;
    public List<string> Parents { get; set; } = [];
    public List<string> Children { get; set; } = [];
    public List<Restriction> Restrictions { get; set; } = [];
    public List<Restriction> Equivalents { get; set; } = [];
    public List<string> DisjointWith { get; set; } = [];
    public List<string> Characteristics { get; set; } = [];
    public List<string> Types { get; set; } = [];
    public string Comment { get; set; } = "";
    public string? Domain
    {
        get; set;
    }
    public string? Range
    {
        get; set;
    }
    public string? Inverse
    {
        get; set;
    }
    public bool IsValuePartition
    {
        get; set;
    }
    public bool Generated => Iri.StartsWith(Ns.Demo, StringComparison.Ordinal);
    public Entity Clone() => new(Iri, Kind) { Name = Name, Parents = [.. Parents], Children = [.. Children], Restrictions = [.. Restrictions], Equivalents = [.. Equivalents], DisjointWith = [.. DisjointWith], Characteristics = [.. Characteristics], Types = [.. Types], Comment = Comment, Domain = Domain, Range = Range, Inverse = Inverse, IsValuePartition = IsValuePartition };
}
public sealed class Individual
{
    public int Index
    {
        get; init;
    }
    public required string Iri
    {
        get; init;
    }
    public required string Type
    {
        get; set;
    }
    public string TypeName => Ns.Local(Type);
    public required string Reference
    {
        get; init;
    }
    public required string Branch
    {
        get; set;
    }
    public double Price
    {
        get; set;
    }
    public long Timestamp
    {
        get; init;
    }
    public int Rating
    {
        get; set;
    }
    public int CustomerIndex
    {
        get; init;
    }
}
public sealed record Customer(string Iri, string Name);
public readonly record struct Term(string Value, bool IsLiteral = false, string DataType = "string")
{
    public static Term Literal(object value, string dt = "string") => new(Convert.ToString(value, CultureInfo.InvariantCulture) ?? "", true, dt);
    public bool Equivalent(Term other) => IsLiteral == other.IsLiteral && Value == other.Value;
    public override string ToString() => IsLiteral ? Value : Ns.Shorten(Value);
}
public readonly record struct Triple(string Subject, string Predicate, Term Object);
public readonly record struct Neighbour(string Iri, string Predicate, bool Outgoing);
public sealed record Adjacency(IReadOnlyList<Neighbour> List, int Total);
public sealed record Change(string Description, bool Structural = false, bool Regenerated = false);
