using System.Globalization;
using System.Text;
using System.Xml;
namespace Axiom.Core;
// SVG uses the same scene and text measurements as the native canvas.
public sealed class SvgDraw : IDraw, IDisposable
{
    private readonly StringBuilder buffer = new();
    private readonly XmlWriter xml;
    private readonly Func<string, double, bool, bool, double> measure;
    private static string N(double n) => n.ToString("0.0", CultureInfo.InvariantCulture);
    public SvgDraw(double width, double height, Func<string, double, bool, bool, double> measure)
    {
        this.measure = measure;
        xml = XmlWriter.Create(buffer, new XmlWriterSettings { OmitXmlDeclaration = true, Indent = true });
        xml.WriteStartElement("svg", "http://www.w3.org/2000/svg");
        Attr("width", N(width));
        Attr("height", N(height));
        Attr("viewBox", $"0 0 {N(width)} {N(height)}");
    }
    private void Attr(string key, string value) => xml.WriteAttributeString(key, value);
    private void Paint(uint colour, double stroke = 0)
    {
        var hex = "#" + (colour & 0xffffff).ToString("X6", CultureInfo.InvariantCulture);
        Attr(stroke > 0 ? "stroke" : "fill", hex);
        if (stroke > 0)
        {
            Attr("fill", "none");
            Attr("stroke-width", N(stroke));
            Attr("stroke-linejoin", "round");
        }
        if ((colour >> 24) != 255)
            Attr("opacity", ((colour >> 24) / 255d).ToString("0.###", CultureInfo.InvariantCulture));
    }
    public double Measure(string text, double size, bool bold = false, bool mono = false) => measure(text, size, bold, mono);
    public void Rectangle(RectD r, uint c, double radius = 0, double stroke = 0)
    {
        xml.WriteStartElement("rect");
        Attr("x", N(r.X));
        Attr("y", N(r.Y));
        Attr("width", N(r.Width));
        Attr("height", N(r.Height));
        Attr("rx", N(radius));
        Paint(c, stroke);
        xml.WriteEndElement();
    }
    public void Circle(PointD p, double r, uint c, double stroke = 0)
    {
        xml.WriteStartElement("circle");
        Attr("cx", N(p.X));
        Attr("cy", N(p.Y));
        Attr("r", N(r));
        Paint(c, stroke);
        xml.WriteEndElement();
    }
    public void Path(PointD[] points, uint c, double stroke = 1, bool closed = false, bool fill = false, bool dashed = false, PointD? quadratic = null)
    {
        if (points.Length == 0)
            return;
        xml.WriteStartElement("path");
        var d = $"M{N(points[0].X)},{N(points[0].Y)}";
        if (quadratic is { } q)
            d += $" Q{N(q.X)},{N(q.Y)} {N(points[^1].X)},{N(points[^1].Y)}";
        else
            foreach (var p in points.Skip(1))
                d += $" L{N(p.X)},{N(p.Y)}";
        if (closed)
            d += " Z";
        Attr("d", d);
        Paint(c, fill ? 0 : stroke);
        if (dashed)
            Attr("stroke-dasharray", "4 3");
        xml.WriteEndElement();
    }
    public void Text(string text, PointD p, uint c, double size, bool bold = false, bool mono = false, bool centred = false, uint? halo = null)
    {
        xml.WriteStartElement("text");
        Attr("x", N(p.X));
        Attr("y", N(p.Y));
        Attr("dominant-baseline", "text-before-edge");
        Attr("font-family", mono ? "Cascadia Mono, Consolas, monospace" : "Segoe UI Variable Text, Segoe UI, sans-serif");
        Attr("font-size", N(size));
        Attr("font-weight", bold ? "600" : "400");
        if (centred)
            Attr("text-anchor", "middle");
        Paint(c);
        if (halo is { } h)
        {
            Attr("stroke", "#" + (h & 0xffffff).ToString("X6"));
            Attr("stroke-width", "3.5");
            Attr("stroke-linejoin", "round");
            Attr("paint-order", "stroke");
        }
        xml.WriteString(text);
        xml.WriteEndElement();
    }
    public void Badge(string text, PointD anchor, uint surface, uint stroke, uint foreground, double scale = 1)
    {
        var width = Measure(text, 9.5 * scale, true) + 9 * scale;
        var bounds = new RectD(anchor.X - width / 2, anchor.Y - 7 * scale, width, 14 * scale);
        Rectangle(bounds, surface, 7 * scale);
        Rectangle(bounds, stroke, 7 * scale, 1);
        xml.WriteStartElement("text");
        Attr("x", N(anchor.X));
        Attr("y", N(anchor.Y + .5 * scale));
        Attr("dominant-baseline", "central");
        Attr("text-anchor", "middle");
        Attr("font-family", "Segoe UI Variable Text, Segoe UI, sans-serif");
        Attr("font-size", N(9.5 * scale));
        Attr("font-weight", "600");
        Paint(foreground);
        xml.WriteString(text);
        xml.WriteEndElement();
    }
    public string Finish()
    {
        xml.WriteEndElement();
        xml.Flush();
        return buffer.ToString();
    }
    public void Dispose() => xml.Dispose();
}
