namespace Axiom.Core;
// LAY-44..117. Deterministic Barnes-Hut repulsion, biased springs and collision projection.
public sealed class ForceLayout(Viewport view)
{
    private GraphNode[] nodes = [];
    private (GraphNode A, GraphNode B, string Predicate)[] edges = [];
    private readonly List<Quad> pool = [];
    private int used;
    private readonly CollisionWorkspace collisions = new();
    private sealed class Quad
    {
        public double X, Y, Size, Mass, Cx, Cy;
        public GraphNode? Body;
        public List<GraphNode>? Extra;
        public Quad[]? Children;
        public bool HasChildren;
        public void Reset(double x, double y, double size)
        {
            X = x;
            Y = y;
            Size = size;
            Mass = Cx = Cy = 0;
            Body = null;
            Extra?.Clear();
            HasChildren = false;
        }
    }
    private Quad Cell(double x, double y, double size)
    {
        if (used == pool.Count)
            pool.Add(new Quad());
        var q = pool[used++];
        q.Reset(x, y, size);
        return q;
    }
    public void Reset(bool fresh)
    {
        nodes = view.OrderedNodes.ToArray();
        edges = view.Edges.Keys.Select(e => (view.Nodes[e.Source], view.Nodes[e.Target], e.Predicate)).ToArray();
        for (var i = 0; i < nodes.Length; i++)
        {
            var n = nodes[i];
            n.Charge = 210 + n.Radius * 16;
            if (!double.IsFinite(n.X) || !double.IsFinite(n.Y))
            {
                n.X = 0;
                n.Y = 0;
            }
            if (fresh && !n.Pinned)
            {
                var r = 30 * Math.Sqrt(i + .5);
                var angle = i * 2.399963229728653;
                n.X = Math.Cos(angle) * r;
                n.Y = Math.Sin(angle) * r;
                n.Vx = n.Vy = 0;
            }
        }
        if (fresh)
        {
            view.Alpha = 1;
            var count = Math.Clamp((int)Math.Floor(70000d / (nodes.Length + 60) + .5), 70, 300);
            for (var i = 0; i < count; i++)
                Step(true);
            view.Alpha = .05;
        }
        else
            view.Alpha = Math.Max(view.Alpha, .5);
    }
    public void Step(bool sync = false)
    {
        if (nodes.Length == 0 || (!sync && view.Alpha < .004))
            return;
        used = 0;
        double x0 = double.PositiveInfinity, y0 = double.PositiveInfinity, x1 = double.NegativeInfinity, y1 = double.NegativeInfinity;
        foreach (var n in nodes)
        {
            x0 = Math.Min(x0, n.X);
            y0 = Math.Min(y0, n.Y);
            x1 = Math.Max(x1, n.X);
            y1 = Math.Max(y1, n.Y);
        }
        var span = Math.Max(2, Math.Max(x1 - x0, y1 - y0)) + 8;
        var root = Cell(x0 - 4, y0 - 4, span);
        foreach (var node in nodes)
            Insert(root, node, 0);
        Accumulate(root);
        foreach (var n in nodes)
            Repel(root, n);
        foreach (var (a, b, predicate) in edges)
        {
            var dx = b.X - a.X + 1e-6;
            var dy = b.Y - a.Y + 1e-6;
            var d = Math.Sqrt(dx * dx + dy * dy);
            var target = 48 + a.Radius + b.Radius + (Layouts.IsHierarchy(predicate) ? 0 : 26);
            var stiff = .6 / Math.Min(7, Math.Max(1, Math.Min(a.ShownDegree, b.ShownDegree)));
            var f = (d - target) / d * view.Alpha * stiff;
            var bias = b.ShownDegree / (double)Math.Max(1, a.ShownDegree + b.ShownDegree);
            a.Vx += dx * f * bias;
            a.Vy += dy * f * bias;
            b.Vx -= dx * f * (1 - bias);
            b.Vy -= dy * f * (1 - bias);
        }
        foreach (var n in nodes)
        {
            n.Vx -= n.X * .024 * view.Alpha;
            n.Vy -= n.Y * .024 * view.Alpha;
            if (n.Fixed)
            {
                n.Vx = n.Vy = 0;
                continue;
            }
            n.Vx *= .62;
            n.Vy *= .62;
            var speed = Math.Sqrt(n.Vx * n.Vx + n.Vy * n.Vy);
            if (speed > 45)
            {
                n.Vx = n.Vx / speed * 45;
                n.Vy = n.Vy / speed * 45;
            }
            n.X += n.Vx;
            n.Y += n.Vy;
        }
        collisions.Resolve(nodes, sync ? 1 : 2);
        view.Alpha *= .9772;
    }
    private void Insert(Quad q, GraphNode n, int depth)
    {
        if (depth > 22 || q.Size < .5)
        {
            (q.Extra ??= []).Add(n);
            return;
        }
        if (!q.HasChildren && q.Body is null)
        {
            q.Body = n;
            return;
        }
        if (!q.HasChildren)
        {
            var half = q.Size / 2;
            var old = q.Body!;
            q.Body = null;
            q.Children ??= new Quad[4];
            q.Children[0] = Cell(q.X, q.Y, half);
            q.Children[1] = Cell(q.X + half, q.Y, half);
            q.Children[2] = Cell(q.X, q.Y + half, half);
            q.Children[3] = Cell(q.X + half, q.Y + half, half);
            q.HasChildren = true;
            Put(q, old, depth);
        }
        Put(q, n, depth);
    }
    private void Put(Quad q, GraphNode n, int depth) => Insert(q.Children![(n.X >= q.X + q.Size / 2 ? 1 : 0) + (n.Y >= q.Y + q.Size / 2 ? 2 : 0)], n, depth + 1);
    private static void Accumulate(Quad q)
    {
        double mass = 0, x = 0, y = 0;
        void Add(GraphNode n)
        {
            mass += n.Charge;
            x += n.X * n.Charge;
            y += n.Y * n.Charge;
        }
        if (q.Body != null)
            Add(q.Body);
        if (q.Extra != null)
            foreach (var n in q.Extra)
                Add(n);
        if (q.HasChildren)
            foreach (var c in q.Children!)
            {
                Accumulate(c);
                if (c.Mass > 0)
                {
                    mass += c.Mass;
                    x += c.Cx * c.Mass;
                    y += c.Cy * c.Mass;
                }
            }
        q.Mass = mass;
        if (mass > 0)
        {
            q.Cx = x / mass;
            q.Cy = y / mass;
        }
    }
    private void Repel(Quad q, GraphNode n)
    {
        if (q.Mass == 0)
            return;
        var dx = n.X - q.Cx;
        var dy = n.Y - q.Cy;
        var d2 = dx * dx + dy * dy;
        if (!q.HasChildren || q.Size * q.Size < .66 * d2)
        {
            if (!q.HasChildren && q.Body == n && (q.Extra is null || q.Extra.Count == 0))
                return;
            var f = q.Mass * view.Alpha / Math.Max(9, d2);
            n.Vx += dx * f;
            n.Vy += dy * f;
            return;
        }
        foreach (var c in q.Children!)
            Repel(c, n);
        if (q.Extra != null)
            foreach (var b in q.Extra)
            {
                if (b == n)
                    continue;
                var ex = n.X - b.X;
                var ey = n.Y - b.Y;
                var f = b.Charge * view.Alpha / Math.Max(9, ex * ex + ey * ey);
                n.Vx += ex * f;
                n.Vy += ey * f;
            }
    }
    public static void Collisions(IReadOnlyList<GraphNode> nodes, int iterations) => new CollisionWorkspace().Resolve(nodes, iterations);
    private sealed class CollisionWorkspace
    {
        private readonly Dictionary<(int, int), List<GraphNode>> grid = [];
        private readonly List<List<GraphNode>> buckets = [];
        public void Resolve(IReadOnlyList<GraphNode> nodes, int iterations)
        {
            for (var iteration = 0; iteration < iterations; iteration++)
            {
                grid.Clear();
                var usedBuckets = 0;
                foreach (var n in nodes)
                {
                    var key = ((int)Math.Floor(n.X / 56), (int)Math.Floor(n.Y / 56));
                    if (!grid.TryGetValue(key, out var list))
                    {
                        if (usedBuckets == buckets.Count)
                            buckets.Add([]);
                        list = buckets[usedBuckets++];
                        list.Clear();
                        grid.Add(key, list);
                    }
                    list.Add(n);
                }
                foreach (var n in nodes)
                {
                    var gx = (int)Math.Floor(n.X / 56);
                    var gy = (int)Math.Floor(n.Y / 56);
                    for (var x = -1; x <= 1; x++)
                        for (var y = -1; y <= 1; y++)
                            if (grid.TryGetValue((gx + x, gy + y), out var list))
                                foreach (var m in list)
                                {
                                    if (string.CompareOrdinal(m.Iri, n.Iri) <= 0)
                                        continue;
                                    var dx = m.X - n.X;
                                    var dy = m.Y - n.Y;
                                    var d = Math.Sqrt(dx * dx + dy * dy);
                                    if (d < .01)
                                    {
                                        dx = .7;
                                        dy = .3;
                                        d = .76;
                                    }
                                    var minimum = n.Radius + m.Radius + 11;
                                    if (d >= minimum)
                                        continue;
                                    var push = (minimum - d) / d * .5;
                                    if (!n.Fixed)
                                    {
                                        n.X -= dx * push;
                                        n.Y -= dy * push;
                                    }
                                    if (!m.Fixed)
                                    {
                                        m.X += dx * push;
                                        m.Y += dy * push;
                                    }
                                }
                }
            }
        }
    }
}
