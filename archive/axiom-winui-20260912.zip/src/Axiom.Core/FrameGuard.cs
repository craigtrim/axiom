namespace Axiom.Core;
public sealed class FrameGuard
{
    public string? LastError
    {
        get; private set;
    }
    public event Action<Exception>? Failed;
    public bool Run(Action frame)
    {
        try
        {
            frame();
            LastError = null;
            return true;
        }
        catch (Exception error) { if (LastError != error.Message) Failed?.Invoke(error); LastError = error.Message; return false; }
    }
}
