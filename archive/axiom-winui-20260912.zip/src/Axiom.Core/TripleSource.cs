namespace Axiom.Core;
public sealed partial class Store
{
    public static readonly string[] DemoPredicates = ["orderRef", "branch", "priceGBP", "preparedAt", "rating", "orderedBy"];
    public Term Value(Individual i, string name) => name switch
    {
        "orderRef" => Term.Literal(i.Reference),
        "branch" => Term.Literal(i.Branch),
        "priceGBP" => Term.Literal(i.Price, "decimal"),
        "rating" => Term.Literal(i.Rating, "integer"),
        "preparedAt" => Term.Literal(DateTimeOffset.FromUnixTimeMilliseconds(i.Timestamp).UtcDateTime.ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'"), "dateTime"),
        "orderedBy" => new(Customers[i.CustomerIndex].Iri),
        _ => throw new ArgumentException("Unknown demo predicate.", nameof(name))
    };
    // STORE-48/50, SPQ-47: stream triples, with indexed dispatch for bound patterns.
    public IEnumerable<Triple> Scan(string? subject = null, string? predicate = null, Term? obj = null)
    {
        bool Match(Triple t) => (subject is null || subject == t.Subject) && (predicate is null || predicate == t.Predicate) && (!obj.HasValue || obj.Value.Equivalent(t.Object));
        IEnumerable<Triple> statics = subject is not null ? bySubject.GetValueOrDefault(subject) ?? [] :
            predicate is not null ? byPredicate.GetValueOrDefault(predicate) ?? [] : TBox.Concat(RBox);
        foreach (var t in statics)
            if (Match(t))
                yield return t;
        if (predicate is null || predicate == Ns.Type)
        {
            IEnumerable<Individual> orders = subject is not null ?
                IndividualIndex.TryGetValue(subject, out var rec) ? [rec] : [] :
                obj.HasValue ? obj.Value.Value == Ns.Demo + "Order" ? Individuals : ByType.GetValueOrDefault(obj.Value.Value) ?? [] : Individuals;
            foreach (var i in orders)
            {
                var type = subject is null && obj?.Value == Ns.Demo + "Order" ? Ns.Demo + "Order" : i.Type;
                var t = new Triple(i.Iri, Ns.Type, new(type));
                if (Match(t))
                    yield return t;
            }
            if (!obj.HasValue || obj.Value.Value == Ns.Demo + "Customer")
            {
                var cs = subject is null ? Customers : CustomerIndex.TryGetValue(subject, out var foundCustomer) ? new List<Customer> { foundCustomer } : [];
                foreach (var c in cs)
                {
                    var t = new Triple(c.Iri, Ns.Type, new(Ns.Demo + "Customer"));
                    if (Match(t))
                        yield return t;
                }
            }
        }
        IEnumerable<string> names = predicate is null ? DemoPredicates :
            predicate.StartsWith(Ns.Demo, StringComparison.Ordinal) && DemoPredicates.Contains(predicate[Ns.Demo.Length..]) ? [predicate[Ns.Demo.Length..]] : [];
        foreach (var name in names)
        {
            IEnumerable<Individual> orders = subject is null ? Individuals : IndividualIndex.TryGetValue(subject, out var i) ? [i] : [];
            foreach (var rec in orders)
            {
                var t = new Triple(rec.Iri, Ns.Demo + name, Value(rec, name));
                if (Match(t))
                    yield return t;
            }
        }
        if (predicate is null || predicate == Ns.Rdfs + "label")
        {
            var cs = subject is null ? Customers : CustomerIndex.TryGetValue(subject, out var foundCustomer) ? new List<Customer> { foundCustomer } : [];
            foreach (var c in cs)
            {
                var t = new Triple(c.Iri, Ns.Rdfs + "label", Term.Literal(c.Name));
                if (Match(t))
                    yield return t;
            }
        }
    }
}
