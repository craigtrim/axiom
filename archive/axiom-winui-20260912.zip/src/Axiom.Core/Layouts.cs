namespace Axiom.Core;
public sealed record GroupBlock(string Label, int Count, double X, double Y, double Width, double Height);
public sealed partial class Layouts
{
    private readonly Viewport view;
    private readonly Store store;
    public ForceLayout Force
    {
        get;
    }
    public string Choice { get; set; } = "auto";
    private (int Nodes, int Edges, long Revision, string Choice)? applied;
    public bool NeedsLayout => applied != (view.Nodes.Count, view.Edges.Count, view.Revision, Choice);
    public void EnsureCurrent(bool reducedMotion = false)
    {
        if (NeedsLayout)
            Run(false, reducedMotion);
    }
    public string Resolved { get; private set; } = "force";
    public List<GroupBlock> Groups { get; } = [];
    public List<double> Rings { get; } = [];
    public (double X, double Y) RingOrigin
    {
        get; private set;
    }
    public Layouts(Viewport v, Store s)
    {
        view = v;
        store = s;
        Force = new(v);
    }
    public static bool IsHierarchy(string predicate) => predicate is Ns.SubClass or Ns.SubProperty or Ns.Type;
    public static string Name(string mode) => mode switch { "force" => "Force-directed", "hierarchy" => "Hierarchy", "radial" => "Radial", "grid" => "Cluster grid", _ => "Auto layout" };
    public string Choose()
    {
        if (Choice != "auto")
            return Choice;
        var n = view.Nodes.Count;
        var m = view.Edges.Count;
        if (n == 0)
            return "force";
        var typed = view.Edges.Keys.Count(e => e.Predicate == Ns.Type);
        var hierarchy = view.Edges.Keys.Count(e => IsHierarchy(e.Predicate));
        if (n > 300 && m > 0 && typed / (double)m > .55)
            return "grid";
        if (n > 500)
            return "grid";
        if (m >= n * .5 && m > 0 && hierarchy / (double)m > .78 && n <= 400)
            return "hierarchy";
        if (view.Focus.Count <= 2 && n > 14)
            return "radial";
        return "force";
    }
    public void Run(bool fresh = true, bool reducedMotion = false)
    {
        applied = (view.Nodes.Count, view.Edges.Count, view.Revision, Choice);
        Resolved = Choose();
        Groups.Clear();
        Rings.Clear();
        view.IndexParallelEdges();
        if (view.Nodes.Count == 0)
        {
            view.Alpha = 0;
            return;
        }
        switch (Resolved)
        {
            case "force":
                Force.Reset(fresh);
                if (reducedMotion)
                    while (view.Alpha >= .004)
                        Force.Step();
                break;
            case "hierarchy":
                Hierarchy();
                break;
            case "radial":
                Radial();
                break;
            case "grid":
                Grid();
                break;
            default:
                throw new InvalidOperationException("Unknown layout.");
        }
    }
    private void Centre()
    {
        if (view.Nodes.Count == 0)
            return;
        var x = (view.Nodes.Values.Min(n => n.X) + view.Nodes.Values.Max(n => n.X)) / 2;
        var y = (view.Nodes.Values.Min(n => n.Y) + view.Nodes.Values.Max(n => n.Y)) / 2;
        foreach (var n in view.OrderedNodes)
            if (!n.Pinned)
            {
                n.X -= x;
                n.Y -= y;
                n.Vx = n.Vy = 0;
            }
    }
    private partial void Hierarchy(); private partial void Radial(); private partial void Grid();
}
