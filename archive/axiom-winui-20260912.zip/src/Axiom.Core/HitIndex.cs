namespace Axiom.Core;

/// <summary>World-space buckets shared by stationary hit tests. Rebuild only after nodes move.</summary>
public sealed class HitIndex
{
    private const double CellSize = 64;
    private readonly Dictionary<(int X, int Y), List<(GraphNode Node, int Order)>> cells = [];
    private double maximumRadius;
    public void Rebuild(IEnumerable<GraphNode> nodes)
    {
        cells.Clear();
        maximumRadius = 0;
        var order = 0;
        foreach (var node in nodes)
        {
            var key = ((int)Math.Floor(node.X / CellSize), (int)Math.Floor(node.Y / CellSize));
            if (!cells.TryGetValue(key, out var cell))
                cells.Add(key, cell = []);
            cell.Add((node, order++));
            maximumRadius = Math.Max(maximumRadius, node.Radius);
        }
    }
    public GraphNode? Hit(PointD point, double padding)
    {
        var reach = maximumRadius + padding;
        GraphNode? result = null;
        var top = -1;
        for (var x = (int)Math.Floor((point.X - reach) / CellSize); x <= (int)Math.Floor((point.X + reach) / CellSize); x++)
            for (var y = (int)Math.Floor((point.Y - reach) / CellSize); y <= (int)Math.Floor((point.Y + reach) / CellSize); y++)
            {
                if (!cells.TryGetValue((x, y), out var cell))
                    continue;
                foreach (var (node, order) in cell)
                {
                    if (order <= top)
                        continue;
                    var dx = node.X - point.X;
                    var dy = node.Y - point.Y;
                    var radius = node.Radius + padding;
                    if (dx * dx + dy * dy <= radius * radius)
                    {
                        result = node;
                        top = order;
                    }
                }
            }
        return result;
    }
}
