using System.Globalization;
using System.Text.Json;
namespace Axiom.Core;
public static class DesignTokens
{
    public static IReadOnlyDictionary<string, uint>? Overrides
    {
        get; set;
    }
    private static readonly JsonElement Data = Load();
    private static readonly IReadOnlyDictionary<string, uint> Light = Palette("light"), Dark = Palette("dark");
    private static IReadOnlyDictionary<string, uint> Palette(string theme) => Values(theme).Where(p => p.Value.StartsWith("#") || p.Value.StartsWith("rgba")).ToDictionary(p => p.Key, p => ParseColour(p.Value));
    private static JsonElement Load()
    {
        using var stream = typeof(DesignTokens).Assembly.GetManifestResourceStream("Axiom.Core.Data.tokens.json")!;
        using var doc = JsonDocument.Parse(stream);
        return doc.RootElement.Clone();
    }
    public static IReadOnlyDictionary<string, string> Values(string theme) => Data.GetProperty(theme).EnumerateObject().ToDictionary(p => p.Name, p => p.Value.GetString()!);
    public static string Value(string token, bool dark = false) => Data.GetProperty(dark ? "dark" : "light").TryGetProperty(token, out var v) ? v.GetString()! : Data.GetProperty("base").GetProperty(token).GetString()!;
    public static double Number(string token) => double.Parse(Value(token).Replace("px", "").Replace("ms", ""), CultureInfo.InvariantCulture);
    public static string Font(string token) => Value(token).Split(',')[0].Trim().Trim('"');
    public static uint Colour(string key, bool dark = false)
    {
        if (Overrides?.TryGetValue(key, out var overridden) == true)
            return overridden;
        return (dark ? Dark : Light)[key];
    }
    private static uint ParseColour(string s)
    {
        if (s.StartsWith('#'))
            return 0xFF000000 | uint.Parse(s[1..], NumberStyles.HexNumber);
        var parts = s[(s.IndexOf('(') + 1)..s.IndexOf(')')].Split(',').Select(p => double.Parse(p, CultureInfo.InvariantCulture)).ToArray();
        return ((uint)Math.Round(parts[3] * 255) << 24) | ((uint)parts[0] << 16) | ((uint)parts[1] << 8) | (uint)parts[2];
    }
    public static double Contrast(uint a, uint b)
    {
        static double Channel(uint v) => v / 255d <= .04045 ? v / 255d / 12.92 : Math.Pow((v / 255d + .055) / 1.055, 2.4);
        static double Luminance(uint v) => .2126 * Channel((v >> 16) & 255) + .7152 * Channel((v >> 8) & 255) + .0722 * Channel(v & 255);
        var l = Luminance(a);
        var r = Luminance(b);
        return (Math.Max(l, r) + .05) / (Math.Min(l, r) + .05);
    }
}
