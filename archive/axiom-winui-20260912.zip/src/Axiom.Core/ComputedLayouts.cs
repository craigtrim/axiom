namespace Axiom.Core;
public sealed partial class Layouts
{
    private partial void Hierarchy()
    {
        var nodes = view.OrderedNodes.ToArray();
        if (nodes.Length == 0)
            return;
        var kids = nodes.ToDictionary(n => n.Iri, _ => new List<string>());
        var pars = nodes.ToDictionary(n => n.Iri, _ => new List<string>());
        var nbr = nodes.ToDictionary(n => n.Iri, _ => new List<string>());
        foreach (var e in view.Edges.Keys)
        {
            nbr[e.Source].Add(e.Target);
            nbr[e.Target].Add(e.Source);
            if (IsHierarchy(e.Predicate))
            {
                pars[e.Source].Add(e.Target);
                kids[e.Target].Add(e.Source);
            }
        }
        var layer = new Dictionary<string, int>();
        var marked = new HashSet<string>();
        int Depth(string u)
        {
            if (layer.TryGetValue(u, out var d))
                return d;
            if (!marked.Add(u))
                return 0;
            d = 0;
            foreach (var p in pars[u])
                d = Math.Max(d, Depth(p) + 1);
            layer[u] = d;
            return d;
        }
        foreach (var n in nodes)
            Depth(n.Iri);
        foreach (var n in nodes)
            if (pars[n.Iri].Count == 0 && kids[n.Iri].Count == 0 && nbr[n.Iri].Count > 0)
                layer[n.Iri] = nbr[n.Iri].Max(v => layer[v]) + 1;
        var rows = Enumerable.Range(0, layer.Values.Max() + 1).Select(_ => new List<GraphNode>()).ToArray();
        foreach (var n in nodes)
            rows[layer[n.Iri]].Add(n);
        var stack = new Stack<string>();
        foreach (var n in nodes)
            stack.Push(n.Iri);
        foreach (var n in rows[0])
            stack.Push(n.Iri);
        var ord = new Dictionary<string, int>();
        while (stack.TryPop(out var u))
            if (ord.TryAdd(u, ord.Count))
                foreach (var c in kids[u].OrderByDescending(Ns.Local, StringComparer.Create(Ns.Culture, false)))
                    if (!ord.ContainsKey(c))
                        stack.Push(c);
        foreach (var row in rows)
            row.Sort((a, b) => ord[a.Iri].CompareTo(ord[b.Iri]));
        var pos = new Dictionary<string, int>();
        void Index()
        {
            foreach (var row in rows)
                for (var i = 0; i < row.Count; i++)
                    pos[row[i].Iri] = i;
        }
        Index();
        if (rows.All(r => r.Count <= 260))
            for (var pass = 0; pass < 8; pass++)
            {
                var up = pass % 2 == 0;
                foreach (var row in up ? rows : rows.Reverse())
                {
                    double Median(GraphNode n)
                    {
                        var points = (up ? pars[n.Iri] : kids[n.Iri]).Where(pos.ContainsKey).Select(v => pos[v]).Order().ToArray();
                        if (points.Length == 0)
                            return pos[n.Iri];
                        var m = points.Length / 2;
                        return points.Length % 2 == 1 ? points[m] : (points[m - 1] + points[m]) / 2d;
                    }
                    var sorted = row.OrderBy(Median).ThenBy(n => pos[n.Iri]).ToArray();
                    row.Clear();
                    row.AddRange(sorted);
                    Index();
                }
            }
        var widths = nodes.ToDictionary(n => n.Iri, n => Math.Min(200, Math.Max(2 * n.Radius + 18, n.Label.Length * 6.8 + 16)));
        foreach (var row in rows)
        {
            double x = 0;
            foreach (var n in row)
            {
                if (!n.Pinned)
                    n.X = x + widths[n.Iri] / 2;
                x += widths[n.Iri] + 20;
            }
            foreach (var n in row)
                if (!n.Pinned)
                    n.X -= Math.Max(0, x - 20) / 2;
        }
        for (var pass = 0; pass < 12; pass++)
            foreach (var row in rows)
                foreach (var entry in row.Select((n, i) => (n, i)).OrderByDescending(e => e.n.ShownDegree))
                {
                    var (n, i) = entry;
                    if (n.Pinned)
                        continue;
                    var refs = (pass % 2 == 0 ? pars[n.Iri] : kids[n.Iri]).Select(u => view.Nodes[u].X).ToArray();
                    if (refs.Length == 0)
                        continue;
                    var lo = i > 0 ? row[i - 1].X + widths[row[i - 1].Iri] / 2 + 20 + widths[n.Iri] / 2 : double.NegativeInfinity;
                    var hi = i + 1 < row.Count ? row[i + 1].X - widths[row[i + 1].Iri] / 2 - 20 - widths[n.Iri] / 2 : double.PositiveInfinity;
                    if (lo <= hi)
                        n.X += (Math.Clamp(refs.Average(), lo, hi) - n.X) * .55;
                }
        for (var r = 0; r < rows.Length; r++)
            foreach (var n in rows[r])
            {
                if (!n.Pinned)
                    n.Y = r * 124;
                n.Vx = n.Vy = 0;
            }
        Centre();
    }
    private partial void Radial()
    {
        var nodes = view.OrderedNodes.ToArray();
        if (nodes.Length == 0)
            return;
        var roots = view.Focus.Where(view.Nodes.ContainsKey).ToArray();
        if (roots.Length == 0)
            roots = [nodes.OrderByDescending(n => n.ShownDegree).First().Iri];
        var nbr = nodes.ToDictionary(n => n.Iri, _ => new List<string>());
        foreach (var e in view.Edges.Keys)
        {
            nbr[e.Source].Add(e.Target);
            nbr[e.Target].Add(e.Source);
        }
        var children = nodes.ToDictionary(n => n.Iri, _ => new List<string>());
        var depth = new Dictionary<string, int>();
        var queue = new List<string>();
        foreach (var root in roots)
            if (depth.TryAdd(root, 0))
                queue.Add(root);
        for (var i = 0; i < queue.Count; i++)
            foreach (var v in nbr[queue[i]])
                if (depth.TryAdd(v, depth[queue[i]] + 1))
                {
                    children[queue[i]].Add(v);
                    queue.Add(v);
                }
        var max = depth.Values.Max();
        var orphans = nodes.Where(n => !depth.ContainsKey(n.Iri)).ToArray();
        if (orphans.Length > 0)
        {
            max++;
            foreach (var n in orphans)
                depth[n.Iri] = max;
        }
        var leaves = new Dictionary<string, int>();
        for (var i = queue.Count - 1; i >= 0; i--)
        {
            var u = queue[i];
            leaves[u] = children[u].Count == 0 ? 1 : children[u].Sum(v => leaves.GetValueOrDefault(v, 1));
        }
        var radii = new double[max + 1];
        var populations = new int[max + 1];
        foreach (var d in depth.Values)
            populations[d]++;
        if (roots.Length > 1)
            radii[0] = Math.Max(52, roots.Sum(r => leaves.GetValueOrDefault(r, 1)) * 52 / (2 * Math.PI));
        for (var d = 1; d <= max; d++)
            radii[d] = Math.Max(radii[d - 1] + 118, populations[d] * 52 / (2 * Math.PI));
        var pending = new Stack<(string U, double Start, double End)>();
        double angle = -Math.PI / 2;
        var total = roots.Sum(r => leaves.GetValueOrDefault(r, 1));
        foreach (var r in roots)
        {
            var span = 2 * Math.PI * leaves.GetValueOrDefault(r, 1) / Math.Max(1, total);
            pending.Push((r, angle, angle + span));
            angle += span;
        }
        while (pending.TryPop(out var item))
        {
            var (u, a0, a1) = item;
            var n = view.Nodes[u];
            var mid = (a0 + a1) / 2;
            if (!n.Pinned)
            {
                n.X = Math.Cos(mid) * radii[depth[u]];
                n.Y = Math.Sin(mid) * radii[depth[u]];
            }
            n.Vx = n.Vy = 0;
            var count = children[u].Sum(c => leaves.GetValueOrDefault(c, 1));
            var a = a0;
            foreach (var c in children[u])
            {
                var span = (a1 - a0) * leaves.GetValueOrDefault(c, 1) / Math.Max(1, count);
                pending.Push((c, a, a + span));
                a += span;
            }
        }
        for (var i = 0; i < orphans.Length; i++)
        {
            var n = orphans[i];
            var a = i / (double)Math.Max(1, orphans.Length) * 2 * Math.PI;
            if (!n.Pinned)
            {
                n.X = Math.Cos(a) * radii[max];
                n.Y = Math.Sin(a) * radii[max];
            }
            n.Vx = n.Vy = 0;
        }
        ForceLayout.Collisions(nodes, 3);
        Centre();
        if (roots.Length == 1)
            Rings.AddRange(radii.Skip(1));
        RingOrigin = (view.Nodes[roots[0]].X, view.Nodes[roots[0]].Y);
    }
    private partial void Grid()
    {
        var nodes = view.OrderedNodes.ToArray();
        if (nodes.Length == 0)
            return;
        string Key(GraphNode n) => store.IndividualIndex.TryGetValue(n.Iri, out var i) ? i.Type : n.Kind == EntityKind.Individual ? Ns.Demo + "Customer" :
            store.Entities.TryGetValue(n.Iri, out var e) && e.Parents.Count > 0 ? e.Parents[0] : "kind:" + n.Kind;
        var blocks = nodes.GroupBy(Key).Select(g =>
        {
            var ns = g.OrderBy(n => n.Label, StringComparer.Create(Ns.Culture, false)).ToArray();
            var cols = Math.Max(1, (int)Math.Ceiling(Math.Sqrt(ns.Length * 1.8)));
            return (Key: g.Key, Nodes: ns, Cols: cols, Width: cols * 36 + 24, Height: (int)Math.Ceiling(ns.Length / (double)cols) * 36 + 46);
        }).OrderByDescending(b => b.Nodes.Length).ToArray();
        var target = Math.Max(700, Math.Sqrt(blocks.Sum(b => (double)b.Width * b.Height)) * 1.6);
        double x = 0, y = 0, rowH = 0;
        var frames = new List<GroupBlock>();
        foreach (var block in blocks)
        {
            if (x > 0 && x + block.Width > target)
            {
                x = 0;
                y += rowH + 48;
                rowH = 0;
            }
            for (var i = 0; i < block.Nodes.Length; i++)
            {
                var n = block.Nodes[i];
                if (!n.Pinned)
                {
                    n.X = x + 30 + i % block.Cols * 36;
                    n.Y = y + 54 + i / block.Cols * 36;
                }
                n.Vx = n.Vy = 0;
            }
            var label = block.Key.StartsWith("kind:") ? Kinds.Label(Enum.Parse<EntityKind>(block.Key[5..])) : Ns.Humanise(Ns.Local(block.Key));
            frames.Add(new(label, block.Nodes.Length, x, y, block.Width, block.Height));
            x += block.Width + 40;
            rowH = Math.Max(rowH, block.Height);
        }
        var dx = (nodes.Min(n => n.X) + nodes.Max(n => n.X)) / 2;
        var dy = (nodes.Min(n => n.Y) + nodes.Max(n => n.Y)) / 2;
        Centre();
        Groups.AddRange(frames.Select(b => b with { X = b.X - dx, Y = b.Y - dy }));
    }
}
