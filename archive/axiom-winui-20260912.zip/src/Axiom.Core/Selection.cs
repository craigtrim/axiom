namespace Axiom.Core;
// ARCH-38: views publish identity; consumers subscribe independently.
public sealed class Selection(Store store)
{
    public string? Iri
    {
        get; private set;
    }
    public bool IsResolved => Iri is { } iri && store.Exists(iri);
    public event Action<string?>? Changed;
    public event Action<string>? RevealRequested;
    public void Select(string? iri, bool reveal = false)
    {
        if (iri != Iri)
        {
            Iri = iri;
            Changed?.Invoke(iri);
        }
        if (reveal && iri is not null)
            RevealRequested?.Invoke(iri);
    }
}
