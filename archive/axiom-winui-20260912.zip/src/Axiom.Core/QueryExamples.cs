using System.Reflection;
using System.Text.Json;
namespace Axiom.Core;
public sealed record QueryExample(string Title, string Note, string Text);
public static class QueryExamples
{
    public static readonly QueryExample[] All = Read();
    private static QueryExample[] Read()
    {
        using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Axiom.Core.Data.examples.json")!;
        return JsonSerializer.Deserialize<QueryExample[]>(stream)!;
    }
}
public sealed partial class Store
{
    // A stable query snapshot keeps edits and regeneration independent of a running join.
    // It retains compact records and synthesises triples only when scanned.
    public Store QuerySnapshot()
    {
        var copy = new Store();
        foreach (var e in Entities.Values)
            copy.Entities.Add(e.Iri, e.Clone());
        copy.TBox.AddRange(TBox);
        copy.RebuildSchemaIndexes();
        copy.LoadGenerated(Individuals.Select(i => new Individual { Index = i.Index, Iri = i.Iri, Type = i.Type, Reference = i.Reference, Branch = i.Branch, Price = i.Price, Timestamp = i.Timestamp, Rating = i.Rating, CustomerIndex = i.CustomerIndex }).ToList(), Customers.ToList());
        copy.Version = Version;
        return copy;
    }
}
