namespace Axiom.Core;
public readonly record struct PointD(double X, double Y);
public readonly record struct RectD(double X, double Y, double Width, double Height)
{
    public bool Intersects(RectD b) => X < b.X + b.Width && X + Width > b.X && Y < b.Y + b.Height && Y + Height > b.Y;
}
public readonly record struct Camera(double X, double Y, double Zoom)
{
    public PointD Screen(double x, double y) => new(x * Zoom + X, y * Zoom + Y);
    public PointD World(double x, double y) => new((x - X) / Zoom, (y - Y) / Zoom);
    public static Camera Fit(Viewport view, double width, double height)
    {
        var bounds = SceneRenderer.Bounds(view, 0);
        if (bounds is null)
            return new(width / 2, height / 2, 1);
        var b = bounds.Value;
        var k = Math.Clamp(Math.Min((width - 88) / Math.Max(1, b.Width), (height - 88) / Math.Max(1, b.Height)), .05, 1.9);
        return new(width / 2 - (b.X + b.Width / 2) * k, height / 2 - (b.Y + b.Height / 2) * k, k);
    }
}
public interface IDraw
{
    void Line(PointD p, PointD q, uint colour, double stroke = 1, bool dashed = false) => Path([p, q], colour, stroke, dashed: dashed);
    void Arrow(PointD tip, double ux, double uy, uint colour) => Path([tip, new(tip.X - ux * 6 - uy * 3, tip.Y - uy * 6 + ux * 3), new(tip.X - ux * 6 + uy * 3, tip.Y - uy * 6 - ux * 3)], colour, closed: true, fill: true);
    void BeginBadges()
    {
    }
    void EndBadges()
    {
    }
    void Badge(string text, PointD anchor, uint surface, uint stroke, uint foreground, double scale = 1)
    {
        var width = Measure(text, 9.5 * scale, true) + 9 * scale;
        var bounds = new RectD(anchor.X - width / 2, anchor.Y - 7 * scale, width, 14 * scale);
        Rectangle(bounds, surface, 7 * scale);
        Rectangle(bounds, stroke, 7 * scale, 1);
        Text(text, new(anchor.X, anchor.Y + .5 * scale - 9.5 * scale * .6), foreground, 9.5 * scale, true, centred: true);
    }
    void BeginLabels()
    {
    }
    void EndLabels()
    {
    }
    void BeginNodes()
    {
    }
    void EndNodes()
    {
    }
    void BeginPaths()
    {
    }
    void EndPaths()
    {
    }
    void Dots(double step, double xOffset, double yOffset, double width, double height, uint colour)
    {
        for (var x = xOffset; x < width; x += step)
            for (var y = yOffset; y < height; y += step)
                Circle(new(x, y), .7, colour);
    }
    double Measure(string text, double size, bool bold = false, bool mono = false);
    void Rectangle(RectD rect, uint colour, double radius = 0, double stroke = 0);
    void Circle(PointD centre, double radius, uint colour, double stroke = 0);
    void Path(PointD[] points, uint colour, double stroke = 1, bool closed = false, bool fill = false, bool dashed = false, PointD? quadratic = null);
    void Text(string text, PointD position, uint colour, double size, bool bold = false, bool mono = false, bool centred = false, uint? halo = null);
}
public sealed record PlacedLabel(string Iri, string Text, PointD Anchor, RectD Bounds, double Size, bool Bold);
public static class SceneRenderer
{
    private static readonly System.Collections.Concurrent.ConcurrentDictionary<int, string> badgeText = new();
    public static string BadgeText(int count)
    {
        if (badgeText.Count > 8192)
            badgeText.Clear();
        return badgeText.GetOrAdd(count, h => "+" + (h > 9999 ? Math.Floor(h / 1000d + .5).ToString(Ns.Culture) + "k" : h > 999 ? (h / 1000d).ToString("F1", Ns.Culture) + "k" : h.ToString(Ns.Culture)));
    }
    public static uint Opacity(uint colour, double opacity) => (colour & 0xFFFFFF) | ((uint)Math.Round(((colour >> 24) & 255) * opacity) << 24);
    public static string KindToken(EntityKind k) => k switch { EntityKind.Class => "e-class", EntityKind.Defined => "e-defined", EntityKind.Individual => "e-individual", EntityKind.ObjectProperty => "e-objprop", _ => "e-dataprop" };
    public static RectD? Bounds(Viewport view, double pad = 90)
    {
        if (view.Nodes.Count == 0)
            return null;
        var ns = view.Nodes.Values;
        var x = ns.Min(n => n.X - n.Radius) - pad;
        var y = ns.Min(n => n.Y - n.Radius) - pad;
        return new(x, y, ns.Max(n => n.X + n.Radius) + pad - x, ns.Max(n => n.Y + n.Radius) + pad - y);
    }
    public static void Shape(IDraw d, EntityKind kind, PointD p, double r, uint colour, double stroke = 0)
    {
        if (kind == EntityKind.Individual)
        {
            d.Circle(p, r, colour, stroke);
            return;
        }
        if (kind is EntityKind.Class or EntityKind.Defined)
        {
            d.Rectangle(new(p.X - r * .92, p.Y - r * .92, r * 1.84, r * 1.84), colour, Math.Min(5, r * .45), stroke);
            return;
        }
        var count = kind == EntityKind.ObjectProperty ? 4 : 6;
        var start = kind == EntityKind.ObjectProperty ? -Math.PI / 2 : Math.PI / 6;
        var points = Enumerable.Range(0, count).Select(i => new PointD(p.X + Math.Cos(start + i * 2 * Math.PI / count) * r, p.Y + Math.Sin(start + i * 2 * Math.PI / count) * r)).ToArray();
        d.Path(points, colour, stroke == 0 ? 1 : stroke, true, stroke == 0);
    }
    public static IReadOnlyList<PlacedLabel> Labels(IDraw d, Viewport view, Camera camera, double width, double height, string? hovered, int maximum = 900, IReadOnlyList<RectD>? reserved = null, double textScale = 1)
    {
        var buckets = new Dictionary<(int, int), List<RectD>>();
        var labels = new List<PlacedLabel>();
        double Priority(GraphNode n) => (view.Focus.Contains(n.Iri) ? 4000 : 0) + (view.Selected == n.Iri ? 3000 : 0) + (hovered == n.Iri ? 2000 : 0) + (n.Pinned ? 900 : 0) + n.Radius * 18 + n.ShownDegree;
        foreach (var n in view.OrderedNodes.OrderByDescending(Priority))
        {
            if (labels.Count >= maximum)
                break;
            var p = camera.Screen(n.X, n.Y);
            p = p with
            {
                Y = p.Y + n.Radius * camera.Zoom + 4
            };
            if (p.X < -240 || p.Y < -40 || p.X > width + 240 || p.Y > height + 40)
                continue;
            var text = n.Label.Length > 30 ? n.Label[..28] + "…" : n.Label;
            var size = (n.Kind == EntityKind.Individual ? 11 : 12.5) * textScale;
            var bold = n.Kind != EntityKind.Individual;
            var tw = d.Measure(text, size, bold);
            var rect = new RectD(p.X - tw / 2 - 3, p.Y - 2, tw + 6, 16 * textScale);
            var x0 = (int)Math.Floor(rect.X / 96);
            var x1 = (int)Math.Floor((rect.X + rect.Width) / 96);
            var y0 = (int)Math.Floor(rect.Y / 96);
            var y1 = (int)Math.Floor((rect.Y + rect.Height) / 96);
            var overlap = reserved?.Any(rect.Intersects) == true;
            for (var x = x0; x <= x1 && !overlap; x++)
                for (var y = y0; y <= y1 && !overlap; y++)
                    if (buckets.TryGetValue((x, y), out var list) && list.Any(rect.Intersects))
                        overlap = true;
            if (overlap)
                continue;
            for (var x = x0; x <= x1; x++)
                for (var y = y0; y <= y1; y++)
                {
                    if (!buckets.TryGetValue((x, y), out var list))
                        buckets.Add((x, y), list = []);
                    list.Add(rect);
                }
            labels.Add(new(n.Iri, text, p, rect, size, bold));
        }
        return labels;
    }
    public static void Render(IDraw d, Viewport view, Layouts layouts, Camera camera, double width, double height, bool dark, string? hover = null, int maxLabels = 900, double textScale = 1)
    {
        uint C(string key) => DesignTokens.Colour(key, dark);
        var k = camera.Zoom;
        d.Rectangle(new(0, 0, width, height), C("canvas"));
        var step = 34 * k;
        if (step > 11)
            d.Dots(step, camera.X % step, camera.Y % step, width, height, C("canvas-grid"));
        foreach (var r in layouts.Rings)
            d.Circle(camera.Screen(layouts.RingOrigin.X, layouts.RingOrigin.Y), r * k, C("canvas-grid"), 1);
        foreach (var b in layouts.Groups)
        {
            var p = camera.Screen(b.X, b.Y);
            d.Rectangle(new(p.X, p.Y, b.Width * k, b.Height * k), C("stroke"), 6 * k, 1);
        }
        var near = new HashSet<string>();
        if (hover != null)
        {
            near.Add(hover);
            foreach (var e in view.Edges.Keys)
            {
                if (e.Source == hover)
                    near.Add(e.Target);
                if (e.Target == hover)
                    near.Add(e.Source);
            }
        }
        d.BeginPaths();
        foreach (var e in view.Edges.Values)
        {
            if (!view.Nodes.TryGetValue(e.Key.Source, out var a) || !view.Nodes.TryGetValue(e.Key.Target, out var b))
                continue;
            var emphasis = hover != null && (a.Iri == hover || b.Iri == hover);
            var structural = Layouts.IsHierarchy(e.Key.Predicate);
            var colour = Opacity(C(emphasis ? "accent" : "stroke-strong"), emphasis ? 1 : hover != null ? .18 : structural ? .72 : .48);
            var stroke = emphasis ? 2 : structural ? 1.15 : 1;
            var p = camera.Screen(a.X, a.Y);
            var q = camera.Screen(b.X, b.Y);
            var anchor = p;
            if (layouts.Resolved == "hierarchy" && Math.Abs(a.Y - b.Y) > 24)
            {
                var my = (p.Y + q.Y) / 2;
                anchor = new(q.X, my);
                d.Path([p, new(p.X, my), anchor, q], colour, stroke, dashed: e.Key.Predicate == Ns.Type);
            }
            else if (e.ParallelCount > 1)
            {
                var dx = q.X - p.X;
                var dy = q.Y - p.Y;
                var length = Math.Max(1, Math.Sqrt(dx * dx + dy * dy));
                var offset = (e.ParallelIndex - (e.ParallelCount - 1) / 2d) * 22 * k * (string.CompareOrdinal(e.Key.Source, e.Key.Target) < 0 ? 1 : -1);
                anchor = new((p.X + q.X) / 2 - dy / length * offset, (p.Y + q.Y) / 2 + dx / length * offset);
                d.Path([p, q], colour, stroke, dashed: e.Key.Predicate == Ns.Type, quadratic: anchor);
            }
            else
                d.Line(p, q, colour, stroke, e.Key.Predicate == Ns.Type);
            if (k > .42)
            {
                var dx = q.X - anchor.X;
                var dy = q.Y - anchor.Y;
                var length = Math.Max(1, Math.Sqrt(dx * dx + dy * dy));
                var ux = dx / length;
                var uy = dy / length;
                var tip = new PointD(q.X - ux * (b.Radius + 2.5) * k, q.Y - uy * (b.Radius + 2.5) * k);
                d.Arrow(tip, ux, uy, colour);
            }
        }
        d.EndPaths();
        d.BeginNodes();
        foreach (var n in view.OrderedNodes)
        {
            var p = camera.Screen(n.X, n.Y);
            var radius = n.Radius * k;
            var alpha = hover != null && !near.Contains(n.Iri) ? .25 : 1;
            if (view.Selected == n.Iri)
                d.Circle(p, radius + 7, C("accent"), 2.5);
            Shape(d, n.Kind, p, radius, Opacity(C(KindToken(n.Kind)), alpha));
            if (n.Kind == EntityKind.Defined)
            {
                d.Path([new(p.X - radius * .4, p.Y), new(p.X + radius * .4, p.Y)], C("canvas"), 2);
                d.Path([new(p.X, p.Y - radius * .4), new(p.X, p.Y + radius * .4)], C("canvas"), 2);
            }
            if (view.Focus.Contains(n.Iri))
                Shape(d, n.Kind, p, radius + 3, C("text"), 1.8);
            if (n.Pinned)
                d.Circle(new(p.X - radius * .8, p.Y - radius * .8), 3.4 + k, C("warn"));
        }
        d.EndNodes();
        var headings = layouts.Groups.Select(b => (Block: b, Point: camera.Screen(b.X + 12, b.Y + 8))).Where(h => k > .22 && h.Block.Width * k > d.Measure(h.Block.Label, 12 * textScale, true) + 24 && h.Block.Height * k > 56 * textScale).ToArray();
        var headingBounds = headings.Select(h => new RectD(h.Point.X - 3, h.Point.Y - 2, d.Measure(h.Block.Label, 12 * textScale, true) + 6, 32 * textScale)).ToArray();
        d.BeginLabels();
        foreach (var label in Labels(d, view, camera, width, height, hover, maxLabels, headingBounds, textScale))
            d.Text(label.Text, label.Anchor, C("text"), label.Size, label.Bold, centred: true, halo: C("canvas"));
        d.EndLabels();
        d.BeginBadges();
        if (k > .3)
            foreach (var n in view.OrderedNodes)
            {
                if (n.Hidden == 0)
                    continue;
                var p = camera.Screen(n.X, n.Y);
                var anchor = new PointD(p.X + n.Radius * k * .92 + 3, p.Y - n.Radius * k * .92 - 3);
                if (anchor.X < -40 || anchor.Y < -20 || anchor.X > width + 40 || anchor.Y > height + 20)
                    continue;
                d.Badge(BadgeText(n.Hidden), anchor, C("surface"), C("stroke-strong"), C("text-secondary"), textScale);
            }
        d.EndBadges();
        foreach (var h in headings)
        {
            d.Text(h.Block.Label, h.Point, C("text-secondary"), 12 * textScale, true);
            d.Text(Ns.Count(h.Block.Count) + " nodes", h.Point with
            {
                Y = h.Point.Y + 15 * textScale
            }, C("text-secondary"), 10 * textScale);
        }
    }
    public static void ExportChrome(IDraw d, Viewport view, Layouts layouts, double width, double height, bool dark, DateTimeOffset timestamp)
    {
        uint C(string key) => DesignTokens.Colour(key, dark);
        d.Rectangle(new(0, 0, width, 86), C("surface"));
        d.Rectangle(new(0, height - 58, width, 58), C("surface"));
        d.Path([new(0, 86.5), new(width, 86.5)], C("stroke"), 1);
        d.Path([new(0, height - 57.5), new(width, height - 57.5)], C("stroke"), 1);
        d.Text("pizza.owl — graph view", new(28, 18), C("text"), 20, true);
        var product = "Axiom Ontology Workbench";
        d.Text(product, new(width - 28 - d.Measure(product, 12, true), 26), C("text-secondary"), 12, true);
        d.Text(Caption(view, layouts, timestamp), new(28, 50), C("text-secondary"), 12, mono: true);
        double x = 28;
        foreach (var kind in Enum.GetValues<EntityKind>())
        {
            Shape(d, kind, new(x + 7, height - 29), 6.5, C(KindToken(kind)));
            var text = Kinds.Label(kind);
            d.Text(text, new(x + 20, height - 37), C("text-secondary"), 12);
            x += d.Measure(text, 12) + 46;
        }
        var note = "Dashed = rdf:type · solid = subClassOf and object properties · +n = neighbours outside the budget";
        var noteWidth = d.Measure(note, 12);
        if (x <= width - 28 - noteWidth)
            d.Text(note, new(width - 28 - noteWidth, height - 37), C("text-secondary"), 12);
    }
    public static double ExportWidth(IDraw d, double sceneWidth, Viewport view, Layouts layouts, DateTimeOffset timestamp) => Math.Max(Math.Max(640, sceneWidth), d.Measure(Caption(view, layouts, timestamp), 12, mono: true) + 56);
    public static double RasterScale(double width, double height, double requested) => Math.Min(requested, Math.Min(9000 / width, 9000 / height));
    public static string Caption(Viewport view, Layouts layouts, DateTimeOffset timestamp) => $"{Layouts.Name(layouts.Resolved)} layout · {Ns.Count(view.Nodes.Count)} nodes · {Ns.Count(view.Edges.Count)} relationships · viewport budget {Ns.Count(view.Budget)} · {Ns.Count(view.Hidden)} neighbours held back · {timestamp.ToString("dd MMM yyyy, HH:mm", Ns.Culture)}";
}
