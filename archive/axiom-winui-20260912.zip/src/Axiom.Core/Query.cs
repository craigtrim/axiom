using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
namespace Axiom.Core;
public sealed class QueryException(string message, string hint) : Exception(message)
{
    public string Hint { get; } = hint;
}
public sealed record QueryToken(string Kind, string Text, int Offset);
public sealed record QueryTerm(string? Variable, Term? Constant);
public sealed record QueryPattern(QueryTerm Subject, QueryTerm Predicate, QueryTerm Object);
public sealed record QueryFilter(QueryTerm Left, string Operator, QueryTerm Right);
public sealed record ParsedQuery(string[] Columns, QueryPattern[] Patterns, QueryFilter[] Filters, bool Distinct, string? Order, bool Descending, int? Limit);
public sealed record QueryResult(string[] Columns, List<Term[]> Rows, int Total, bool Capped, string[] Iris, long Milliseconds, int StoreVersion);
public static class QueryParser
{
    private static readonly Regex TokenPattern = new("""\G(?:(?<space>\s+)|(?<comment>#[^\r\n]*)|(?<string>"(?:\\.|[^"\\])*")|(?<variable>\?[A-Za-z_][A-Za-z0-9_]*)|(?<iri><[^<>\s]*>)|(?<name>[A-Za-z_][A-Za-z0-9_-]*:[A-Za-z0-9_-]*)|(?<number>-?[0-9]+(?:\.[0-9]*)?)|(?<operator><=|>=|!=|=|<|>)|(?<word>[A-Za-z_][A-Za-z0-9_]*)|(?<punct>[{}().;,*])|(?<symbol>\S))""", RegexOptions.Compiled, TimeSpan.FromSeconds(1));
    public static List<QueryToken> Tokenise(string text)
    {
        var result = new List<QueryToken>();
        var p = 0;
        while (p < text.Length)
        {
            var m = TokenPattern.Match(text, p);
            if (!m.Success)
                throw new QueryException($"Cannot read the query at character {p + 1}.", "Check the query syntax against one of the examples.");
            p += m.Length;
            var kind = TokenPattern.GetGroupNames().First(n => n != "0" && m.Groups[n].Success);
            if (kind is not ("space" or "comment"))
                result.Add(new(kind, m.Value, m.Index));
        }
        return result;
    }
    public static ParsedQuery Parse(string text)
    {
        var tokens = Tokenise(text);
        var at = 0;
        var prefixes = new Dictionary<string, string>(Ns.Prefixes);
        QueryToken? Peek() => at < tokens.Count ? tokens[at] : null;
        bool Is(string value) => string.Equals(Peek()?.Text, value, StringComparison.OrdinalIgnoreCase);
        QueryToken Take() => at < tokens.Count ? tokens[at++] : throw new QueryException("The pattern ends too early.", "Every triple pattern needs a subject, a predicate and an object.");
        bool Eat(string value)
        {
            if (!Is(value))
                return false;
            at++;
            return true;
        }
        void Need(string value, string message, string hint)
        {
            if (Eat(value))
                return;
            if (value is "{" or "}" or "(" or ")")
                throw new QueryException(Peek() is { } t ? $"Expected “{value}” but found “{t.Text}”." : $"Expected “{value}” but found the end of the query.", "Check the braces and the dot at the end of each triple pattern.");
            throw new QueryException(message, hint);
        }
        QueryTerm TermOf()
        {
            var token = Take();
            if (token.Kind == "variable")
                return new(token.Text, null);
            if (token.Kind == "iri")
                return new(null, new(token.Text[1..^1]));
            if (token.Kind == "string")
                return new(null, Term.Literal(Regex.Replace(token.Text[1..^1], @"\\(.)", "$1")));
            if (token.Kind == "number")
                return new(null, Term.Literal(double.Parse(token.Text, CultureInfo.InvariantCulture), token.Text.Contains('.') ? "decimal" : "integer"));
            if (token.Text == "a")
                return new(null, new(Ns.Type));
            if (token.Kind == "name")
            {
                var index = token.Text.IndexOf(':');
                var prefix = token.Text[..index];
                if (!prefixes.TryGetValue(prefix, out var ns))
                    throw new QueryException($"Unknown prefix “{prefix}:”.", "Declare it with PREFIX, or use one of: " + string.Join(" ", prefixes.Keys.Select(k => k + ":")));
                return new(null, new(ns + token.Text[(index + 1)..]));
            }
            throw new QueryException($"“{token.Text}” is not a valid term.", "Terms are variables (?x), prefixed names (pizza:Pizza), IRIs (<…>) or literals (\"…\").");
        }
        while (Eat("PREFIX"))
        {
            if (at + 1 >= tokens.Count)
                throw new QueryException("Malformed PREFIX declaration.", "Write it as: PREFIX pizza: <http://www.co-ode.org/ontologies/pizza/pizza.owl#>");
            var prefix = Take();
            var iri = Take();
            if (prefix.Kind != "name" || !prefix.Text.EndsWith(':') || iri.Kind != "iri")
                throw new QueryException("Malformed PREFIX declaration.", "Write it as: PREFIX pizza: <http://www.co-ode.org/ontologies/pizza/pizza.owl#>");
            prefixes[prefix.Text[..^1]] = iri.Text[1..^1];
        }
        Need("SELECT", "Only SELECT queries are supported.", "Start the query with SELECT, or pick an example from the right.");
        var distinct = Eat("DISTINCT");
        var columns = new List<string>();
        while (Peek()?.Kind == "variable" || Is("*"))
            columns.Add(Take().Text);
        if (columns.Count == 0)
            throw new QueryException("SELECT needs at least one variable.", "For example: SELECT ?pizza ?topping");
        Need("WHERE", "Expected WHERE after the projection.", "The shape is: SELECT ?x WHERE { ... }");
        Need("{", "Expected an opening brace after WHERE.", "Enclose triple patterns in { and }.");
        var patterns = new List<QueryPattern>();
        var filters = new List<QueryFilter>();
        while (Peek() != null && !Is("}"))
        {
            if (Eat("."))
                continue;
            if (Eat("FILTER"))
            {
                Need("(", "FILTER needs an opening parenthesis.", "Write FILTER (?price > 13).");
                var lhs = TermOf();
                var op = Take();
                if (op.Kind != "operator")
                    throw new QueryException("FILTER needs a comparison operator.", "Supported: = != < <= > >=");
                var rhs = TermOf();
                Need(")", "FILTER needs a closing parenthesis.", "Write FILTER (?price > 13).");
                filters.Add(new(lhs, op.Text, rhs));
                Eat(".");
            }
            else
            {
                if (Is("OPTIONAL") || Is("UNION") || Is("BIND") || Is("GRAPH"))
                    throw new QueryException($"{Peek()!.Text.ToUpperInvariant()} is not supported.", "Use a flat basic graph pattern with FILTER and LIMIT.");
                patterns.Add(new(TermOf(), TermOf(), TermOf()));
                Eat(".");
            }
        }
        Need("}", "The WHERE block is not closed.", "Add a closing } after the last pattern.");
        if (patterns.Count == 0)
            throw new QueryException("The WHERE block has no triple patterns.", "Add at least one, for example: ?pizza a pizza:NamedPizza .");
        var variables = patterns.SelectMany(p => new[] { p.Subject, p.Predicate, p.Object }).Where(t => t.Variable != null).Select(t => t.Variable!).Distinct().ToArray();
        if (columns[0] == "*")
            columns = variables.ToList();
        foreach (var c in columns)
            if (!variables.Contains(c))
                throw new QueryException($"Variable {c} is selected but never bound in the WHERE block.", "Either bind it in a pattern, or remove it from SELECT.");
        string? order = null;
        var descending = false;
        if (Eat("ORDER"))
        {
            Eat("BY");
            var wrapped = Is("ASC") || Is("DESC");
            if (wrapped)
            {
                descending = Eat("DESC");
                if (!descending)
                    Eat("ASC");
                Need("(", "ORDER direction needs an opening parenthesis.", "Use ORDER BY DESC(?price).");
            }
            if (Peek() == null)
                throw new QueryException("ORDER BY needs a variable.", "For example: ORDER BY DESC(?price)");
            var key = Take();
            if (key.Kind != "variable")
                throw new QueryException("ORDER BY needs a variable.", "For example: ORDER BY DESC(?price)");
            order = key.Text;
            if (wrapped)
                Eat(")");
        }
        int? limit = null;
        if (Eat("LIMIT"))
        {
            if (Peek() == null)
                throw new QueryException("LIMIT needs a number.", "For example: LIMIT 100");
            var value = Take();
            if (value.Kind != "number" || !double.TryParse(value.Text, System.Globalization.NumberStyles.Float, CultureInfo.InvariantCulture, out var n) || n < 0 || n > int.MaxValue)
                throw new QueryException("LIMIT needs a number.", "For example: LIMIT 100");
            limit = (int)n;
        }
        if (Peek() != null)
            throw new QueryException($"Unexpected token “{Peek()!.Text}” after the query.", "Only one ORDER BY key and a non-negative LIMIT are supported.");
        return new(columns.ToArray(), patterns.ToArray(), filters.ToArray(), distinct, order, descending, limit);
    }
}
public sealed class QueryEngine(Store store)
{
    public const int SolutionCap = 200000;
    public QueryResult Execute(string text, CancellationToken cancellation = default, int solutionCap = SolutionCap)
    {
        var watch = Stopwatch.StartNew();
        var query = QueryParser.Parse(text);
        var version = store.Version;
        var solutions = new List<Dictionary<string, Term>> { new() };
        var capped = false;
        static Term? Bind(Dictionary<string, Term> row, QueryTerm t) => t.Variable is { } variable ? row.TryGetValue(variable, out var v) ? v : null : t.Constant;
        foreach (var pattern in query.Patterns)
        {
            var next = new List<Dictionary<string, Term>>();
            var full = false;
            foreach (var row in solutions)
            {
                cancellation.ThrowIfCancellationRequested();
                var s = Bind(row, pattern.Subject);
                var p = Bind(row, pattern.Predicate);
                var o = Bind(row, pattern.Object);
                if (s?.IsLiteral == true || p?.IsLiteral == true)
                    continue;
                foreach (var triple in store.Scan(s?.Value, p?.Value, o))
                {
                    cancellation.ThrowIfCancellationRequested();
                    var candidate = new Dictionary<string, Term>(row);
                    bool Unify(QueryTerm term, Term value)
                    {
                        if (term.Variable is not { } v)
                            return term.Constant!.Value.Equivalent(value);
                        if (candidate.TryGetValue(v, out var old))
                            return old.Equivalent(value);
                        candidate.Add(v, value);
                        return true;
                    }
                    if (!Unify(pattern.Subject, new(triple.Subject)) || !Unify(pattern.Predicate, new(triple.Predicate)) || !Unify(pattern.Object, triple.Object))
                        continue;
                    if (next.Count >= solutionCap)
                    {
                        capped = true;
                        full = true;
                        break;
                    }
                    next.Add(candidate);
                }
                if (full)
                    break;
            }
            solutions = next;
            if (solutions.Count == 0)
                break;
        }
        bool Filter(Dictionary<string, Term> row, QueryFilter f)
        {
            var a = Bind(row, f.Left);
            var b = Bind(row, f.Right);
            // SPQ-87 permitted refinement: an unbound comparison does not pass.
            if (a is null || b is null)
                return false;
            var x = a.Value.Value;
            var y = b.Value.Value;
            var numeric = x != "" && y != "" && double.TryParse(x, NumberStyles.Float, CultureInfo.InvariantCulture, out var an) && double.IsFinite(an) && double.TryParse(y, NumberStyles.Float, CultureInfo.InvariantCulture, out var bn) && double.IsFinite(bn);
            var comparison = numeric ? double.Parse(x, CultureInfo.InvariantCulture).CompareTo(double.Parse(y, CultureInfo.InvariantCulture)) : string.CompareOrdinal(x, y);
            return f.Operator switch
            {
                "=" => comparison == 0,
                "!=" => comparison != 0,
                "<" => comparison < 0,
                "<=" => comparison <= 0,
                ">" => comparison > 0,
                ">=" => comparison >= 0,
                _ => false
            };
        }
        var rows = solutions.Where(row => query.Filters.All(f => Filter(row, f))).Select(row => query.Columns.Select(c => row.GetValueOrDefault(c)).ToArray()).ToList();
        if (query.Distinct)
        {
            var seen = new HashSet<string>();
            rows = rows.Where(row => seen.Add(string.Concat(row.Select(t => (t.IsLiteral ? "L" : "I") + t.Value.Length + ":" + t.Value)))).ToList();
        }
        if (query.Order is { } order)
        {
            var index = Array.IndexOf(query.Columns, order);
            if (index >= 0)
            {
                var comparer = Comparer<Term>.Create((a, b) => double.TryParse(a.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var x) && double.TryParse(b.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var y) ? x.CompareTo(y) : Ns.Culture.CompareInfo.Compare(a.Value, b.Value));
                rows = (query.Descending ? rows.OrderByDescending(row => row[index], comparer) : rows.OrderBy(row => row[index], comparer)).ToList();
            }
        }
        var total = rows.Count;
        if (query.Limit is { } limit)
            rows = rows.Take(limit).ToList();
        var iris = rows.SelectMany(r => r).Where(t => !t.IsLiteral).Select(t => t.Value).Distinct().ToArray();
        return new(query.Columns, rows, total, capped, iris, Math.Max(1, watch.ElapsedMilliseconds), version);
    }
}
